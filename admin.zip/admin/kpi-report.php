<?php
session_start();
ob_start();
$short_header=1;
header ("Content-type: text/html; charset=utf-8");
$agentReport = true;
require("dbconnect.php");
require("functions.php");


#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
{
    $row=mysql_fetch_row($rslt);
    $non_latin =                                            $row[0];
    $SSoutbound_autodial_active =           $row[1];
    $user_territories_active =                      $row[2];
}
##### END SETTINGS LOOKUP #####echo
###########################################
$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];
$PHP_SELF=$_SERVER['PHP_SELF'];


$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];




if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
{
    $referaall_url=base64_encode("kpi-report");
    header("Location: login.php?refereer=$referaall_url");
    /* Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
     Header("HTTP/1.0 401 Unauthorized");
     echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";*/
    exit;
}
###########################################

$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];


$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);


$short_break_pause_codes=array('MTG','TRG','CPB','BRK','OUT');

 $call_flow_sql = "select vl.user,vl.server_ip,vl.extension,vl.status,vl.campaign_id,vl.last_call_time,va.sub_status,va.event_time from vicidial_live_agents vl left join vicidial_agent_log va on vl.agent_log_id=va.agent_log_id and vl.user=va.user where vl.status='PAUSED' and va.sub_status in ('MTG','TRG','CPB','BRK','OUT') and date(va.event_time)=CURDATE()  and DATE_ADD(va.event_time, INTERVAL 10 MINUTE) <= NOW() ";
//$call_flow_sql = "select vl.user,vl.server_ip,vl.extension,vl.status,vl.campaign_id,vl.last_call_time,va.sub_status,va.event_time from vicidial_live_agents vl left join vicidial_agent_log va on vl.agent_log_id=va.agent_log_id and vl.user=va.user where vl.status='PAUSED' and va.sub_status in ('MTG','TRG','CPB','BRK','OUT')  ";


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
    <title>KPI Dash board</title>
</head>
<script language="JavaScript" src="calendar_db.js"></script>
<link rel="stylesheet" href="calendar.css">

<body>

<?php
# require("admin_header.php");
require("top-menu.php");




?>

<br><TABLE width='100%'><TR><TD>
            <div class="col-md-12"><div class="panel panel-default"><div class="panel-heading clickable"><h3 class="panel-title"><b>Short Break Greator than 10 Minutes</b>
                            <span class="pull-right"><i class="glyphicon glyphiconoo-minus"></i></span></h3></div><div class="panel-body" style="display: block;"><table class="table" width="100%" cellspacing="0" cellpadding="1" >
<thead><tr>
                                <td class="td_padding"><font size="2"># </font></td>
                                <td class="td_padding"><font size="2">User </font></td>
                                <td class="td_padding"><font size="2"> Server Ip</font></td>
                                <td class="td_padding"><font size="2"> Extension</font></td>
                                <td class="td_padding"><font size="2"> Status</font></td>
                                <td class="td_padding"><font size="2"> Pause Code</font></td>
                                <td class="td_padding"><font size="2">Campaign Id</font></td>
                                <td class="td_padding"><font size="2">Last Call Time</font></td>
                                <td class="td_padding"><font size="2">Pause Time</font></td>

</tr>
</thead>


                            <tbody id="table_1" class="table-1"><tr>
                        <?php




		$c=0;
                $call_flow_result = mysql_query($call_flow_sql);
                $result= mysql_affected_rows();
                while ($call_flow_row = mysql_fetch_array($call_flow_result))
                {


                        $user = $call_flow_row['user'];
                        $server_ip = $call_flow_row['server_ip'];
                        $extension = $call_flow_row['extension'];
                        $status = $call_flow_row['status'];
                        $campaign_id = $call_flow_row['campaign_id'];
                        $pause_code = $call_flow_row['sub_status'];
                        $last_call_time = $call_flow_row['last_call_time'];
                        $event_time = $call_flow_row['event_time'];


                    ?>
                    <tr>
                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $c+1;?></td>
                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $user;?></td>
                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $server_ip;?></td>
                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $extension;?></td>
                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $status;?></td>
                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $pause_code;?></td>

                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $campaign_id;?></td>

                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $last_call_time;?></td>

                        <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $event_time;?></td>


                    </tr>

                    <?php
                    $c++;
                }
	?>



                            </tbody>
                        </table>
                        </div></div></div>

        </td>
    </tr>
</table>

<TABLE width='100%'><TR><TD>
            <div class="col-md-12"><div class="panel panel-default"><div class="panel-heading clickable"><h3 class="panel-title"><b>Calls in Queue</b>
                            <span class="pull-right"><i class="glyphicon glyphiconoo-minus"></i></span></h3></div><div class="panel-body" style="display: block;"><table class="table" width="100%" cellspacing="0" cellpadding="1" >
                            <thead><tr>
                                <td class="td_padding"><font size="2"># </font></td>

                                <td class="td_padding"><font size="2"> Server Ip</font></td>
                                <td class="td_padding"><font size="2"> Campaign Id</font></td>

                                <td class="td_padding"><font size="2"> Phone Number</font></td>

                                <td class="td_padding"><font size="2"> Call Time</font></td>


                            </tr>
                            </thead>


                            <tbody id="table_2" class="table-2"><tr>
                                <?php
                                $call_queue_sql = "select * from vicidial_auto_calls where status='LIVE'   ";




                                $k=0;
                                $call_queue_result = mysql_query($call_queue_sql);
                                $queue_result= mysql_affected_rows();
                                while ( $queue_result_row = mysql_fetch_array($call_queue_result))
                                {



                                $server1_ip = $queue_result_row['server_ip'];
                                $phone1_number = $queue_result_row['phone_number'];

                                $campaign1_id = $queue_result_row['campaign_id'];

                                $call1_time = $queue_result_row['call_time'];



                                ?>
                            <tr>
                                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $k+1;?></td>
                                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $server1_ip;?></td>
                                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $campaign1_id;?></td>
                                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $phone1_number;?></td>
                                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $call1_time;?></td>


                            </tr>

                            <?php
                            $k++;
                            }
                            ?>



                            </tbody>
                        </table>
                    </div></div></div>

        </td>
    </tr>
</table>



</body>
</html>
<script type="text/javascript">
    $(document).ready(function() {
      //  getAgentCounts();
        setInterval(getAgentCounts, 30000);
//getCounts();
    });

    function getAgentCounts(){


        $.ajax({
            url: 'ajax_kpi.php',
            data: {

            },
            error: function() {
                //  alert('An error has occurred to delete same process lead');
            },
            success: function(data) {
                // console.log(data);
                var obj = jQuery.parseJSON(data);

                $("#table_1").html(obj.break_data);
                $("#table_2").html(obj.queue_data);


              // console.log(obj);
            },
            type: 'post'
        });
    }
</script>
