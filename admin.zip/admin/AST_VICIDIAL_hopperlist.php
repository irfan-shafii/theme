<?php 
# AST_VICIDIAL_hopperlist.php
# 
# Copyright (C) 2012  Matt Florell <vicidial@gmail.com>    LICENSE: AGPLv2
#
# CHANGES
#
# 60619-1654 - Added variable filtering to eliminate SQL injection attack threat
#            - Added required user/pass to gain access to this page
# 70115-1614 - Added ALT field for vicidial_hopper alt_dial column
# 71029-0852 - Added list_id to the output
# 71030-2118 - Added priority to display
# 90508-0644 - Changed to PHP long tags
# 91023-1540 - Changed to only show hopper status of READY
# 101111-1253 - Added source field
# 111103-1207 - Added admin_hide_phone_data and admin_hide_lead_data options
# 120210-1218 - Added vendor_lead_code to output
# 120221-0059 - Added User Group restriction settings
#

require("dbconnect.php");

$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["DB"]))					{$DB=$_GET["DB"];}
	elseif (isset($_POST["DB"]))		{$DB=$_POST["DB"];}
if (isset($_GET["group"]))				{$group=$_GET["group"];}
	elseif (isset($_POST["group"]))		{$group=$_POST["group"];}
if (isset($_GET["submit"]))				{$submit=$_GET["submit"];}
	elseif (isset($_POST["submit"]))	{$submit=$_POST["submit"];}
if (isset($_GET["SUBMIT"]))				{$SUBMIT=$_GET["SUBMIT"];}
	elseif (isset($_POST["SUBMIT"]))	{$SUBMIT=$_POST["SUBMIT"];}

$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 6 and view_reports='1' and modify_campaigns='1';";
if ($DB) {echo "|$stmt|\n";}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
	{
    Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
    exit;
	}

$stmt="SELECT full_name,user_group,admin_hide_lead_data,admin_hide_phone_data from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$LOGfullname =				$row[0];
$LOGuser_group =			$row[1];
$LOGadmin_hide_lead_data =	$row[2];
$LOGadmin_hide_phone_data =	$row[3];

$NOW_DATE = date("Y-m-d");
$NOW_TIME = date("Y-m-d H:i:s");
$STARTtime = date("U");
if (!isset($group)) {$group = '';}
if (!isset($query_date)) {$query_date = $NOW_DATE;}
if (!isset($server_ip)) {$server_ip = '10.10.10.15';}

$stmt="SELECT allowed_campaigns,allowed_reports,admin_viewable_groups,admin_viewable_call_times from vicidial_user_groups where user_group='$LOGuser_group';";
if ($DB) {$HTML_text.="|$stmt|\n";}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$LOGallowed_campaigns =			$row[0];
$LOGallowed_reports =			$row[1];
$LOGadmin_viewable_groups =		$row[2];
$LOGadmin_viewable_call_times =	$row[3];

$LOGallowed_campaignsSQL='';
$whereLOGallowed_campaignsSQL='';
if ( (!eregi("-ALL",$LOGallowed_campaigns)) )
	{
	$rawLOGallowed_campaignsSQL = preg_replace("/ -/",'',$LOGallowed_campaigns);
	$rawLOGallowed_campaignsSQL = preg_replace("/ /","','",$rawLOGallowed_campaignsSQL);
	$LOGallowed_campaignsSQL = "and campaign_id IN('$rawLOGallowed_campaignsSQL')";
	$whereLOGallowed_campaignsSQL = "where campaign_id IN('$rawLOGallowed_campaignsSQL')";
	}
$regexLOGallowed_campaigns = " $LOGallowed_campaigns ";


$stmt="select campaign_id,campaign_name from vicidial_campaigns $whereLOGallowed_campaignsSQL order by campaign_id;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$campaigns_to_print = mysql_num_rows($rslt);
$i=0;
while ($i < $campaigns_to_print)
	{
	$row=mysql_fetch_row($rslt);
	$campaign_id[$i] =$row[0];
	$campaign_name[$i] =$row[1];
	$i++;
	}
?>

<HTML>
<HEAD>
<STYLE type="text/css">
<!--
   .green {color: white; background-color: green}
   .red {color: white; background-color: red}
   .blue {color: white; background-color: blue}
   .purple {color: white; background-color: purple}
-->
 </STYLE>

<?php 
##### BEGIN Set variables to make header show properly #####
$ADD =					'100';
$hh =					'lists';
$LOGast_admin_access =	'1';
$SSoutbound_autodial_active = '1';
$ADMIN =				'admin.php';
$page_width='770';
$section_width='750';
$header_font_size='3';
$subheader_font_size='2';
$subcamp_font_size='2';
$header_selected_bold='<b>';
$header_nonselected_bold='';
$lists_color =		'#FFFF99';
$lists_font =		'BLACK';
$lists_color =		'#E6E6E6';
$subcamp_color =	'#C6C6C6';
##### END Set variables to make header show properly #####
#require("admin_header.php");
require("top-menu.php");

echo "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=utf-8\">\n";
echo "<TITLE>Hopper List Report</TITLE></HEAD><BODY BGCOLOR=WHITE marginheight=0 marginwidth=0 leftmargin=0 topmargin=0>\n";

	$short_header=1;

	#require("admin_header.php");
echo "<br><TABLE CELLPADDING=1 CELLSPACING=0 width='100%' ><TR><TD>";
echo "<center><TABLE width='100%'><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=WHITE SIZE=2>";
echo "<div class='panel panel-success'>";
echo "<FORM ACTION=\"$PHP_SELF\" METHOD=GET>\n";
echo "<TABLE BORDER=0 CELLSPACING=1 class='table'><tr>";
echo "<TABLE BORDER=0 class='table'><tr bgcolor='#D4D0B3' style='color:black;'>";
echo "<td align='center'>Campaign</td>";
echo "<td align='center'></td>";
echo "</tr></div>";
echo "<tr><td></td></tr>";
echo "<tr bgcolor='#E8E6DA'>";
echo "<td align='center'>";
echo "<SELECT SIZE=1 NAME=group>\n";
$o=0;
while ($campaigns_to_print > $o)
	{
	if ($campaign_id[$o] == $group) {echo "<option selected value=\"$campaign_id[$o]\">$campaign_id[$o] - $campaign_name[$o]</option>\n";}
	else {echo "<option value=\"$campaign_id[$o]\">$campaign_id[$o] - $campaign_name[$o]</option>\n";}
	$o++;
	}
echo "</SELECT></td>";
echo "<td align='center'><INPUT TYPE=SUBMIT NAME=SUBMIT VALUE=SUBMIT class='btn btn-orange'></td>";
#echo " &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href=\"./admin.php?ADD=34&campaign_id=$group\">MODIFY</a> \n";
echo "</tr></table></div></table>";
echo "</FORM>";

echo "<PRE><FONT SIZE=2>";

echo "<TABLE width='100%'><TR><TD>";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
echo "<div class='panel panel-default' style='margin:0 0%;'>";
if (!$group)
	{
		#echo "\n\n";
		#echo "PLEASE SELECT A CAMPAIGN ABOVE AND CLICK SUBMIT\n";
	}
	else
	{
		echo "<table class='table report-heading' ><tr><td class='heading-orange' align='center'><b>Live Current Hopper List</b></td><td style='border-top:none; width:1px;'></td><td class='heading-black'>$NOW_TIME</td><tr></table>";
		#echo "Live Current Hopper List                      $NOW_TIME\n";
		echo "<div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>";
		echo "<tr style='background-color:#F7F5F0' >";
#		echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><b>Totals</b></font></a></td></tr>";

	#echo "\n";
	#echo "---------- TOTALS\n";
	$stmt="select count(*) from vicidial_hopper where campaign_id='" . mysql_real_escape_string($group) . "' $LOGallowed_campaignsSQL;";
	$rslt=mysql_query($stmt, $link);
	if ($DB) {echo "$stmt\n";}
	$row=mysql_fetch_row($rslt);

	$TOTALcalls =	sprintf("%10s", $row[0]);

#	echo "<tr>";
#	echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">Total leads in hopper right now:       $TOTALcalls</td></tr></table></div></table><br>";

#	echo "Total leads in hopper right now:       $TOTALcalls\n";


	##############################
	#########  LEAD STATS


echo "<br><TABLE width='100%'><TR><TD>";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
echo "<div class='panel panel-default' style='margin:0 0%;'>";
echo "<table class='table report-heading' ><tr><td class='heading-orange' align='center'><b>Total leads in hopper right now:       $TOTALcalls</b></td><tr></table>";
echo "<div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>";
echo "<br><tr style='background-color:#d4d0b3' >";

#	echo "\n";
#	echo "---------- LEADS IN HOPPER\n";
#	echo "+------+--------+-----------+------------+------------+-------+--------+-------+--------+-------+-------+----------------------+\n";
#	echo "|ORDER |PRIORITY| LEAD ID   | LIST ID    | PHONE NUM  | STATE | STATUS | COUNT | GMT    | ALT   | SOURCE| VENDOR LEAD CODE     |\n";
#	echo "+------+--------+-----------+------------+------------+-------+--------+-------+--------+-------+-------+----------------------+\n";

echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Order</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Priority</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Lead ID</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>List ID</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Phone Number</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>State</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Status</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Count</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>GMT</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>ALT</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Source</b></font></td>";
echo"<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Vendor Lead Code</b></font></td></tr>";

	$stmt="select vicidial_hopper.lead_id,phone_number,vicidial_hopper.state,vicidial_list.status,called_count,vicidial_hopper.gmt_offset_now,hopper_id,alt_dial,vicidial_hopper.list_id,vicidial_hopper.priority,vicidial_hopper.source,vicidial_hopper.vendor_lead_code from vicidial_hopper,vicidial_list where vicidial_hopper.campaign_id='" . mysql_real_escape_string($group) . "' and vicidial_hopper.status='READY' and vicidial_hopper.lead_id=vicidial_list.lead_id $LOGallowed_campaignsSQL order by priority desc,hopper_id limit 5000;";
	$rslt=mysql_query($stmt, $link);
	if ($DB) {echo "$stmt\n";}
	$users_to_print = mysql_num_rows($rslt);
	$i=0;
	while ($i < $users_to_print)
		{
		$row=mysql_fetch_row($rslt);

		if ($LOGadmin_hide_phone_data != '0')
			{
			if ($DB > 0) {echo "HIDEPHONEDATA|$row[1]|$LOGadmin_hide_phone_data|\n";}
			$phone_temp = $row[1];
			if (strlen($phone_temp) > 0)
				{
				if ($LOGadmin_hide_phone_data == '4_DIGITS')
					{$row[1] = str_repeat("X", (strlen($phone_temp) - 4)) . substr($phone_temp,-4,4);}
				elseif ($LOGadmin_hide_phone_data == '3_DIGITS')
					{$row[1] = str_repeat("X", (strlen($phone_temp) - 3)) . substr($phone_temp,-3,3);}
				elseif ($LOGadmin_hide_phone_data == '2_DIGITS')
					{$row[1] = str_repeat("X", (strlen($phone_temp) - 2)) . substr($phone_temp,-2,2);}
				else
					{$row[1] = preg_replace("/./",'X',$phone_temp);}
				}
			}
		if ($LOGadmin_hide_lead_data != '0')
			{
			if ($DB > 0) {echo "HIDELEADDATA|$row[2]|$LOGadmin_hide_lead_data|\n";}
			if (strlen($row[2]) > 0)
				{$state_temp = $row[2];   $row[2] = preg_replace("/./",'X',$state_temp);}
			if (strlen($row[11]) > 0)
				{$vlc_temp = $row[11];   $row[11] = preg_replace("/./",'X',$vlc_temp);}
			}

		$FMT_i =		sprintf("%-4s", $i);
		$lead_id =		sprintf("%-9s", $row[0]);
		$phone_number =	sprintf("%-10s", $row[1]);
		$state =		sprintf("%-5s", $row[2]);
		$status =		sprintf("%-6s", $row[3]);
		$count =		sprintf("%-5s", $row[4]);
		$gmt =			sprintf("%-6s", $row[5]);
		$hopper_id =	sprintf("%-6s", $row[6]);
		$alt_dial =		sprintf("%-5s", $row[7]);
		$list_id =		sprintf("%-10s", $row[8]);
		$priority =		sprintf("%-6s", $row[9]);
		$source =		sprintf("%-5s", $row[10]);
		$vendor_lead_code =	sprintf("%-20s", $row[11]);

		if ($DB) {
			#	echo "| $FMT_i | $priority | $lead_id | $list_id | $phone_number | $state | $status | $count | $gmt | $hopper_id |\n";
				echo "<tr>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$FMT_i</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"> $priority </td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$lead_id</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$list_id</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$phone_number</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$state</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$status</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$count</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$gmt</td>";
		                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$hopper_id</td></tr>";

	                 }
		else 	{
			#	echo "| $FMT_i | $priority | $lead_id | $list_id | $phone_number | $state | $status | $count | $gmt | $alt_dial | $source | $vendor_lead_code |\n";
	                        echo "<tr>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$FMT_i</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"> $priority </td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$lead_id</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$list_id</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$phone_number</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$state</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$status</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$count</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$gmt</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$alt_dial</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$source</td>";
                                echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">$vendor_lead_code</td></tr>";
				
			}
		$i++;
		}
	 echo "</table></div></table>";

#	echo "+------+--------+-----------+------------+------------+-------+--------+-------+--------+-------+-------+----------------------+\n";

	}


?>

<TABLE width='100%'><TR><TD>
<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
<div class='panel panel-default' style='margin:0 0%;'>
<table class='table report-heading' ><tr><td class='heading-orange td_padding' align='left'><b>Sources</b></td><tr></table>
<div class='panel-body' style='padding:0;'><table width='100%' class='table' cellspacing=0 cellpadding=1>
<tr style='background-color:#E8E6DA' >
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">A = Auto-alt-dial</td>
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">C = Scheduled Callbacks</td>
</tr>

<tr style='background-color:#F7F5F0' >
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">N = Xth New lead order</td>
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"> P = Non-Agent API hopper load</td>
</tr>

<tr style='background-color:#E8E6DA' >
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">Q = No-hopper queue insert </td>
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">R = Recycled leads</td>
</tr>

<tr style='background-color:#F7F5F0' >
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">S = Standard hopper load</td>
<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"></td>
</tr>
</table></div></table>

</PRE>

</TD></TR></TABLE>

</BODY></HTML>
