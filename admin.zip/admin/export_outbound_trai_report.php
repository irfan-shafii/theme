<?php 
include('dbconnect.php'); 
require('functions.php');

$query_date_BEGIN = $_GET['date_from'];
$query_date_END = $_GET['date_to'];
$group = $_GET['group'];
$today = date("Y-m-d");
header('Content-Type: text/csv; charset=utf-8');
header("Content-Disposition: attachment; filename=outbound_trai_report_$today.csv");
$output = fopen('php://output', 'w');
?>
<?php

	$where = '1';
	$where1 = '1';	
	if($group == "" )
        {
		 $call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`uniqueid`,status,phone_number_call_date  FROM `vicidial_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and user != 'VDAD'  and {$where} ";

        }
        else{
	$call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`uniqueid`,status,phone_number,call_date  FROM `vicidial_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and campaign_id='$group'and user != 'VDAD'  and {$where} ";

        }
	fputcsv($output, array('','','','Outbound TRAI Report','','',''));
        $call_flow_result = mysql_query($call_flow_sql);						
	$num = mysql_num_rows($result);	

	fputcsv($output, array('Row','Agent Name','Start DateTime','Phone Number','Outgoing','Talk Time','Wrapup Time','Disposition'));
	  $i=1;
                $c=1;
                $total_sec=0;
                $time_BEGIN = "00:00:00";
                $time_END = "23:59:59";
                $query_date_BEGIN = "$date_from $time_BEGIN";
                $query_date_END = "$date_to $time_END";
                $call_flow_result = mysql_query($call_flow_sql);
                $result= mysql_affected_rows();
                while ($call_flow_row = mysql_fetch_row($call_flow_result))
                {
                                $uniqueid = $call_flow_row['3'];
                                $phone_number = $call_flow_row['5'];
                                $group = $call_flow_row['1'];
                                $datetime = $call_flow_row['6'];
                                $user = $call_flow_row['0'];
                                #####Query to get Agent Name --Ketan Solanki    
                                $sql_full_name = 'SELECT full_name  FROM vicidial_users WHERE user LIKE CONVERT(_utf8 "'.$user.'" USING latin1) COLLATE latin1_swedish_ci';
                                $result_full_name = mysql_query($sql_full_name);
                                $row_full_name = mysql_fetch_row($result_full_name);
                                $user_name = $row_full_name[0];
                                ######Query To get Full Disposition
                                $status = $call_flow_row['4'];
                                # $sql_full_status = 'SELECT status_name  FROM vicidial_statuses  WHERE status  LIKE CONVERT(_utf8 "'.$status.'" USING latin1) COLLATE latin1_swedish_ci ';
                                 $sql_full_status = '(SELECT status_name  FROM vicidial_statuses  WHERE status  LIKE CONVERT(_utf8 "'.$status.'" USING latin1) COLLATE latin1_swedish_ci) UNION (SELECT status_name  FROM vicidial_campaign_statuses  WHERE status  LIKE CONVERT(_utf8 "'.$status.'" USING latin1) COLLATE latin1_swedish_ci)';
                                $result_full_status = mysql_query($sql_full_status);
                                $row_full_status = mysql_fetch_row($result_full_status);
                                $status_name = $row_full_status[0];
                               $sec = $call_flow_row['2'];
                                #$que_sec = $call_flow_row['7'];
                                $status = $call_flow_row['4'];
                                $action = $call_flow_row['6'];
                                $row = $i;
 if($pre_uniqueid==$uniqueid)
                                {
                                        $uniqueid='';
                                        $phone_number='';
                                        $ivr='';
                                        $datetime='';
                                        $row='';
                                        $i--;
                                        $c++;
                                        $total_sec = $total_sec + $sec;
                                }
                                elseif($pre_uniqueid!=$uniqueid)
                                {
                                        $pre_uniqueid='';
                                        $c=1;
                                        $total_sec = $sec;
                                }
                                ### Print total sec 
                                $print_total_sec = $total_sec;
                                $print_total_sec = sec_convert($print_total_sec,'H');
                                $sec = sec_convert($sec,'H');
				####### Get Dispo time,Hold Time
                        $sql_get_dispo ="select dispo_sec from vicidial_agent_log where uniqueid='$uniqueid'";
                        $result_get_dispo = mysql_query($sql_get_dispo);
                        if($row_get_dispo = mysql_fetch_array($result_get_dispo))
                        {
                                $dispo_sec = $row_get_dispo['dispo_sec'];
                                $dispo_sec = sec_convert($dispo_sec,'H');
                        }
                        else{
                                $dispo_sec = "00:00";
                        }
		
		fputcsv($output, array($row,$user_name,$datetime,$phone_number,$group,$sec,$dispo_sec,$status_name));	
        	$i++;
		}
?>
