<?php
session_start();
ob_start();
unset($_SESSION['username']);
unset($_SESSION['password']);
//$referal_url=$_SERVER['HTTP_REFERER'];
$short_header=1;
$message="";
header ("Content-type: text/html; charset=utf-8");
$agentReport = true;
require("dbconnect.php");
require("functions.php");


if(isset($_REQUEST['refereer'])) {

    $referaall_url=base64_decode($_REQUEST['refereer']);
    $referaall_url=$referaall_url.".php";
    setcookie('origin_ref', $referaall_url);
} else if(!isset($_COOKIE['origin_ref'])) {

    setcookie('origin_ref', "admin.php");
}


if(isset($_POST['submit'])) {
    $message="";
    $var = $_COOKIE['origin_ref'];
    // echo "<pre>";print_r($_POST);die;

    $PHP_AUTH_USER=$_POST['uname'];
    $PHP_AUTH_PW=$_POST['psw'];
    $PHP_SELF=$_SERVER['PHP_SELF'];
#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
    $stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
    $rslt=mysql_query($stmt, $link);
    if ($DB) {echo "$stmt\n";}
    $ss_conf_ct = mysql_num_rows($rslt);
    if ($ss_conf_ct > 0)
    {
        $row=mysql_fetch_row($rslt);
        $non_latin =                                            $row[0];
        $SSoutbound_autodial_active =           $row[1];
        $user_territories_active =                      $row[2];
    }
##### END SETTINGS LOOKUP #####echo
###########################################

    $stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
    if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
    $rslt=mysql_query($stmt, $link);
    $row=mysql_fetch_row($rslt);
    $auth=$row[0];
    if($auth) {

        $_SESSION['username']=$PHP_AUTH_USER;
        $_SESSION['password']=$PHP_AUTH_PW;
        header("Location: $var");

    } else {

        $message="Invalid Username /Password";
    }


}


?>


<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/dev.css" />
   <!-- <style>
        body {font-family: Arial, Helvetica, sans-serif;}
        form {border: 3px solid #f1f1f1;}
        #content {
            width: 50%;
            float: inherit;

            vertical-align: middle;
            margin: 50px auto;
        }
        .error{
            color: red;
            font-weight: bold;
        }

        input[type=text], input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
        }

        .cancelbtn {
            width: auto;
            padding: 10px 18px;
            background-color: #f44336;
        }

        .imgcontainer {
            text-align: center;
            margin: 24px 0 12px 0;
        }

        img.avatar {
            width: 40%;
            border-radius: 50%;
        }

        .container {
            padding: 16px;
        }

        span.psw {
            float: right;
            padding-top: 16px;
        }

        /* Change styles for span and cancel button on extra small screens */
        @media screen and (max-width: 300px) {
            span.psw {
                display: block;
                float: none;
            }
            .cancelbtn {
                width: 100%;
            }
        }
    </style>-->
</head>
<body>
<!--<div id="content">
    <h2>Centrix Plus Administration</h2>

    <form  method="post" name="form1" action="login.php">
        <div class="imgcontainer">
            <img src="images/centrix-logo.png" alt="Logo" >
        </div>

        <div class="container">
            <div class="error"><?php // if(!empty($message)) {echo $message; } ?></div>
            <label for="uname"><b>Username</b></label>
            <input type="text" placeholder="Enter Username" name="uname" required>

            <label for="psw"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="psw" required>

            <button type="submit" name="submit">Login</button>

        </div>

        <div class="container" style="background-color:#f1f1f1">
            <button type="reset" class="cancelbtn">Cancel</button>

        </div>
    </form>
</div>-->
<div class="loginbg logoinidbg">

    <div class="main loginform">
        <div class="loginmain leftside">
            <div class="clear"></div>
            <div class="logfields whitebox">
                <div class="logleft leftblock">
                    <div class="whitefield frm_input isempty">
                        <div class="head_text headtext h_text"></div>

                        <!-- Id Field Block : Here -->
                        <!-- Login Radio Button:Here -->
                        <div class="loginRadioBtn" id="radio_select">
                            <div class="loginAs">Centrix Plus Administration</div>


                            <div class="trackologo"><img src="images/centrix-logo.png"></div>

                            <span style="color:red"> <?php  if(!empty($message)) {echo $message; }  ?></span>
                        </div>

                        <form  method="post" name="form1" action="login.php">



                            <div class="fields inputfield loginid loginpage" id="E_field_login" >



                                <div class="group">

                                    <input type="text" id="uname" name='uname'   class="typetxt" required="required">


                                    <span class="bar">


                                </span>

                                    <label>

                                        Please Enter User Name

                                    </label>

                                </div>

                                <div class="group">

                                    <input type="password" id="psw" name='psw'   class="typetxt" required="required">

                                    <span class="bar"> </span>

                                    <label>Please Enter Password</label>

                                </div>



                                <input type="submit" name="submit" value="Login" class="button loginbtn loginAction"/> <span id="LogiNReseT"></span>

                            </div>
                            <!-- Id Field Block : End -->
                            <!-- Forgot ID Block :Here -->



                        </form>


                    </div>
                </div>
            </div>

        </div>
        <div class="loginmain1 rightside">
            <div class="clear"></div>
            <div class="trackoside">
                <div class="trackologo"><img src="images/hosted-voip-icon.png" ></div>
                <div class="deshboardimg"><img src="images/modal.png" height="320"></div>

            </div>
        </div>
    </div>


</div>
</body>
</html>
