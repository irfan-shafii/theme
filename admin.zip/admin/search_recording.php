<?php
session_start();
ob_start();
# user_stats.php
# 
# Copyright (C) 2010  Matt Florell <vicidial@gmail.com>    LICENSE: AGPLv2
#
# CHANGES
#
# 60619-1743 - Added variable filtering to eliminate SQL injection attack threat
# 61201-1136 - Added recordings display and changed calls to time range with 10000 limit
# 70118-1605 - Added user group column to login/out and calls lists
# 70702-1231 - Added recording location link and truncation
# 80117-0316 - Added vicidial_user_closer_log entries to display
# 80501-0506 - Added Hangup Reason to logs display
# 80523-2012 - Added vicidial timeclock records display
# 80617-1402 - Fixed timeclock total logged-in time
# 81210-1634 - Added server recording display options
# 90208-0504 - Added link to multi-day report and fixed call status summary section
# 90305-1226 - Added user_call_log manual dial logs
# 90310-0734 - Added admin header
# 90508-0644 - Changed to PHP long tags
# 90524-2009 - Changed time display to use functions.php
# 91130-2037 - Added user closer log manager flag display
# 100203-1008 - Added agent activity log section
# 100216-0042 - Added popup date selector
#
header ("Content-type: text/html; charset=utf-8");

$agentReport = true;

require("dbconnect.php");
require("functions.php");
?>
<script language="javascript">
function checkAll(){
 for (var i=0;i<document.forms[1].elements.length;i++)
    {
            var e=document.forms[1].elements[i];
            if ((e.name != 'allbox') && (e.type=='checkbox'))
            {
                    e.checked=document.forms[1].allbox.checked;
            }
        }
}

function setDownloadAction() {
document.form1.action = "download.php";
document.form1.submit();
}

function setDeleteAction() {

if(confirm("Are you sure want to delete these rows?")) {
document.form1.action = "delete.php";
document.form1.submit();
}

}
</script>
<?
#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
	{
	$row=mysql_fetch_row($rslt);
	$non_latin =						$row[0];
	$SSoutbound_autodial_active =		$row[1];
	$user_territories_active =			$row[2];
	}
##### END SETTINGS LOOKUP #####echo
###########################################
$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];

//$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
//$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["date_from"]))				{$begin_date=$_GET["date_from"];}
	elseif (isset($_POST["date_from"]))	{$begin_date=$_POST["date_from"];}
if (isset($_GET["date_to"]))				{$end_date=$_GET["date_to"];}
	elseif (isset($_POST["date_to"]))		{$end_date=$_POST["date_to"];}
if (isset($_GET["user"]))					{$user=$_GET["user"];}
	elseif (isset($_POST["user"]))			{$user=$_POST["user"];}
if (isset($_GET["campaign"]))				{$campaign=$_GET["campaign"];}
	elseif (isset($_POST["campaign"]))		{$campaign=$_POST["campaign"];}
if (isset($_GET["DB"]))						{$DB=$_GET["DB"];}
	elseif (isset($_POST["DB"]))			{$DB=$_POST["DB"];}
if (isset($_GET["submit"]))					{$submit=$_GET["submit"];}
	elseif (isset($_POST["submit"]))		{$submit=$_POST["submit"];}
if (isset($_GET["SUBMIT"]))					{$SUBMIT=$_GET["SUBMIT"];}
	elseif (isset($_POST["SUBMIT"]))		{$SUBMIT=$_POST["SUBMIT"];}

$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}

$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
	{
		$referaall_url=base64_encode("search_recording");
		header("Location: login.php?refereer=$referaall_url");
   /* Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";*/
    exit;
	}
else
	{

	if($auth>0)
		{
		$stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
		$rslt=mysql_query($stmt, $link);
		$row=mysql_fetch_row($rslt);
		$LOGfullname=$row[0];

		fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
		fclose($fp);
		}
	else
		{
		fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
		fclose($fp);
		echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
		exit;
		}

	$stmt="SELECT full_name from vicidial_users where user='$user';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$full_name = $row[0];
	}




?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script language="JavaScript" src="calendar_db.js"></script>
<link rel="stylesheet" href="calendar.css">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<title>ADMINISTRATION:Search Recording</title>
<?php


##### BEGIN Set variables to make header show properly #####
$ADD =					'3';
$hh =					'recording';
$LOGast_admin_access =	'1';
$ADMIN =				'index.php';
$page_width='770';
$section_width='770';
$header_font_size='3';
$subheader_font_size='2';
$subcamp_font_size='2';
$header_selected_bold='<b>';
$header_nonselected_bold='';
$users_color =		'#FFFF99';
$users_font =		'BLACK';
$users_color =		'#E6E6E6';
$subcamp_color =	'#C6C6C6';
##### END Set variables to make header show properly #####

#require("admin_header.php");
require("top-menu.php");

$filter = array();

$filter['vicidial_users.user'] = mysql_real_escape_string($_POST['agent_name']);
//$filter['length_in_sec'] = intval($_POST['call_length']);
//$filter['vicidial_log.lead_id'] = intval($_POST['lead_id']);
$filter['date_from'] = $_POST['date_from'];
$filter['date_to'] = $_POST['date_to'];
$filter['phone_number'] = mysql_real_escape_string($_POST['phone_number']);
$filter['vicidial_log.status'] = mysql_real_escape_string($_POST['status']);

//Mehul
$filter['vicidial_log.campaign_id'] = $_POST['campaign_id'];
$filter['vicidial_log.list_id'] = $_POST['list_id'];

$where = '1';
foreach ($filter as $field => $value)
{
    if (strlen($value) && $value)
    {
        if ($field == 'vicidial_log.status' || $field == 'vicidial_users.user')
	{
            $where .= ' AND ' . $field . ' = "' . $value . '"';
        }
	else if ($field == 'date_from')
	{
	    $where .= ' AND DATE_FORMAT(start_time, "%Y-%m-%d") >= "' . date('Y-m-d', strtotime($value)) . '"';
	}
	else if ($field == 'date_to')
	{
	    $where .= ' AND DATE_FORMAT(start_time, "%Y-%m-%d") <= "' . date('Y-m-d', strtotime($value)) . '"';
	}
	else if ($field == 'vicidial_log.campaign_id')
	{
	    $where .= ' AND ' . $field . ' = "' . $value . '"';
	}
	else if ($field == 'vicidial_log.list_id')
	{
	    $where .= ' AND ' . $field . ' = "' . $value . '"';
	}
	else
	{
	    if (is_int($value))
	    {
		$where .= ' AND ' . $field . ' = ' . $value;
	    }
	    else
	    {
		$where .= ' AND ' . $field . ' LIKE "%' . $value . '%"';
	    }
	}
    }
}
?>
<?php 
echo "<center><TABLE width='50%'><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
echo "<div class='panel panel-default' style='margin:0 0%;'>";
echo "<div class='panel-heading'><h3 class='panel-title'> Search Recording </h3></div>";
echo "<div class='panel-body' style='padding:0;'>";
echo "<form action=$PHP_SELF method=POST name=vicidial_report id=vicidial_report><input type='hidden' name='send' value='1' />\n";
echo "<input type=hidden name=DB value=\"$DB\">\n";
echo "<table width='100%' class=\"table\" cellspacing ='0' cellpadding = '1'>";

$users = mysql_query('select * from vicidial_users');
$statuses = mysql_query('select * from vicidial_statuses');
$campaign_names = mysql_query('select campaign_id, campaign_name from vicidial_campaigns');
$list_names = mysql_query('select * from vicidial_lists');

?>
<tr bgcolor=#e8e6da>
	<td align=left class='td_padding'>Date </td>
<td align=left>
    <input type=text name=date_from id=date_from style="width: 100px" value="<?php echo $filter['date_from']?>"> 
    <script language="JavaScript">
        var o_cal = new tcal ({
	        'formname': 'vicidial_report',
	        'controlname': 'date_from'
        });
        o_cal.a_tpl.yearscroll = false;
    </script>
    to <input type=text name=date_to id=date_to style="width: 100px" value="<?php echo $filter['date_to']?>">
    <script language="JavaScript">
    var o_cal = new tcal ({
        'formname': 'vicidial_report',
        'controlname': 'date_to'
    });
    o_cal.a_tpl.yearscroll = false;
</script>
</td></tr>
<tr bgcolor=#f7f5f0>
	<td align=left class='td_padding'>Agent name</td>
	<td align=left>
    <select name=agent_name>
        <option></option>
        <?php while ($user = mysql_fetch_assoc($users)) {
        echo '<option value="' . $user['user'] . '"' . ($user['user'] == $filter['vicidial_users.user'] ? ' selected="selected"': '') . '>' . $user['full_name'] . '</option>';
        }?>
    </select>
</td>
</tr>
<!--<tr><td>Call length</td><td><input type=text name=call_length value="<?php //echo $filter['length_in_sec']?>"></td></tr>
<tr><td>Lead ID</td><td><input type=text name=lead_id value="<?php //echo $filter['vicidial_log.lead_id']?>"></td></tr>-->
<tr bgcolor=#e8e6da>
	<td align=left class='td_padding'>Campaign Name </td>  
  <td align=left>
    <select name=campaign_id>
        <option></option>
        <?php while ($campaign_name = mysql_fetch_assoc($campaign_names)) {
        

        echo '<option value="' . $campaign_name['campaign_id'] . '"' . ($campaign_name['campaign_id'] == $filter['vicidial_log.campaign_id'] ? ' selected="selected"': '') . '>' . $campaign_name['campaign_id']."-".$campaign_name['campaign_name'] . '</option>';
        }?>
    </select>
  </td>
</tr>

<tr bgcolor=#f7f5f0>
	<td align=left class='td_padding'>List Name</td>    
  <td align=left>
    <select name=list_id>
        <option></option>
        <?php while ($list_name = mysql_fetch_assoc($list_names)) {
        echo '<option value="' . $list_name['list_id'] . '"' . ($list_name['list_id'] == $filter['vicidial_log.list_id'] ? ' selected="selected"': '') . '>' . $list_name['list_id']."-".$list_name['list_name'] . '</option>';
        }?>
    </select>
  </td>
</tr>

<tr bgcolor=#e8e6da>	
	<td align=left class='td_padding'>Phone number</td>    
	<td align=left>
		<input type=text name=phone_number value="<?php echo $filter['phone_number']?>">
	</td>
</tr>
<tr bgcolor=#f7f5f0>
	<td align=left class='td_padding'>Status</td>    	
	<td align=left>
    <select name=status>
        <option></option>
        <?php while ($status = mysql_fetch_assoc($statuses)) {
        echo '<option value="' . $status['status'] . '"' . ($status['status'] == $filter['vicidial_log.status'] ? ' selected="selected"': '') . '>' . $status['status_name'] . '</option>';
        }?>
    </select>
</td></tr>
<tr bgcolor=#e8e6da>	
	<td align=center colspan=2>
		<input type=submit name=ubmit value=Submit class='btn btn-orange'>
	</td>
</tr></table></center>
<?php

if ($_POST['send']) {
#echo "</B></TD></TR>\n";

//echo "<TR><TD ALIGN=LEFT COLSPAN=2>\n";

echo "<TR><TD ALIGN=LEFT COLSPAN=2>\n";

echo "<br>\n";
echo "</td></tr></table></center></form>";
//Mehul
echo "<form name='form1' method='POST' action=''>";
##### vicidial recordings for this time period #####

echo "<TABLE width='100%'><TR><TD>\n";	
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
echo "<div class='panel panel-default' style='margin:0 0%;'>";
#echo "<div class='panel-heading'><h3 class='panel-title'> Recordings For This Time Period</h3></div>";
echo "<table class='table report-heading' ><tr><td class='heading-orange' align='center' style='width:300px;'><b>Recordings For This Time Period </b></td><td style='border-top:none;'></td><td class='heading-black'> $begin_date to $end_date &nbsp;&nbsp;&nbsp;<a href='javascript:void(0);' onClick='setDeleteAction();' class='btn btn-orange pull-right'><i class='glyphicon glyphicon-trash'></i></a><a href='javascript:void(0);' onClick='setDownloadAction();' class='btn btn-orange pull-right' style='margin-right:10px;'><i class='glyphicon glyphicon-save'></i></a></td><tr></table><br>";
#echo "<B>RECORDINGS FOR THIS TIME PERIOD: (10000 record limit)</B>\n";
echo "<div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>";
echo "<tr style='background-color:#d4d0b3' >";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><input type='checkbox' value='on' name='allbox' onClick='checkAll();'></font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >#</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Lead</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Date / Time</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Seconds</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >RECID</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >FileName</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Location</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Play</font></td>";
echo "</tr>";


	$stmt="select recording_log.*, vicidial_log.list_id, vicidial_log.campaign_id, start_time as end_time
           from recording_log JOIN vicidial_users ON vicidial_users.user = recording_log.user 
           JOIN vicidial_log ON vicidial_log.uniqueid = recording_log.vicidial_id
           where {$where} order by recording_id desc limit 10000;";

	$rslt=mysql_query($stmt, $link);
	$logs_to_print = mysql_num_rows($rslt);

	
	$u=0;
	while ($logs_to_print > $u) 
		{
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $u))
			{$bgcolor='bgcolor="#E8E6DA"';} 
		else
			{$bgcolor='bgcolor="#F7F5F0"';}

		$play = $row[10];
		$location = $row[11];

		if (strlen($location)>2)
			{
			$URLserver_ip = $location;
			$URLserver_ip = eregi_replace('http://','',$URLserver_ip);
			$URLserver_ip = eregi_replace('https://','',$URLserver_ip);
			$URLserver_ip = eregi_replace("\/.*",'',$URLserver_ip);
			$stmt="select count(*) from servers where server_ip='$URLserver_ip';";
			$rsltx=mysql_query($stmt, $link);
			$rowx=mysql_fetch_row($rsltx);
			
			if ($rowx[0] > 0)
				{
				$stmt="select recording_web_link,alt_server_ip from servers where server_ip='$URLserver_ip';";
				$rsltx=mysql_query($stmt, $link);
				$rowx=mysql_fetch_row($rsltx);
				
				if (eregi("ALT_IP",$rowx[0]))
					{
					$location = eregi_replace($URLserver_ip, $rowx[1], $location);
					$checkbox_location = eregi_replace($URLserver_ip, $rowx[1], $location);
					}
				}
			}

			// abhishek for play recording
			//$play_file = substr($play ,-38);
        	        //$play_location = "/var/spool/asterisk/monitorDONE/".$play_file;
			//shell_exec("/bin/rm -rf /var/www/html/admin/play/*.*");
	               // shell_exec("/bin/cp $play_location  /var/www/html/admin/play/");
			
	
			//Mehul
			
			$path_parts = pathinfo($location);
			$new_location = $path_parts['basename'];

		if (strlen($location)>30)
			{
			  $locat = substr($location,0,27);  $locat = "$locat...";
			  $new_location=$new_location;
			}
		else
			{$locat = $location; $new_location=$new_location;}
		if (eregi("http",$location))
			{$location = "<a href=\"$location\">$locat</a>"; $new_location=$new_location; }
		else
			{$location = $locat;}
		$u++;
		echo "<tr $bgcolor>";
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><input type='checkbox' name='check[]' value='$new_location'></font></td>";
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$u</font></td>";		
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><A HREF=\"admin_modify_lead.php?lead_id=$row[12]\" target=\"_blank\">$row[12]</A></font></td>";
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[4]</font></td>\n";
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[8]</font></td>\n";
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[0]</font></td>\n";
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[10]</font></td>\n";
		echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$location</font></td>\n";
		 if($location!='DELETED')
                {
                        #echo "<td><a href='play.php?filename=$play'> <img src='play.png' width='25' height='25' /> </a></td>";
                        echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=4 color=black FACE=\"Arial,Helvetica\" ><a href='play.php?filename=$play'><i class='glyphicon glyphicon-play-circle'></i></a></font></td>";
                }
               else
                {
                        echo "<td>&nbsp;</td>";
                }

		echo "</tr>\n";

		$tot_rec = $tot_rec + 1;
		}

//Mehul
echo "\n";
#echo "<tr><input type=hidden name=num value='$tot_rec'><td colspan='8' align='center'><input type='button' value='DOWNLOAD' name='download' onClick='setDownloadAction();' class='btn btn-orange'> <input type='button' value='DELETE' name='delete' onClick='setDeleteAction();'class='btn btn-orange' >";
echo "<tr><input type=hidden name=num value='$tot_rec'><td colspan='8' align='center'><a href='javascript:void(0);' onClick='setDownloadAction();' class='btn btn-orange'><i class='glyphicon glyphicon-save '></i></a>&nbsp;&nbsp;<a href='javascript:void(0);' onClick='setDeleteAction();' class='btn btn-orange'><i class='glyphicon glyphicon-trash'></i></a>";
echo "</td></tr>";
echo "</table></table></div></table><BR><BR>";

echo "</form>";

##### vicidial agent outbound user manual calls for this time period #####
echo "<TABLE width='100%'><TR><TD>\n";	
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
echo "<div class='panel panel-default' style='margin:0 0%;'>";
#echo "<div class='panel-heading'><h3 class='panel-title'> Manual Outbound Calls For This Time Period</h3></div>";
echo "<table class='table report-heading' ><tr><td class='heading-orange' align='center' style='width:350px;'><b>Manual Outbound Calls For This Time Period </b></td><td style='border-top:none;'></td><td class='heading-black'> $begin_date to $end_date </td><tr></table><br>";
#echo "<B>MANUAL OUTBOUND CALLS FOR THIS TIME PERIOD: (10000 record limit)</B>\n";
echo "<div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>";
echo "<tr align='center' style='background-color:#d4d0b3' >";//Ketan
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >#</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Date / Time</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Call Type</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Server</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Phone</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Dialed</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Lead</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >CallerID</font></td>";
echo "<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Allias</font></td>";
echo "</tr>";
#echo "<tr><td><font size=1>#</td><td><font size=2>DATE/TIME </td><td align=left><font size=2> CALL TYPE</td><td align=left><font size=2> SERVER</td><td align=left><font size=2> PHONE</td><td align=right><font size=2> DIALED</td>	  <td align=right><font size=2> LEAD</td><td align=right><font size=2> CALLERID</td><td align=right><font size=2> ALIAS</td></tr>\n";

	$stmt="select user_call_log.*
        from user_call_log
        JOIN vicidial_users ON vicidial_users.user = user_call_log.user 
        JOIN vicidial_log ON vicidial_log.lead_id = recording_log.lead_id
         where {$where} order by call_date desc limit 10000;";
	$rslt=mysql_query($stmt, $link);
	$logs_to_print = mysql_num_rows($rslt);

	$u=0;
	while ($logs_to_print > $u) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $u))
			{$bgcolor='bgcolor="#E8E6DA"';} 
		else
			{$bgcolor='bgcolor="#F7F5F0"';}

			$u++;
			echo "<tr $bgcolor>";
			echo "<td><font size=1>$u</td>";
			echo "<td><font size=2>$row[0]</td>";
			echo "<td align=left><font size=2> $row[1]</td>\n";
			echo "<td align=left><font size=2> $row[2]</td>\n";
			echo "<td align=left><font size=2> $row[3] </td>\n";
			echo "<td align=right><font size=2> $row[4] </td>\n";
			echo "<td align=right><font size=2> <A HREF=\"admin_modify_lead.php?lead_id=$row[5]\" target=\"_blank\">$row[5]</A> </td>\n";
			echo "<td align=right><font size=2> $row[6] </td>\n";
			echo "<td align=right><font size=2> $row[7] </td></tr>\n";
	}

#echo "<tr><td colspan='9' align='center'><input type='button' value='DOWNLOAD' name='download' onClick='setDownloadAction();' class='btn btn-orange'> <input type='button' value='DELETE' name='delete' onClick='setDeleteAction();' class='btn btn-orange'></td> </tr>";
echo "</TABLE><BR><BR>\n";
$ENDtime = date("U");

$RUNtime = ($ENDtime - $STARTtime);

echo "\n\n\n<br><br><br>\n\n";

//echo "<font size=0>\n\n\n<br><br><br>\nscript runtime: $RUNtime seconds</font>";
}
?>
</TD></TR><TABLE>
</body>
</html>

<?php
exit;
?>
