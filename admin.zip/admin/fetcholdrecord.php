<?php
$VARDB_server = '192.168.70.20';
//$VARDB_port = '3306';
$VARDB_user = 'cron';
$VARDB_pass = '1234';

$link=mysql_connect("$VARDB_server", "$VARDB_user", "$VARDB_pass");

mysql_select_db("elision");


$stmt="SELECT date(call_date), sec_to_time(time_to_sec(call_date)- time_to_sec(call_date)%(15*60)) as dateintervals,count(*) from vicidial_log where date(call_date) between '2017-07-30' and '2017-12-01' group by dateintervals,date(call_date) order by call_date asc";

$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_array($rslt);

echo "<pre>";print_r($row);die;
/**
 * Created by PhpStorm.
 * User: avdhesh
 * Date: 6/2/18
 * Time: 6:15 PM
 */