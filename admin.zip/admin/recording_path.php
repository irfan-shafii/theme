<?php

$recording_path="/var/spool/asterisk/monitorDONE/ORIG/";
$dirPath=getcwd();
//$recording_path="/var/spool/asterisk/monitorDONE/ORIG/";
?>
