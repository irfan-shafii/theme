<?php
require('/var/www/html/admin/dbconnect.php');
$now = date('Y-m-d H:i:s', time());
$tenlessnow = date('Y-m-d H:i:s', strtotime('-10 minutes'));
$sql = "SELECT lead_id,called_since_last_reset FROM vicidial_list WHERE list_id='999' AND status IN ('DROP','TIMEOT') AND modify_date >='".$tenlessnow."' AND modify_date <='".$now."'"; 
#echo $sql."\n";exit;
$result = mysql_query($sql);					
#$c=0;	
while ($row = mysql_fetch_array($result))
{
	#$c++;
	$called = $row[1];####Value retrived as Y or N
	$id = $row[0];####Lead ID value
	#echo $id."\n"; 
	if($called == 'Y')
	{
		$sql_update = "UPDATE vicidial_list SET called_since_last_reset='N' WHERE lead_id='$id';";
		#echo $sql_update;exit;
		$result_update = mysql_query($sql_update);						
	}
	
}
#echo $c;
?>
