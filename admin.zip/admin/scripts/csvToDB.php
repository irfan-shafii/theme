<?php
$Current_time = date('Y-m-d h:i:s');
global $Current_time, $file_path, $time_diff, $output, $prev_output_count;
//$Current_time = date('2014-02-14 11:11:47');
	
//$Current_time = date('2013-12-24 13:32:14');	
//$file_path = "/var/log/asterisk/cdr-csv/Master-18-feb.csv";
$file_path = "/var/log/asterisk/cdr-csv/Master.csv";

$output = array();
#$time_diff = 160000; //In minute
#$time_diff = 10; //In minute
$time_diff = 7; //In minute
#read_last_line = 2;
#$read_last_line = 2200;
$read_last_line = 10;

$prev_output_count = 0;
if ( ! function_exists('str_getcsv')) 
{
	function str_getcsv($input, $delimiter = ',', $enclosure = '"')  
	{
		if( ! preg_match("/[$enclosure]/", $input) ) 
		{
			return (array)preg_replace(array("/^\\s*/", "/\\s*$/"), '', explode($delimiter, $input));
		}
		$token = "##"; $token2 = "::";
		//alternate tokens "\034\034", "\035\035", "%%";
		$t1 = preg_replace(array("/\\\[$enclosure]/", "/$enclosure{2}/",
				"/[$enclosure]\\s*[$delimiter]\\s*[$enclosure]\\s*/", "/\\s*[$enclosure]\\s*/"),
				array($token2, $token2, $token, $token), trim(trim(trim($input), $enclosure)));
	
		$a = explode($token, $t1);
		foreach($a as $k=>$v) 
		{
			if ( preg_match("/^{$delimiter}/", $v) || preg_match("/{$delimiter}$/", $v) ) 
			{
				$a[$k] = trim($v, $delimiter); $a[$k] = preg_replace("/$delimiter/", "$token", $a[$k]);
			}
		}
		$a = explode($token, implode($token, $a));
		return (array)preg_replace(array("/^\\s/", "/\\s$/", "/$token2/"), array('', '', $enclosure), $a);
	}
}

function read_line_from_csv($read_last_line = "", $temp) 
{
    global $Current_time, $file_path, $time_diff, $output,  $prev_output_count;
    #$command = "tail -n ".$read_last_line." ".$file_path." | tac"; #abhishek
    $command = "tail -n $read_last_line $file_path | tac";
#echo $command; exit;
    $output = array();
    $res = shell_exec($command);
echo $res;
    $res1 = explode("\n",$res);
#echo "hello....".$res1;
print_r($res1);

    foreach ($res1 as $k => $line) 
    {
    	$cells = "";
        if($line == "\n" || $line == "") continue;
        $cells = str_getcsv($line);
        $key = array_search('"', $cells); // $key = 2;
		if($key == 4) {
	        unset($cells[$key]);
	        $cells = array_values($cells);
		}
        if((strtotime($Current_time) - strtotime($cells[11])) >= ($time_diff*60)) 
		{
            return $output;
        }
        $output[$k] = $cells;
    }
    $last_cell = end($output);
    if($prev_output_count == count($output))
        return $output;
    
    if((strtotime($Current_time) - strtotime($last_cell[11])) <= ($time_diff*60) ) 
    {
        $prev_output_count = count($output);
        read_line_from_csv(count($output) + $read_last_line, true);
    }
    return $output;
}

$output = read_line_from_csv($read_last_line,true);
#$output = read_line_from_csv($read_last_line);

# echo 'Output Array ==> <pre>';
# echo '<pre>';print_r($output);exit;
echo print_r($output);exit;
$con = mysql_connect('localhost','root','tumko34h1se') or die('Not Connected to the server!');
mysql_select_db('asterisk',$con) or die('Database selection Error!');

ini_set('memory_limit', '300M');
ini_set('max_execution_time', 123456);
ini_set('post_max_size', '100M');
ini_set('upload_max_filesize', '100M');


$q = "INSERT INTO `asterisk`.`ovs_cdr_log` ( `accountcode` , `src` , `dst` , `dcontext` , `clid` , `channel` , `dstchannel` , `lastapp` , `lastdata` , `calldate` , `callpickup` , `callhangup` , `duration` , `billsec` , `status` , `userfield` , `callid` , `amaflags` ) VALUES  ";

$count = 0;
mysql_query("START TRANSACTION;");

foreach ($output as $k => $o) 
{
    $sql="SELECT (accountcode) ".
            " FROM CallCenterCDR".
            " WHERE calldate='".$o[11]."'".
            " AND src='".$o[1]."'".
            " AND duration='".$o[12]."'".
            " LIMIT 1";
    $result = mysql_num_rows(mysql_query($sql));
    if($result != 1)
    {
        //$insert_q = $q."(NULL, '".mysql_real_escape_string($o[1])."', '".mysql_real_escape_string($o[2])."',
 /*bk       $insert_q = $q."('".mysql_real_escape_string($o[1])."', '".mysql_real_escape_string($o[2])."',
                '".mysql_real_escape_string($o[3])."', '".mysql_real_escape_string($o[4])."',
                '".mysql_real_escape_string($o[5])."'
        , '".mysql_real_escape_string($o[6])."', '".mysql_real_escape_string($o[7])."',
                '".mysql_real_escape_string($o[8])."', '".mysql_real_escape_string($o[9])."',
                        '".mysql_real_escape_string($o[10])."'
        , '".mysql_real_escape_string($o[11])."', '".mysql_real_escape_string($o[12])."'
        , '".mysql_real_escape_string($o[13])."', '".mysql_real_escape_string($o[14])."'
        , '".mysql_real_escape_string($o[15])."', '".mysql_real_escape_string($o[16])."');"; */

	  $insert_q = $q."('', '".mysql_real_escape_string($o[1])."', '".mysql_real_escape_string($o[2])."',
                '".mysql_real_escape_string($o[3])."', '".mysql_real_escape_string($o[4])."',
                '".mysql_real_escape_string($o[5])."'
        , '".mysql_real_escape_string($o[6])."', '".mysql_real_escape_string($o[7])."',
                '".mysql_real_escape_string($o[8])."', '".mysql_real_escape_string($o[9])."',
                        '".mysql_real_escape_string($o[10])."'
        , '".mysql_real_escape_string($o[11])."', '".mysql_real_escape_string($o[12])."'
        , '".mysql_real_escape_string($o[13])."', '".mysql_real_escape_string($o[14])."'
        , '".mysql_real_escape_string($o[15])."', '".mysql_real_escape_string($o[16])."'
        , '');";

#echo $insert_q;exit;
        if(mysql_query($insert_q))
            $count++;
    }
}

echo "Total : ".count($output).", Record Inserted is :". $count;
mysql_query("COMMIT;");
exit;
?>
