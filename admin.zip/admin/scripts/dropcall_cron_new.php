<?php
require('/var/www/html/admin/dbconnect.php');
$curr_time = date('Y-m-d H:i:s', time());
$pre_time = date('Y-m-d H:i:s', strtotime('-30 minutes'));
#$sql = "SELECT DISTINCT(phone_number) FROM vicidial_list WHERE list_id='999' AND status IN ('DROP','TIMEOT') AND modify_date >='".$pre_time."' AND modify_date <='".$curr_time."'"; 
$sql = "SELECT DISTINCT(phone_number) FROM vicidial_closer_log WHERE status IN ('DROP') AND call_date >='".$pre_time."' AND call_date <='".$curr_time."'"; 
#echo $sql."\n";exit;
$result = mysql_query($sql);					
$entry_date = date('Y-m-d H:i:s');
while ($row = mysql_fetch_array($result))
{

	$sql_insert = "insert into vicidial_list (entry_date,status,list_id,phone_number) values ('$entry_date','NEW','12345','".$row['phone_number']."')";	
	#echo $sql_insert; exit;
	mysql_query($sql_insert);
}
?>
