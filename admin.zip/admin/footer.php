<div class="pg-footer">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 text-center">
				<p><strong>Centrix Admin</strong> | Centrix Plus 2016-2019 All Rights Reserved.</p>
			</div>
		</div>
	</div>
</div>