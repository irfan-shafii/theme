<?php
require("dbconnect.php");
require("functions.php");

function ifLeadExistsinLog($row,$link) {
        $VAC_mancall_ct=0;
echo "\n";
       echo $stmt = "SELECT * from vicidial_closer_log where  phone_number like '%".$row['phone_number']."%' and status not in ('DROP','TIMEOUT','NANQUE') and  call_date >'".$row['entry_date']."' ";

        $rslt=mysql_query($stmt, $link);
$VAC_mancall_ct = mysql_num_rows($rslt);
if ($VAC_mancall_ct > 0)
{
  return true;
} else {
        echo "\n";
     echo   $stmt = "SELECT * from recording_posta where  extension like '%".$row['phone_number']."%' and   datetime >'".$row['entry_date']."' ";

        $rslt=mysql_query($stmt, $link);
        $VAC_mancall_ct = mysql_num_rows($rslt);
        if ($VAC_mancall_ct > 0)
        {
                return true;
        } else {

                echo "\n";
                echo   $stmt = "SELECT * from vicidial_hopper where  lead_id = '".$row['lead_id']."'  ";

                $rslt=mysql_query($stmt, $link);
                $VAC_mancall_ct = mysql_num_rows($rslt);
                if ($VAC_mancall_ct > 0)
                {
                        return true;
                }

        }

}

        return false;
}
echo $stmt = "SELECT vl.*,vc.campaign_id from vicidial_list vl join vicidial_lists vc on vl.list_id=vc.list_id where vl.status in ('DROP','TIMEOUT','NANQUE') and  vl.entry_date > date_sub(now(), interval 5 minute)";

$rslt=mysql_query($stmt, $link);
while($row = mysql_fetch_array($rslt)) {

        if(!ifLeadExistsinLog($row,$link)) {


                $call_date=$row['call_date'];
               $phone_number=$row['phone_number'];

                $lead_id=$row['lead_id'];
                $VD_campaign_id=$row['campaign_id'];
                $list_id=$row['list_id'];

                $gmt_offset=$row['gmt_offset_now'];
                $state=$row['state'];
                $hopper_priority=99;
                $vendor_lead_code=$row['vendor_lead_code'];
               // $gmt_offset=$row['list_id'];

//echo "<pre>";print_r($row);die;

              echo   $stmt = "INSERT INTO vicidial_hopper SET lead_id='$lead_id',campaign_id='$VD_campaign_id',status='READY',list_id='$list_id',gmt_offset_now='$gmt_offset',state='$state',user='',priority='$hopper_priority',source='P',vendor_lead_code='$vendor_lead_code';";
                $rslt=mysql_query($stmt, $link);
                $Haffected_rows = mysql_affected_rows($link);
                if ($Haffected_rows > 0)
                {

echo "Lead ID $lead_id  inserted into hooper";

                }

        }

        //$call_date=$row['call_date'];
        //$phone_number=$row['phone_number'];



//echo "<pre>";print_r($row);die;
}

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
else
        {

        if($auth>0)
                {
                $stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
                $rslt=mysql_query($stmt, $link);
                $row=mysql_fetch_row($rslt);
                $LOGfullname=$row[0];

                fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
                fclose($fp);
                }
        else
                {
                fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
                fclose($fp);
                echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
                exit;
                }

        $stmt="SELECT full_name from vicidial_users where user='$user';";
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $full_name = $row[0];
        }


?>

