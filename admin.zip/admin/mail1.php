<?php
 
if(isset($_POST['submit'])){
	
	$name=$_POST['agent_name'];
	$email=$_POST['email'];
	$date_from=$_POST['date_from'];
	$call_reference=$_POST['call_reference'];
	$evaluated_by=$_POST['evaluated_by'];
	$mention_first_name=$_POST['mention_first_name'];
	$volume_voice=$_POST['volume_voice'];
	$customer_needs=$_POST['customer_needs'];
	$explain_process=$_POST['explain_process'];
	$accurate_information=$_POST['accurate_information'];
	$complicated_terms=$_POST['complicated_terms'];
	$positive_words=$_POST['positive_words'];
	$use_slan_words=$_POST['use_slan_words'];
	
	$informed_customer=$_POST['informed_customer'];
	$offer_asistence=$_POST['offer_asistence'];
	$organization_name=$_POST['organization_name'];
	$total_score=$_POST['total_score'];
	
	 
	$to=$_POST['email']; 
	$subject='form submited'; 
	
	$message="	Name :'$name'<br>Email :'$email'<br>Date-from : '$date_from'<br>Call-reference :'$call_reference'<br>evaluated_by : '$evaluated_by'<br>
			  Use organization Name Mention First Name Clearly: '$mention_first_name'<br>
			Volume of Voice,Use appropriate Pace Friendly tone with a smile :'$volume_voice'<br>
			Identify customer needs :'$customer_needs'<br>
			explain the procedures and process (Very Important) :'$explain_process'<br>
			gave accurate information :'$accurate_information'<br>
			Refrained from using complicated terms :'$complicated_terms'<br>
			Used positive words (I know, I'm certain,) :'$positive_words'<br>
			did not use slang and jargon :'$use_slan_words'<br>
			Informed the Customer before placing them on hold Thanked the customer for holding :'$informed_customer'<br>
			Offer additional assistance :'$offer_asistence'<br>
			Thank you for calling use organization Name :'$organization_name'<br>
			Total :'$total_score'<br>"; 
		 
		$headers  = $_POST['email'];  
			
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	//$headers=$_POST['email'];	
    //mail($to,$subject,$message,$headers);  
					 if(mail($to,$subject,$message,$headers))
						 {
							 echo 'mail sent';
						 }
						 else
						 {
							 echo 'not sent'; 
						 }
	
	 
}
  

?>