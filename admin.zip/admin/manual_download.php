<?php
session_start();
ob_start();
### AST_agent_performance_detail.php
### 
### Copyright (C) 2007  Matt Florell <vicidial@gmail.com>    LICENSE: GPLv2
###
# CHANGES
#
# 71119-2359 - First build
# 71121-0144 - Replace existing AST_agent_performance_detail.php script with this one
#            - Fixed zero division bug
#

include_once("./dbconnect.php");
include_once("./value.php");
#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
        {
        $row=mysql_fetch_row($rslt);
        $non_latin =                                            $row[0];
        $SSoutbound_autodial_active =           $row[1];
        $user_territories_active =                      $row[2];
        }
##### END SETTINGS LOOKUP #####echo
###########################################
//$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
//$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];


$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
        {
            $referaall_url=base64_encode("manual_download");
            header("Location: login.php?refereer=$referaall_url");
   /* Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";*/
    exit;
        }
else
        {

        if($auth>0)
                {
                $stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
                $rslt=mysql_query($stmt, $link);
                $row=mysql_fetch_row($rslt);
                $LOGfullname=$row[0];

                fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
                fclose($fp);
                }
        else
                {
                fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
                fclose($fp);
                echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
                exit;
                }

        $stmt="SELECT full_name from vicidial_users where user='$user';";
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $full_name = $row[0];
        }
include("manual_recording_path.php");
#$i = 0;
shell_exec("/bin/rm -rf $dirPath/recordings/*.*");
//$recording_path="/var/spool/asterisk/monitorDONE/";
/*while($i <= $num)
{ 
    $name = "check".$i;
    if(array_key_exists("$name",$_POST))
    {	
	$filename = $_POST["$name"];
	$filename = addcslashes($filename,' ');
	//$down .= "/var/spool/asterisk/monitor/DONE/".$filename."-in.wav "."/var/spool/asterisk/monitor/DONE/".$filename."-out.wav ";
	//$down .= "/log/asterisk/monitor/monitor/".$filename."-in.wav ";
	$down .= $recording_path.$filename."\t";
    }
    $i++;

} */

foreach($_POST['check'] as $filename){
   $filename = $filename.".wav";    
    $down .= $recording_path.$filename."\t";
}
//include("PP_header.php");
?>

 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
<head>

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<title>Download Recording File</title>
</head>
<body>
<?php require("admin_header.php"); ?>
<form name="form1" method="POST" action="download.php">
  <?
if($down == "")
{
?>

    <center><TABLE width='100%'><TR><TD>
        <FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=2>
        <div class='panel panel-default' style='margin:0 0%;'>
        <div class='panel-heading'><h3 class='panel-title'> Download Report </h3></div>
        <div class='panel-body' style='padding:0;'>
        <table width='100%' class="table" cellspacing ='0' cellpadding = '1'>   
        <tr bgcolor=#e8e6da>
           <td class='td_padding'>No file has been selected for downloading</td>
        </tr>                         
        <tr bgcolor=#f7f5f0>
            <td align="center">
                <input type="button" name="back" class="btn btn-orange" value="Go Back" onclick="javascript:history.back();">
            <td>
        </tr>        
       </table></div></div></font></td></tr></table></center>

<?    
}
else
{


shell_exec("/bin/cp $down  $dirPath/recordings/");
shell_exec("/bin/tar cvf $dirPath/recordings/recording.tar recordings/");


if(is_file("$dirPath/recordings/recording.tar"))
{     ?>  	
<!--<table border="0" cellpadding="0" celspacing="0" bordercolor="#000000" width="500">
<tr height="20">
<td>&nbsp;</td>
</tr>
<tr><td align="center" class="main5">File has been created : Recording.tar.gz.<td></tr>
<tr><td align="center" class="main5">Click here to download.&nbsp;<b><a href="recordings/recording.tar.gz">Download file</a></b><td></tr>
<tr height="20">
<td>&nbsp;</td>
</tr>    
</table>-->
<center><TABLE width='100%'><TR><TD>
        <FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=2>
        <div class='panel panel-default' style='margin:0 0%;'>
        <div class='panel-heading'><h3 class='panel-title'> Download Report </h3></div>
        <div class='panel-body' style='padding:0;'>
        <table width='100%' class="table" cellspacing ='0' cellpadding = '1'>   
        <tr bgcolor=#e8e6da>
           <td class='td_padding'>File has been created : Recording.tar</td>
        </tr>
       </table>
            <br /><center><b><a href="recordings/recording.tar" class="btn btn-orange">Download file</a></b></center><br />
	</div></div></font></td></tr></table></center>
<?              
}
else
{
?>	
        <center><TABLE width='100%'><TR><TD>
        <FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=2>
        <div class='panel panel-default' style='margin:0 0%;'>
        <div class='panel-heading'><h3 class='panel-title'> Download Report </h3></div>
        <div class='panel-body' style='padding:0;'>
        <table width='100%' class="table" cellspacing ='0' cellpadding = '1'>   
	    <tr bgcolor=#e8e6da>
    	   <td class='td_padding'>Due to some errors file has not been created.</td>
        </tr>
        <tr bgcolor=#f7f5f0>
            <td class="td_padding">Kindly go back and select the files for downloading again.<td>
        </tr>      	              
	    <tr bgcolor=#e8e6da>
            <td align="center">
                <input type="button" name="back" class="btn btn-orange" value="GO BACK" onclick="javascript:history.back();">
            <td>
        </tr>        
	   </table></div></div></font></td></tr></table></center>    
<?    }
}?>   

</form>

</td></tr>

<tr><td width="100%" height="5" background="image/table_bottom.gif">
</td></tr>
<tr height="9"><td></td></tr>
</table>
</body>
</html>


<?
//include("PP_footer.php");    
?>
