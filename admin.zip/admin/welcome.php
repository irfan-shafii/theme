<?php
# welcome.php - VICIDIAL welcome page
# 
# Copyright (C) 2016  Matt Florell <vicidial@gmail.com>    LICENSE: AGPLv2
#
# CHANGELOG:
# 141007-2140 - Finalized adding QXZ translation to all admin files
# 161106-1920 - Changed to use newer design and dynamic links
#
?>

	<!DOCTYPE html>
	<html lang="en">

	<head>
		<!-- Required meta tags always come first -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Welcome Centrix Plus</title>
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" type="text/css" href="css/fonts.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
		<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="css/welcome.css">
	</head>

	<body>
		<div class="container">
			<div class="header clearfix">
			<h4 class="text-muted"><img src="images/centrix_plus-logo-light.png" alt=""></h4>
			</div>
			<div class="jumbotron">
				<h1>Welcome Centrix</h1>
				<p class="lead"><?php echo('we are the leading organization in the communication Era of this Century'); ?></p>
			</div>
			<div class="row marketing">
				<div class="col-md-4">
					<h4><?php echo ('Welcome Agent'); ?></h4>
					<p><?php echo  ('Call center agents can login here , Agents are privalaged to make outbound and assist the inbounds '); ?></p>
					<p><a href=<?php echo "\"../agent/\""; ?> class="btn btn-default"><?php echo('Agent Login'); ?></a></p>
				</div>
				<div class="col-md-4">
					<h4><?php echo ('Administrator'); ?></h4>
					<p><?php echo('Administrator can login here administrator have all the rights to manage the application.'); ?></p>
					<p><a href=<?php echo "\"../admin/\""; ?> class="btn btn-default"><?php echo('Admin Login'); ?></a></p>
				</div>
				<div class="col-md-4">
					<h4><?php echo('Time Clock'); ?></h4>
					<p><?php echo(''); ?></p>
					<p><a href=<?php echo "\"../agent/timeclock.php?referrer=welcome\""; ?> class="btn btn-default"><?php echo('Timeclock'); ?></a></p>
				</div>
			</div>



			<footer class="footer">
				<p>(&copy; 2016 Centrix Plus.)</p>
			</footer>
		</div>
		<!-- jQuery first, then Tether, then Bootstrap JS. -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/custom.js"></script>
	</body>

	</html>



