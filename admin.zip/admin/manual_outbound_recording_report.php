<?php
session_cache_limiter('private_no_expire');
session_start();
ob_start();
header ("Content-type: text/html; charset=utf-8");

$agentReport = true;

require("dbconnect.php");
require("functions.php");

#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
        {
        $row=mysql_fetch_row($rslt);
        $non_latin =                                            $row[0];
        $SSoutbound_autodial_active =           $row[1];
        $user_territories_active =                      $row[2];
        }
##### END SETTINGS LOOKUP #####
###########################################

//$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
//$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];

$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["begin_date"]))                         {$begin_date=$_GET["begin_date"];}
        elseif (isset($_POST["begin_date"]))    {$begin_date=$_POST["begin_date"];}
if (isset($_GET["end_date"]))                           {$end_date=$_GET["end_date"];}
        elseif (isset($_POST["end_date"]))              {$end_date=$_POST["end_date"];}
if (isset($_GET["user"]))                                       {$user=$_GET["user"];}
        elseif (isset($_POST["user"]))                  {$user=$_POST["user"];}
if (isset($_GET["campaign"]))                           {$campaign=$_GET["campaign"];}
        elseif (isset($_POST["campaign"]))              {$campaign=$_POST["campaign"];}
if (isset($_GET["DB"]))                                         {$DB=$_GET["DB"];}
        elseif (isset($_POST["DB"]))                    {$DB=$_POST["DB"];}
if (isset($_GET["submit"]))                                     {$submit=$_GET["submit"];}
        elseif (isset($_POST["submit"]))                {$submit=$_POST["submit"];}
if (isset($_GET["SUBMIT"]))                                     {$SUBMIT=$_GET["SUBMIT"];}
        elseif (isset($_POST["SUBMIT"]))                {$SUBMIT=$_POST["SUBMIT"];}

//$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
//$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");
$NOW_DATE = date("Y-m-d");
if (!isset($date_from)) {$date_from = $NOW_DATE;}
if (!isset($date_to)) {$date_to = $NOW_DATE;}
if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
        {
            $referaall_url=base64_encode("manual_outbound_recording_report");
            header("Location: login.php?refereer=$referaall_url");
            /* Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
             Header("HTTP/1.0 401 Unauthorized");
             echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";*/
    exit;
        }
else
        {

        if($auth>0)
                {
                $stmt="SELECT full_name,user_group from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
                $rslt=mysql_query($stmt, $link);
                $row=mysql_fetch_row($rslt);
                $LOGfullname=$row[0];
                    $userGroup=$row[1];

                fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
                fclose($fp);
                }
	 else
                {
                fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
                fclose($fp);
                echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
                exit;
                }

        $stmt="SELECT full_name from vicidial_users where user='$user';";
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $full_name = $row[0];
        }



?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
<head>

<script language="JavaScript" src="calendar_db.js"></script>
<link rel="stylesheet" href="calendar.css">

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<title>Outbound Recording Report</title>
<?php


##### BEGIN Set variables to make header show properly #####
$hh =                                   'reports';
$LOGast_admin_access =  '1';
$ADMIN =                                'index.php';
$page_width='770';
$section_width='750';
$header_font_size='3';
$subheader_font_size='2';
$subcamp_font_size='2';
$header_selected_bold='<b>';
$header_nonselected_bold='';
$users_color =          '#FFFF99';
$users_font =           'BLACK';
$users_color =          '#E6E6E6';
$subcamp_color =        '#C6C6C6';
##### END Set variables to make header show properly #####

require("top-menu.php");

$campaigns = mysql_query('SELECT * from vicidial_campaigns;');
$users = mysql_query('SELECT * from vicidial_users;');

?>
<script language="javascript">
function checkAll(){
 for (var i=0;i<document.forms[1].elements.length;i++)
    {
            var e=document.forms[1].elements[i];
            if ((e.name != 'allbox') && (e.type=='checkbox'))
            {
                    e.checked=document.forms[1].allbox.checked;
            }
        }
}

function setDownloadAction() {
document.form1.action = "manual_download.php";
document.form1.submit();
}

function setDeleteAction() {

if(confirm("Are you sure want to delete these rows?")) {
document.form1.action = "delete.php";
document.form1.submit();
}

}
</script>
</head>
<body>
<?php
if(isset($_POST['submit']))
{
        $date_from = $_POST['date_from'];
        $date_to = $_POST['date_to'];
        $phone_number=$_POST['phone_number'];
        $ext_number=$_POST['ext_number'];
        $did_number=$_POST['did_number'];
        if($date_from=='')
        {
                $date_from = $today;
        }
        if($date_to=='')
        {
                $date_to =$today;
        }
        $start = "$date_from $start_time";
        $end =  "$date_to $end_time";
}
echo "<center><TABLE width='50%'><TR><TD>\n";
echo "<div class='panel panel-default' style='margin:0 0%;'>";
echo "<div class='panel-heading'><h3 class='panel-title'>Manual Outbound Call Recording</h3></div>";
echo "<div class='panel-body' style='padding:0;'>";
echo "<form action='' method=POST name=report id=vicidial_report>";
echo "<input type=hidden name=DB value=\"$DB\">";
echo "<table width='100%' class=\"table\" cellspacing ='0' cellpadding = '1'>";

?>
	<tr bgcolor=#e8e6da>
	<td class='td_padding'>Date</td>
        <td><input type="text" name="date_from" style="width: 100px"  VALUE="<?php echo $date_from; ?>">
		<script language="JavaScript">
			var o_cal = new tcal ({
        		// form name
        		'formname': 'report',
        		// input name
        		'controlname': 'date_from'
			});
			o_cal.a_tpl.yearscroll = false;
			// o_cal.a_tpl.weekstart = 1; // Monday week start
		</script>
        to<input type="text" name="date_to" style="width: 100px" VALUE="<?php echo $date_to; ?>" >
		<script language="JavaScript">
			var o_cal = new tcal ({
		        // form name
		        'formname': 'report',
		        // input name
		        'controlname': 'date_to'
			});
			o_cal.a_tpl.yearscroll = false;
			// o_cal.a_tpl.weekstart = 1; // Monday week start
		</script>
        </td>
        </tr>
	<tr bgcolor=#f7f5f0>
	<td align=left class='td_padding'>Phone Number:</td>
	<td><input type='text' name="ext_number" value="<?php echo $ext_number; ?>"></td>
	</tr>
	<tr bgcolor=#e8e6da>
        <td align=left class='td_padding'>Desk Number:</td>
        <td><input type='text' name="phone_number" value="<?php echo $phone_number; ?>"></td>
        </tr>

	<tr>
	<td colspan="2" align="center"><input type="submit" name="submit" value="Submit" class='btn btn-orange'/></td>
	</tr>
</table>
</form>
</div></div>
</table>
<?php
### Abhishek
$today = date('Y-m-d');
$start_time='00:00:00';
$end_time='23:59:59';
if(isset($_POST['submit']))
{
        $date_from = $_POST['date_from'];
        $date_to = $_POST['date_to'];
        $phone_number=$_POST['phone_number'];
        $ext_number=$_POST['ext_number'];

        #echo "<script>alert('$phone_number');</script>";

        if($date_from=='')
        {
                $date_from = $today;
        }
        if($date_to=='')
        {
                $date_to =$today;
        }
	$start = "$date_from $start_time";
        $end =  "$date_to $end_time";

?>
<br />

<form name='form1' method='POST' action=''>
<div style='float:right;'>
  <!--  <input type='button' value='DOWNLOAD' name='download' onClick='setDownloadAction();' class='btn btn-orange' >
<a href='javascript:void(0);' onClick='setDownloadAction();' class='btn btn-orange'><i class='glyphicon glyphicon-save'></i></a>-->
 </div><br /><br />
<TABLE width='100%'><TR><TD>
    <FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
        <div class='panel panel-default' style='margin:0 0%;'>
            <table class='table report-heading' ><tr><td class='heading-orange' align='center' style='width:300px;'><b>Outbound Recordings: </b></td><td style='border-top:none;'></td><td class='heading-black'><?php echo "$date_from - $date_to";?><a href='javascript:void(0);'            onClick='setDownloadAction();' class='btn btn-orange pull-right'><i class='glyphicon glyphicon-save'></i></a></td><tr></table>
            <div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>
<br><tr style='background-color:#d4d0b3' >
<td class='td_padding' style='border-right:1px solid #e8e6da;'><font><input type='checkbox' value='on' name='allbox' onClick='checkAll();'></td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'>Rows</td>
                        <td class='td_padding' style='border-right:1px solid #e8e6da;'>Recording Id</td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'>Desk Number</td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'>Phone Number</td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'>Recording Name</td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'>Call Date & Time</td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'>Call Type</td>
<!-- <td class='td_padding' style='border-right:1px solid #e8e6da;'>Call Time</td> -->
<td class='td_padding' style='border-right:1px solid #e8e6da;'>Play</td>
</tr>
<?php
	$c=1;
	$where = '';
	if($phone_number!='')
        {
		$where .="and r.phone_number LIKE '%$phone_number%' ";
	}
	if($ext_number!='')
        {
                $where .="and r.extension = '$ext_number' ";
        }

if($userGroup!='ADMIN' || trim($PHP_AUTH_USER) == "saleem" )
{
    $where .=" and v.user_group = 'AGENTS' ";

    $sql="select * from recording_manual r join vicidial_users v on r.phone_number=v.phone_login  where r.datetime>='$start' and r.datetime<='$end' and r.call_type='outbound' {$where}";

} else {
    #$sql="SELECT * FROM (select * from recording_posta where datetime>='$start' and datetime<='$end' and call_type='outbound' {$where}) as t1, ( SELECT billsec, callid FROM `ovs_cdr_log` ) as t2 WHERE t1.uniqueid = t2.callid";
    $sql="select r.* from recording_manual r where datetime>='$start' and datetime<='$end' and call_type='outbound' {$where}";


}
             	//echo $sql;
        $result = mysql_query($sql);
	while($row = mysql_fetch_array($result))
	{
		$filename = $row['3'];
		//$extension = substr($row['2'], -4);
        $extension =$row['2'];
        $recording_id =$row['0'];
?>
	<tr>
	<td class='td_padding' style='border-right:1px solid #ccc;'><input type='checkbox' name='check[]' value='<?php echo $filename; ?>'><?php echo $u; ?></td>
	<!--<td class='td_padding' style='border-right:1px solid #ccc;'><input type='checkbox' name='check_list[]' value='<?php echo $filename; ?>'><?php echo $u; ?></td>-->
	<td class='td_padding' style='border-right:1px solid #ccc;'><?php echo $c;?></td>
        <td class='td_padding' style='border-right:1px solid #ccc;'><?php echo $recording_id;?></td>
	<td class='td_padding' style='border-right:1px solid #ccc;'><?php echo $extension; ?></td>
	<td class='td_padding' style='border-right:1px solid #ccc;'><?php echo $row['6']; ?></td>
	<td class='td_padding' style='border-right:1px solid #ccc;'><?php echo $row['3']; ?></td>
	<td class='td_padding' style='border-right:1px solid #ccc;'><?php echo $row['4']; ?></td>
	<td class='td_padding' style='border-right:1px solid #ccc;'><?php echo "outbound"; ?></td>
	<!-- <td class='td_padding' style='border-right:1px solid #ccc;'><?php echo $row['billsec']; ?></td> -->
	<td class='td_padding' style='border-right:1px solid #ccc;'><a href="manual_faisal_play.php?filename=<?php echo $filename; ?>&recording_id=<?php echo $recording_id; ?>"> <i class='glyphicon glyphicon-play-circle'></i></a></td>
	</tr>
<?php
	$c++;
	}
}
?>
</table>
</div></div>
</form>
</body>
</html>
