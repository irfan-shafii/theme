<?php
require("dbconnect.php");
require("functions.php");
if(isset($_POST['view'])){

$query = "select lead_id from vicidial_list  WHERE entry_date > CURDATE()   order by lead_id desc limit 1";
$result = mysql_query( $query);
    $closeCallId=0;
$output = '';
    $output_notification = '';
$total_live_calls=mysql_num_rows($result) ;
if($total_live_calls >0) {
    $closeCallResult=mysql_fetch_array($result);
    $closeCallId=$closeCallResult['lead_id'];
}

$data = array(
   // 'notification' => $output,
    'unseen_notification'  => $total_live_calls,
    'callid'=>$closeCallId
   // 'output_notification'=>$output_notification
);

echo json_encode($data);

}

?>