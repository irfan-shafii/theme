<?php
require("dbconnect.php");
require("functions.php");

header('Content-Type: text/csv; charset=utf-8');
header("Content-Disposition: attachment; filename=helpdesk_report.csv");
$output = fopen('php://output', 'w');

$query_date_BEGIN = $_GET['date_from']; 
$query_date_END = $_GET['date_to']; 
$campaign = $_GET['campaign'];

$where_outbound = "1";
if($campaign != '')
{
	$where_outbound .= " and campaign_id = '$campaign'";
	$sql_select_group = "SELECT closer_campaigns FROM vicidial_campaigns WHERE campaign_id = '$campaign'";
	#echo $sql_select_group;
	$result_select_group = mysql_query($sql_select_group);
	if($row_select_group = mysql_fetch_array($result_select_group))
	{
		$group = $row_select_group['closer_campaigns'];
	}
}
	$group = preg_replace("/^ | -$/","",$group);
	#echo $group;
	#exit;
$where_inbound = "1";
if($group != '')
{
	$where_inbound .= " and campaign_id = '$group'";
}
#echo "<br />";
#echo $where_inbound."<br />";
#echo $where_outbound;	

### Query for inbound and outbound both
$sql_combine = "(select count(*),status from vicidial_closer_log where call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_inbound} group by status) union (select count(*),status from vicidial_log where call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_outbound} group by status)";
	
#echo $sql_combine;
$result_combine = mysql_query($sql_combine);


fputcsv($output, array('','Help Desk Report',"$query_date_BEGIN-$query_date_END",''));
fputcsv($output, array('No','Status','Status Name','Calls'));
	
$i=1;
while($row_combine = mysql_fetch_array($result_combine))
{
	$status = $row_combine[1];
	$sql_status_name = "(select status,status_name from vicidial_statuses where status='$status') union (select status,status_name from vicidial_campaign_statuses where status='$status')";
	$result_status_name = mysql_query($sql_status_name);
	#echo $sql_status_name;
	if($row_status_name= mysql_fetch_array($result_status_name))
	{
		$status_name=$row_status_name[1];
	}

fputcsv($output, array($i,$row_combine[1],$status_name,$row_combine[0]));
$i++;
}

fputcsv($output, array('Total Calls',''));

#### Total Answer
$sql_ans = "(select count(status) from vicidial_closer_log where status NOT IN ('DROP','TIMEOT') and call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_inbound})";
#echo $sql_ans;
$result_ans = mysql_query($sql_ans);
if($row_ans = mysql_fetch_array($result_ans))
{
	$inbound_ans = $row_ans[0];
}
$sql_ans = "(select count(status) from vicidial_log where status NOT IN ('DROP','TIMEOT') and call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_outbound})";

#echo $sql_ans;
$result_ans = mysql_query($sql_ans);
if($row_ans = mysql_fetch_array($result_ans))
{
	$outbound_ans = $row_ans[0];
}
$total_ans = $inbound_ans + $outbound_ans;
fputcsv($output, array('Total Answers',$total_ans));
	
	
#### Total Dropcall
$sql_drop = "select count(status) from vicidial_closer_log where status IN ('DROP','TIMEOT') and call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_inbound}";
$result_drop = mysql_query($sql_drop);
if($row_drop = mysql_fetch_array($result_drop))
{
	$inbound_drop = $row_drop[0];
}
$sql_drop = "select count(status) from vicidial_log where status IN ('DROP','TIMEOT') and call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_outbound}";
$result_drop = mysql_query($sql_drop);
if($row_drop = mysql_fetch_array($result_drop))
{
	$outbound_drop = $row_drop[0];
}
$total_drop = $inbound_drop + $outbound_drop;
fputcsv($output, array('Total Drop',$total_drop));


### Total Unique
$sql_unique = "select count(DISTINCT(phone_number)) from vicidial_closer_log where call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_inbound} and status IN ('DROP','TIMEOT')";
$result_unique = mysql_query($sql_unique);
if($row_unique = mysql_fetch_array($result_unique))
{
	$inbound_unique = $row_unique[0];
}
$sql_unique = "select count(DISTINCT(phone_number)) from vicidial_log where call_date >= '$query_date_BEGIN' and call_date <= '$query_date_END' and {$where_outbound} and status IN ('DROP','TIMEOT')";
$result_unique = mysql_query($sql_unique);
if($row_unique = mysql_fetch_array($result_unique))
{
	$outbound_unique = $row_unique[0];
}
$total_unique = $inbound_unique + $outbound_unique;
fputcsv($output, array('Total unique',$total_unique));

$total = $total_ans + $total_drop ; 
fputcsv($output, array('Total Calls',$total));



fputcsv($output, array('','','','Agent wise calls',$query_date_BEGIN.'-'.$query_date_END,'','',''));
fputcsv($output, array('No','Agent Name','Calls','Pause Time','Wait Time','Talk Time','Dispo Time','Dead Time'));

$sql_agent = "select user,sum(pause_sec),sum(wait_sec),sum(talk_sec),sum(dispo_sec),sum(dead_sec),count(lead_id) from vicidial_agent_log where event_time >= '$query_date_BEGIN' and event_time <= '$query_date_END' and {$where_outbound} group by user ";
#echo $sql_agent;
$i=1;
$total_pause_time = 0;
$total_wait_time = 0;
$total_talk_time = 0;
$total_dispo_time = 0;
$total_dead_time = 0;
$total_calls = 0;
$result_agent = mysql_query($sql_agent);
while($row_agent = mysql_fetch_array($result_agent))
{
	$user = $row_agent['user'];
	$sql_full_name = "select full_name from vicidial_users where user='$user'";
	$result_full_name = mysql_query($sql_full_name);
	if($row_full_name = mysql_fetch_array($result_full_name))
	{
		$full_name = $row_full_name[0];
	}
	$pause_time = $row_agent['sum(pause_sec)'];
	$wait_time = $row_agent['sum(wait_sec)'];
	$talk_time = $row_agent['sum(talk_sec)'];
	$dispo_time = $row_agent['sum(dispo_sec)'];
	$dead_time = $row_agent['sum(dead_sec)'];
	$calls = $row_agent['count(lead_id)'];
	
				
	$total_pause_time = $total_pause_time + $pause_time;
	$total_wait_time = $total_wait_time + $wait_time;
	$total_talk_time = $total_talk_time + $talk_time;
	$total_dispo_time = $total_dispo_time + $dispo_time;
	$total_dead_time = $total_dead_time + $dead_time;
	$total_calls = $total_calls + $calls;
	
	$pause_time = sec_convert($pause_time,'H');
	$wait_time = sec_convert($wait_time,'H');
	$talk_time = sec_convert($talk_time,'H');
	$dispo_time = sec_convert($dispo_time,'H');
	$dead_time = sec_convert($dead_time,'H');

	fputcsv($output, array($i,$full_name,$calls,$pause_time,$wait_time,$talk_time,$dispo_time,$dead_time));

	$i++;
}
	$total_pause_time = sec_convert($total_pause_time,'H');
	$total_wait_time = sec_convert($total_wait_time,'H');
	$total_talk_time = sec_convert($total_talk_time,'H');
	$total_dispo_time = sec_convert($total_dispo_time,'H');
	$total_dead_time = sec_convert($total_dead_time,'H');

	fputcsv($output, array('','Grand Total:',$total_calls,$total_pause_time,$total_wait_time,$total_talk_time,$total_dispo_time,$total_dead_time));
?>
