<?php
$use_agent_colors = '1'; 				# set to 1 to use the agent_screen_colors setting in the system settings 
?>
