<?php echo "<BR><table cellpadding=0 cellspacing=0 width=20% >";
//echo "<TR bgcolor='#000000'><TD ALIGN=CENTER colspan=2><a href=\"#\" onclick=\"openDiv(\'campaign_select_list\');\"><font size=2>Choose Report Display Options</a></TD></TR>";
echo "<TR bgcolor='#E8E6DA'><TD ALIGN=left><font size=2><B>DIAL LEVEL :</B></TD><TD ALIGN=LEFT><font size=2>$DIALlev </TD></tr>";
echo "<TR bgcolor='#F7F5F0'><TD ALIGN=left><font size=2><B>FILTER : </B></TD><TD ALIGN=LEFT><font size=2>&nbsp; $DIALfilter &nbsp; </TD></tr>";
echo "<TR bgcolor='#E8E6DA'><TD ALIGN=left><font size=2><B>DIALABLE LEADS:</B></TD><TD ALIGN=LEFT ><font size=2>$DAleads </TD></tr>";
echo "<TR bgcolor='#F7F5F0'><TD ALIGN=left><font size=2><B>HOPPER <font size=1>( min/auto )</font>:</B></TD><TD ALIGN=LEFT><font size=2>$HOPlev / $AHOPlev</TD></tr>";
echo "<TR bgcolor='#E8E6DA'><TD ALIGN=left><font size=2><B>LEADS IN HOPPER:</B></TD><TD ALIGN=LEFT ><font size=2>&nbsp; $VDhop &nbsp; &nbsp; </TD></tr>";
echo "<TR bgcolor='#F7F5F0'><TD ALIGN=left><font size=2><B>CALLS TODAY:</B></TD><TD ALIGN=LEFT ><font size=2>&nbsp; $callsTODAY &nbsp; &nbsp; </TD></tr>";	
echo "<TR bgcolor='#E8E6DA'><TD ALIGN=left><font size=2><B>DIAL METHOD:</B></TD><TD ALIGN=LEFT ><font size=2>&nbsp; $DIALmethod &nbsp; &nbsp; </TD></tr>";
echo "<TR bgcolor='#F7F5F0'><TD ALIGN=left><font size=2><B>DROPPED / ANSWERED:</B></TD><TD ALIGN=LEFT ><font size=2>&nbsp; $dropsTODAY / $answersTODAY &nbsp; </TD>";	
echo "<TR bgcolor='#E8E6DA'><TD ALIGN=left><font size=2><B>DROPPED PERCENT:</B></TD><TD ALIGN=LEFT ><font size=2>&nbsp; ";
if ($drpctTODAY >= $DROPmax)
		{echo "<font color=red><B>$drpctTODAY%</B></font>";}
	else
		{echo "$drpctTODAY%";}
	echo " &nbsp; &nbsp;</TD></TR>";
	//echo "<TD ALIGN=left colspan=2'><font size=2><B>ORDER:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $DIALorder &nbsp; &nbsp; </TD>";
	//echo "";			

	//echo "<TR bgcolor='#E8E6DA'>";		//echo "<td></td>";
	//echo "";
	//echo "</tr><TR bgcolor='#E8E6DA'>";
	//echo "";
	//echo "<td></td>";
	//echo "";
	//echo "<td></td>";
	//echo "</TR>";
	//echo "<TR bgcolor='#F7F5F0'>";	
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DIALABLE LEADS:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $DAleads &nbsp; &nbsp; </TD>";	
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>AVG AGENTS:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $agentsONEMIN &nbsp; &nbsp; </TD>";
	//echo "<td></td>";
	//echo "</TR>";
	//echo "<TR bgcolor='#E8E6DA'>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>HOPPER <font size=1>( min/auto )</font>:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $HOPlev / $AHOPlev &nbsp; &nbsp; </TD>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DL DIFF:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $diffONEMIN &nbsp; &nbsp; </TD>";
	//echo "</TR>";
	//echo "<TR bgcolor='#F7F5F0'>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>LEADS IN HOPPER:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $VDhop &nbsp; &nbsp; </TD>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DIFF:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $diffpctONEMIN% &nbsp; &nbsp; </TD>";
	//echo "</TR>";
	//echo "<TR bgcolor='#E8E6DA'>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>TRUNK SHORT/FILL:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $balanceSHORT / $balanceFILL &nbsp; &nbsp; </TD>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B> TIME:</B> &nbsp; </TD><TD ALIGN=LEFT colspan=2><font size=2> $NOW_TIME </TD>";	
	//echo "</TR>";
	//echo "<TR bgcolor='#F7F5F0'>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>CALLS TODAY:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $callsTODAY &nbsp; &nbsp; </TD>";	
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DIAL METHOD:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $DIALmethod &nbsp; &nbsp; </TD>";
	//echo "</TR>";
	//echo "<TR bgcolor='#E8E6DA'>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DROPPED / ANSWERED:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $dropsTODAY / $answersTODAY &nbsp; </TD>";	
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>STATUSES:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $DIALstatuses &nbsp; &nbsp; </TD>";
	//echo "</TR>";
	//echo "<TR bgcolor='#F7F5F0'>";
	//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DROPPED PERCENT:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; ";
	
	//if ($adastats>1)
		//{
		//$min_link='<a href=\"$PHP_SELF?$usergroupQS$groupQS&RR=4&DB=$DB&adastats=1\"><font size=1>- min </font></a>';
		//if ($RTajax > 0)
		//	{$min_link='';}

		//echo "<TR BGCOLOR=\"#E8E6DA\">";
		//echo "<TD ALIGN=left colspan=2 class='td_padding'>$min_link<font size=2>&nbsp; <B>MAX LEVEL:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $maxDIALlev &nbsp; </TD>";
		//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DROPPED MAX:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $DROPmax% &nbsp; &nbsp;</TD>";
		//echo "</TR>";
		//echo "<TR BGCOLOR=\"#F7F5F0\">";
	//	echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>TARGET DIFF:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $targetDIFF &nbsp; &nbsp; </TD>";
		//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>INTENSITY:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $ADAintense &nbsp; &nbsp; </TD>";
		//echo "</TR>";
		//echo "<TR BGCOLOR=\"#E8E6DA\">";
	//	echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>DIAL TIMEOUT:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $DIALtimeout &nbsp;</TD>";
		//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>TAPER TIME:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $TAPERtime &nbsp;</TD>";
	//	echo "</TR>";
		//echo "<TR BGCOLOR=\"#F7F5F0\">";
		//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>LOCAL TIME:</B></TD><TD ALIGN=LEFT colspan=2 style='border-right:1px solid #ccc;'><font size=2>&nbsp; $CALLtime &nbsp;</TD>";
		//echo "<TD ALIGN=left colspan=2 class='td_padding'><font size=2><B>AVAIL ONLY:</B></TD><TD ALIGN=LEFT colspan=2><font size=2>&nbsp; $ADAavailonly &nbsp;</TD>";
		//echo "</TR>";
	//	}	
		?>