<?php
require("dbconnect.php");
require("functions.php");


if(isset($_POST['view'])){


$query = "select * from vicidial_auto_calls where status='LIVE' ";
$result = mysql_query( $query);
$output = '';
    $output_notification = '';
$total_live_calls=mysql_num_rows($result) ;
if($total_live_calls> 0)
{
 while($row = mysql_fetch_array($result))
 {
   $output .= '
   <li>
   <a href="#">
   <strong>'.$row["phone_number"].'</strong><br />
   <small><b>Campaign Id</b>  - <em>'.$row["campaign_id"].'</em></small>
     <small><b>Call Time </b>  - <em>'.$row["call_time"].'</em></small>
   </a>
   </li>
   ';

     $output_notification .= '\n
   <strong>'.$row["phone_number"].'</strong><br />
   <small><b>Campaign Id</b>  - <em>'.$row["campaign_id"].'</em></small>
     <small><b>Call Time </b>  - <em>'.$row["call_time"].'</em></small>

   ';
 }
}
else{
     $output .= '
     <li><a href="#" class="text-bold text-italic">No Calls In Queue</a></li>';



}


$data = array(
    'notification' => $output,
    'unseen_notification'  => $total_live_calls,
    'output_notification'=>$output_notification
);

echo json_encode($data);

}

?>