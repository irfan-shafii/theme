<html>

<head>
    <style>

        /* General Styles */
        html{

            background-size: cover;
            height:100%;
            background-color: #000;
        }
        * {
            box-sizing:border-box;
            -webkit-box-sizing:border-box;
            -moz-box-sizing:border-box;
            -webkit-font-smoothing:antialiased;
            -moz-font-smoothing:antialiased;
            -o-font-smoothing:antialiased;
            font-smoothing:antialiased;
            text-rendering:optimizeLegibility;
        }
        body {
            color: #C0C0C0;
            font-family: Arial, san-serif;
        }
        table {
            margin-top: 10px;



        }
        th, td.body_large, td.body_small {


            padding-bottom: 25px;
            padding-right: 25px;
        }
        table th {
            font-size: 25px;


        }

        /* Contact Form Styles */

        th{
            margin: 10px 20px;
        }
        body table {
            background-color:rgba(72,72,72,0.7);
            padding: 10px 20px 30px 20px;
            max-width:100%;
            float: left;
            left: 50%;
            position: absolute;
            margin-top:30px;
            margin-left: -260px;
            border-radius:7px;
            -webkit-border-radius:7px;
            -moz-border-radius:7px;
        }




          a,input[type="button"] {
            cursor:pointer;
            width:100%;
            border:none;
            background:#991D57;
            background-image:linear-gradient(bottom, #8C1C50 0%, #991D57 52%);
            background-image:-moz-linear-gradient(bottom, #8C1C50 0%, #991D57 52%);
            background-image:-webkit-linear-gradient(bottom, #8C1C50 0%, #991D57 52%);
            color:#FFF;
            margin:0 0 5px;
            padding:10px;
            border-radius:5px;
            width: auto !important;
        }
         a,input[type="button"]:hover {
            background-image:linear-gradient(bottom, #9C215A 0%, #A82767 52%);
            background-image:-moz-linear-gradient(bottom, #9C215A 0%, #A82767 52%);
            background-image:-webkit-linear-gradient(bottom, #9C215A 0%, #A82767 52%);
            -webkit-transition:background 0.3s ease-in-out;
            -moz-transition:background 0.3s ease-in-out;
            transition:background-color 0.3s ease-in-out;
        }
         a,input[type="button"]:active {
            box-shadow:inset 0 1px 3px rgba(0,0,0,0.5);
        }



        /* Hide success/failure message
           (especially since the php is missing) */
        #failure, #success {
            color: #6EA070;
            display:none;
        }

        /* Make form look nice on smaller screens */
        @media only screen and (max-width: 580px) {
            form{
                left: 3%;
                margin-right: 3%;
                width: 88%;
                margin-left: 0;
                padding-left: 3%;
                padding-right: 3%;
            }
        }
        .bold_large {

            font-weight: bold;
            color:red;
        }
    </style>

</head>


<?php
//$phone_number='67771404';
$phone_number=isset($_REQUEST['phone']) ? $_REQUEST['phone']:"";

if(!$phone_number) {

    echo "<span class='bold_large'>Kindly pass phone number</span>";
    
}
else if(strlen($phone_number)==11) {
  $phone_number = substr($phone_number, 3);
//exit();
}
error_reporting(E_ALL);
ini_set('display_errors', 1);
/*$url = "http://ec2-35-157-61-171.eu-central-1.compute.amazonaws.com";
$db = "bitnami_openerp";
$username = "t@devoire.com";
$password = "R7xHUO5u";
*/
$url = 'http://159.65.17.29:9000';
$db = "sismatix_call_center";
$username = "admin";
$password = "a";

require_once('ripcord-master/ripcord.php');
$common = ripcord::client("$url/xmlrpc/2/common");
//$version=$common->version();
//echo "<pre>";print_r($version);die;

$uid = $common->authenticate($db, $username, $password, array());
$models = ripcord::client("$url/xmlrpc/2/object");


$records = $models->execute_kw($db, $uid, $password, 'res.partner', 'search_read', array(
    array(
        array('phone', '=', $phone_number),
    ),
), array('fields'=>array('name', 'country_id', 'comment','mobile','email','street','city','phone','id')
));



if (is_array($records) && isset($records[0])) {

foreach ($records as  $real_content) {
    //$page_url=$url."/web#id=".$real_content['id']."&view_type=kanban&model=res.partner&action=77&menu_id=70";
     $page_url=$url."/web?#min=1&limit=80&view_type=list&model=sale.order&action=503&active_id=".$real_content['id']."&menu_id=70";
?>

<table >
    <tr><th colspan="2"> Contact Details</th></tr>

    <tr><td>Name:</td><td><?php echo $real_content['name']?></td></tr>

    <tr><td>Id:</td><td><?php echo $real_content['id'] ?></td></tr>
    <tr><td>Mobile:<td><?php echo $real_content['mobile'] ?></td></tr>
    <tr><td>Phone:</td><td><?php echo $real_content['phone']?></td></tr>
    <tr><td>Email:</td><td><?php echo $real_content['email'] ?></td></tr>
    <tr><td>Street:</td><td><?php echo $real_content['street'] ?></td></tr>
    <tr><td>City:</td><td><?php echo $real_content['city'] ?></td></tr>
    <tr><td>Country:</td><td><?php echo $real_content['country_id'][1] ?></td></tr>
    <tr><td></td></tr>
    <tr><td></td></tr>
    <tr><td></td></tr>
    <tr><td colspan="2">
            <a href="javascript:window.close()" onclick="window.open('<?php echo $page_url; ?>'); "> Go to CRM Page</a>
          <!--
          javascript:window.open(http://195.226.254.232/vicidial/odoo_client.php?phone=--A--phone_number--B--)
          <input type="button" value="Go to CRM Page" onclick="window.open('<?php // echo $page_url; ?>')" />-->


        </td>
    
    </tr>
</table>
<?php } } else {
    $createpage_url=$url."/web#&view_type=kanban&model=res.partner&action=77&menu_id=70";
    ?>


    <table >
        <tr><th colspan="2"> This Phone Number has not registered with CRM</th></tr>


        <tr><td></td></tr>
        <tr><td></td></tr>
        <tr><td></td></tr>
        <tr><td colspan="2">
                <a href="javascript:window.close()" onclick="window.open('<?php echo $createpage_url; ?>'); "> Create Customer</a>
             <!--   <input type="button" value="Create Customer" onclick="window.open('<?php // echo $createpage_url; ?>', '_self')" /> -->


            </td></tr>
    </table>

<?php }

?>
</html>
