<?php
require("dbconnect.php");
require("functions.php");


if(isset($_POST['view'])){


$query = "select vl.user,vl.server_ip,vl.extension,vl.status,vl.campaign_id,vl.last_call_time,va.sub_status,va.event_time from vicidial_live_agents vl left join vicidial_agent_log va on vl.agent_log_id=va.agent_log_id and vl.user=va.user where vl.status='PAUSED' and va.sub_status in ('MTG','TRG','CPB','BRK','OUT') and date(va.event_time)=CURDATE()  and DATE_ADD(va.event_time, INTERVAL 10 MINUTE) <= NOW()  ";
$result = mysql_query( $query);
$output = '';
    $output_notification = '';
$total_live_calls=mysql_num_rows($result) ;
if($total_live_calls> 0)
{
 while($row = mysql_fetch_array($result))
 {
   $output .= '
   <li>
   <a href="#">
   <strong>'.$row["user"].'</strong><br />
   <small><b>Extension</b>  - <em>'.$row["extension"].'</em></small>
     <small><b>Pause Code </b>  - <em>'.$row["sub_status"].'</em></small>
     <small><b>Since </b>  - <em>'.$row["event_time"].'</em></small>
   </a>
   </li>
   ';
     $output_notification .= '\n
   <strong>'.$row["user"].'</strong><br />
   <small><b>Extension </b>  - <em>'.$row["extension"].'</em></small>
     <small><b>>Pause Code </b>  - <em>'.$row["sub_status"].'</em></small>
          <small><b>>Since </b>  - <em>'.$row["event_time"].'</em></small>

   ';

 }
}
else{
     $output .= '
     <li><a href="#" class="text-bold text-italic">No Agents are on Short Break </a></li>';
    $output_notification .= '\n No Agents on Break';

}


$data = array(
    'notification' => $output,
    'unseen_notification'  => $total_live_calls,
    'output_notification'=>$output_notification

);

echo json_encode($data);

}

?>