<?php
$short_header=1;
header ("Content-type: text/html; charset=utf-8");
$agentReport = true;
require("dbconnect.php");
require("functions.php");
#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
//echo "1".$stmt;exit;
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
        {
        $row=mysql_fetch_row($rslt);
        $non_latin =                                            $row[0];
        $SSoutbound_autodial_active =           $row[1];
        $user_territories_active =                      $row[2];
        }
##### END SETTINGS LOOKUP #####echo
###########################################
$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);
$STARTtime = date("U");
$TODAY = date("Y-m-d");
if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
//echo "2".$stmt;exit;
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];
$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");
if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
        {
    Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
    exit;
        }
###########################################
$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["begin_date"]))                         {$begin_date=$_GET["begin_date"];}
        elseif (isset($_POST["begin_date"]))    {$begin_date=$_POST["begin_date"];}
if (isset($_GET["end_date"]))                           {$end_date=$_GET["end_date"];}
        elseif (isset($_POST["end_date"]))              {$end_date=$_POST["end_date"];}
if (isset($_GET["user"]))                                       {$user=$_GET["user"];}
        elseif (isset($_POST["user"]))                  {$user=$_POST["user"];}
if (isset($_GET["campaign"]))                           {$campaign=$_GET["campaign"];}
        elseif (isset($_POST["campaign"]))              {$campaign=$_POST["campaign"];}
if (isset($_GET["DB"]))                                         {$DB=$_GET["DB"];}
        elseif (isset($_POST["DB"]))                    {$DB=$_POST["DB"];}
if (isset($_GET["submit"]))                                     {$submit=$_GET["submit"];}
        elseif (isset($_POST["submit"]))                {$submit=$_POST["submit"];}
if (isset($_GET["SUBMIT"]))                                     {$SUBMIT=$_GET["SUBMIT"];}
        elseif (isset($_POST["SUBMIT"]))                {$SUBMIT=$_POST["SUBMIT"];}

$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
else
        {

        if($auth>0)
                {
                $stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
              //  echo "3".$tmt;exit;
                $rslt=mysql_query($stmt, $link);
                $row=mysql_fetch_row($rslt);
                $LOGfullname=$row[0];

                fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
                fclose($fp);
                }
        else
                {
                fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
                fclose($fp);
                echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
                exit;
                }

        $stmt="SELECT full_name from vicidial_users where user='$user';";
       //  echo "4".$tmt;exit;
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $full_name = $row[0];
        }


?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<title>Inbound Call Flow Report</title>
</head>
<script language="JavaScript" src="calendar_db.js"></script>
<link rel="stylesheet" href="calendar.css">

<body>

<?php 
#require("admin_header.php"); 
require("top-menu.php"); 
if (isset($_GET["date_from"]))                         {$query_date=$_GET["date_from"];}
        elseif (isset($_POST["date_from"]))    {$query_date=$_POST["date_from"];}
        elseif($date_from =='' ){$date_from=date('Y-m-d');}
if (isset($_GET["date_to"]))                           {$end_date=$_GET["date_to"];}
        elseif (isset($_POST["date_to"]))              {$end_date=$_POST["date_to"];}
         elseif($date_to =='' ){$date_to=date('Y-m-d');}
if($_POST['display'])
{
if(isset($_POST['generate']))
{

	$today_date=date('Y-m-d');
	$date_from=$_POST['date_from']; 
	$date_to=$_POST['date_to']; 
	$group = $_POST['groups'];
	//$group = $_POST['groups'];
	//echo($group);exit;
	$call_type = $_POST['call_type'];
	//echo($call_type);exit;
	if($date_from =='' )
	{
		$date_from=$today_date;
	}
	if($date_to =='' )
	{
		$date_to=$today_date;
	}

	$time_BEGIN = "00:00:00";
        $time_END = "23:59:59";
        $query_date_BEGIN = "$date_from $time_BEGIN";
        $query_date_END = "$date_to $time_END";
}
}
?>
<!--<center><h1>Inbound Call Flow Report</h1></center>-->
<br><TABLE CELLPADDING=1 CELLSPACING=0 width='100%' ><TR><TD>
<center><TABLE width='100%'><TR><TD>
<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
<div class='panel panel-success'>
<TABLE BORDER=0 CELLSPACING=1 class='table'><tr>
<form action="" method="post" style="width: 500px; margin: auto" name="report">
<TABLE BORDER=0 class='table'>
    <input type="hidden" name="display" value="1" />
        <tr bgcolor='#D4D0B3' style='color:black;'>
	<td align='center'>Dates</td>
	<td align='center'>To</td>
	<td align='center'>Campaigns</td>
	<td align='center'>Call Type</td>
	<td align='center'></td>
	<td align='center'></td>
	</tr></div>
	<tr><td></td></tr>
	<tr bgcolor='#E8E6DA'>
            <td align='center'><input type="text" name="date_from" value="<?php echo $date_from;?>"/>
		<script language="JavaScript">
			var o_cal = new tcal ({
		        // form name
		        'formname': 'report',
		        // input name
		        'controlname': 'date_from'
			});
			o_cal.a_tpl.yearscroll = false;
		</script>
          </td>       
            <td align='center'><input type="text" name="date_to" value="<?php echo $date_to;?>"/>
<script language="JavaScript">
var o_cal = new tcal ({
        // form name
        'formname': 'report',
        // input name
     'controlname': 'date_to'
});
o_cal.a_tpl.yearscroll = false;
</script>
         </td>        
	<td align='center'>
		<select name="groups" id="groups">
			<option name="">Select</option>
			<?php
			$sql_get_ingroup = "select group_id from vicidial_inbound_groups";
			
			$result_get_ingroup = mysql_query($sql_get_ingroup);

			while($row_get_ingroup = mysql_fetch_array($result_get_ingroup))
			{
				echo "<option value='$row_get_ingroup[0]'";
					if($group == $row_get_ingroup[0])
					{
						echo "Selected";
					}
					echo ">$row_get_ingroup[0]</option>";
			}

			
			?>
		</select>
	</td>
	<td align='center'> 
		<select name="call_type" id="call_type">
		<option value="">Select</option>
		<option value="Inbound"<?php if($call_type == 'Inbound') {echo "Selected";} ?>>Inbound</option>
		<option value="Misscall"<?php if($call_type == 'Misscall') {echo "Selected";} ?>>Misscall</option>
		</select>
	</td>
        <td colspan="2" align="center"><input type="submit" name="generate" value="Submit"class='btn btn-orange'  /></td></tr>
    </table>
</form>

<br><TABLE width='100%'><TR><TD>
<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
<div class='panel panel-default' style='margin:0 0%;'>
<table class='table report-heading' ><tr><td class='heading-orange' align='center'><b>Inbound Call Flow Report </b></td><td class='heading-black'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php if($_POST['generate']) {echo $date_from." to ".$date_to;}?></td><td class='heading-black'><?php if($_POST['generate']) {?><a class="btn btn-orange pull-right" href="/admin_new/export_call_flow_report.php?date_from=<?php echo $query_date_BEGIN?>&date_to=<?php echo $query_date_END ?>&call_type=<?php echo $call_type;?>&group=<?php echo $group;?>">
<i class="glyphicon glyphicon-save" style="color:white"></i>
</a><?php }?></td><tr></table>
<?php
if($_POST['display'])
{
if(isset($_POST['generate']))
{

	$today_date=date('Y-m-d');
	$date_from=$_POST['date_from']; 
	$date_to=$_POST['date_to']; 
	$group = $_POST['groups'];
	//echo($group);exit;
	$call_type = $_POST['call_type'];

	if($date_from =='' )
	{
		$date_from=$today_date;
	}
	if($date_to =='' )
	{
		$date_to=$today_date;
	}

	$time_BEGIN = "00:00:00";
        $time_END = "23:59:59";
        $query_date_BEGIN = "$date_from $time_BEGIN";
        $query_date_END = "$date_to $time_END";
	
	$where = 1;
	if($call_type == "Misscall" ) {$where .= " and (status='DROP') " ;}
	elseif ($call_type == "Inbound") {$where .= " and (status !='DROP')" ;}

	if($group == "Select" )
	{
		#$call_flow_sql = "SELECT * FROM (SELECT phone_ext,start_time,GROUP_CONCAT(comment_b),uniqueid FROM `live_inbound_log` WHERE `start_time` >= '$query_date_BEGIN' and `start_time` <= '$query_date_END'  group by uniqueid) as t1, (SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and {$where} ) as t2 WHERE t1.uniqueid = t2.uniqueid";
	//commented by avdhesh on feb 26 2018
		/*$call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason,phone_number_call_date  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and {$where} AND term_reason not in ('CALLER')";*/

$call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason,phone_number_call_date  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and {$where} ";
	//echo $call_flow_sql;exit;
	}
	if($group != "Select" ){//echo "123";exit;
		#$call_flow_sql = "SELECT * FROM (SELECT phone_ext,start_time,GROUP_CONCAT(comment_b),uniqueid FROM `live_inbound_log` WHERE `start_time` >= '$query_date_BEGIN' and `start_time` <= '$query_date_END'  group by uniqueid) as t1, (SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and campaign_id='$group' and {$where}) as t2 WHERE t1.uniqueid = t2.uniqueid";
		//commented by avdhesh on feb 26 2018
/*$call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason,phone_number,call_date  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and campaign_id='$group' and {$where} AND term_reason not in ('CALLER')";*/

$call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason,phone_number,call_date  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and campaign_id='$group' and {$where} ";


	}
	#echo $call_flow_sql;	exit;
}
?>

<div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>
               <br><tr style='background-color:#d4d0b3' align='center' >
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Row</b></font></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>ID</b></font></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Phone Number</b></font></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Groups</b></font></a></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Datetime</b></font></a></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Desk</b></font></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Call Time</b></font></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Total Time</b></font></td>
<!--<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Disposition Time</b></font></td>-->
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Hangup By</b></font></td>
<td style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Disposition</b></font></td>
	</tr>
	<?php
		$i=1;
		$c=1;
		$total_sec=0;
		$time_BEGIN = "00:00:00";
		$time_END = "23:59:59";
		$query_date_BEGIN = "$date_from $time_BEGIN";
		$query_date_END = "$date_to $time_END";
                $call_flow_result = mysql_query($call_flow_sql);
                $result= mysql_affected_rows();
                while ($call_flow_row = mysql_fetch_row($call_flow_result))
                {
                                $uniqueid = $call_flow_row['4'];
                                $phone_number = $call_flow_row['7'];
                                $group = $call_flow_row['1'];
                                $datetime = $call_flow_row['8'];
                                $user = $call_flow_row['0'];
                                $sec = $call_flow_row['2'];
                                #$que_sec = $call_flow_row['7'];
				$status = $call_flow_row['5'];
				$action = $call_flow_row['6'];
				$row = $i;
				
				if($pre_uniqueid==$uniqueid)
                                {
                                        $uniqueid='';
                                        $phone_number='';
                                        $ivr='';
                                        $datetime='';
					$row='';
					$i--;
					$c++;
					$total_sec = $total_sec + $sec;
                                }
                                elseif($pre_uniqueid!=$uniqueid)
                                {
                                        $pre_uniqueid='';
					$c=1;
					$total_sec = $sec;
                                }
				### Print total sec 
				$print_total_sec = $total_sec;
				$print_total_sec = sec_convert($print_total_sec,'H');
				$sec = sec_convert($sec,'H');
				

			####### Get Dispo time
			//$sql_get_dispo ="select dispo_sec from vicidial_agent_log where uniqueid='$uniqueid'";

			//$result_get_dispo = mysql_query($sql_get_dispo);
			//if($row_get_dispo = mysql_fetch_array($result_get_dispo))
		//	{	
				$dispo_sec = $row_get_dispo['dispo_sec'];
				$dispo_sec = sec_convert($dispo_sec,'H');	
			//}
			//else{	
			//	$dispo_sec = "00:00";
			//}
	?>
<tr align='center' >
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $row;?></font></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $uniqueid;?></font></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $phone_number;?></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $group;?></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $datetime;?></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $user; ?></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $sec; ?></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $print_total_sec; ?></td>
<!--<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $dispo_sec; ?></td>-->
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $action; ?></td>
<td style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $status; ?></td>
                <tr>

	<?php
			 if($pre_uniqueid=='')
                                {
                                        $pre_uniqueid = $uniqueid;
                                }
				$i++;
			}
	?>
	</table>
	</td>
	</tr>
</table>
<?php
} 
?>
</body>
</html>

