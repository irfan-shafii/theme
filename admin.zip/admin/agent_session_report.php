<?php
session_start();
ob_start();
$short_header=1;
header ("Content-type: text/html; charset=utf-8");

$agentReport = true;

require("dbconnect.php");
require("functions.php");

#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
        {
        $row=mysql_fetch_row($rslt);
        $non_latin =                                            $row[0];
        $SSoutbound_autodial_active =           $row[1];
        $user_territories_active =                      $row[2];
        }
##### END SETTINGS LOOKUP #####echo
###########################################
$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];
$PHP_SELF=$_SERVER['PHP_SELF'];


$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
        {
            $referaall_url=base64_encode("agent_session_report");
            header("Location: login.php?refereer=$referaall_url");
   /* Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";*/
    exit;
        }
###########################################

$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["begin_date"]))                         {$begin_date=$_GET["begin_date"];}
        elseif (isset($_POST["begin_date"]))    {$begin_date=$_POST["begin_date"];}
if (isset($_GET["end_date"]))                           {$end_date=$_GET["end_date"];}
        elseif (isset($_POST["end_date"]))              {$end_date=$_POST["end_date"];}
if (isset($_GET["user"]))                                       {$user=$_GET["user"];}
        elseif (isset($_POST["user"]))                  {$user=$_POST["user"];}
if (isset($_GET["campaign"]))                           {$campaign=$_GET["campaign"];}
        elseif (isset($_POST["campaign"]))              {$campaign=$_POST["campaign"];}
if (isset($_GET["DB"]))                                         {$DB=$_GET["DB"];}
        elseif (isset($_POST["DB"]))                    {$DB=$_POST["DB"];}
if (isset($_GET["submit"]))                                     {$submit=$_GET["submit"];}
        elseif (isset($_POST["submit"]))                {$submit=$_POST["submit"];}
if (isset($_GET["SUBMIT"]))                                     {$SUBMIT=$_GET["SUBMIT"];}
        elseif (isset($_POST["SUBMIT"]))                {$SUBMIT=$_POST["SUBMIT"];}

$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
else
        {

        if($auth>0)
                {
                $stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
                $rslt=mysql_query($stmt, $link);
                $row=mysql_fetch_row($rslt);
                $LOGfullname=$row[0];

                fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
                fclose($fp);
                }
        else
                {
                fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
                fclose($fp);
                echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
                exit;
                }

        $stmt="SELECT full_name from vicidial_users where user='$user';";
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $full_name = $row[0];
        }

if($campaign) {
//echo "<pre>";print_r($campaign);die;
}

?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<title>Agent Login/Logout Report</title>
</head>
<script language="JavaScript" src="calendar_db.js"></script>
<link rel="stylesheet" href="calendar.css">

<body>

<?php
# require("admin_header.php");
 require("top-menu.php");
 if (isset($_GET["date_from"]))                         {$query_date=$_GET["date_from"];}
        elseif (isset($_POST["date_from"]))    {$query_date=$_POST["date_from"];}
        elseif($date_from =='' ){$date_from=date('Y-m-d');}
if (isset($_GET["date_to"]))                           {$end_date=$_GET["date_to"];}
        elseif (isset($_POST["date_to"]))              {$end_date=$_POST["date_to"];}
        elseif($date_to =='' ){$date_to=date('Y-m-d');}

if($_POST['display'])
{
if(isset($_POST['generate']))
{

    $today_date=date('Y-m-d');
    $date_from=$_POST['date_from']; 
    $date_to=$_POST['date_to']; 
    $campaign = $_POST['campaign'];


   
    if($date_from =='' )
    {
        $date_from=$today_date;
    }
    if($date_to =='' )
    {
        $date_to=$today_date;
    }

    $time_BEGIN = "00:00:00";
        $time_END = "23:59:59";
        $query_date_BEGIN = "$date_from $time_BEGIN";
        $query_date_END = "$date_to $time_END";
}


}


 ?>
<!--<center><h1>Outbound Call Report</h1></center>-->


<form action="" method="post" style="margin: auto" name="report">
   <input type="hidden" name="display" value="1" />
<br><TABLE CELLPADDING=1 CELLSPACING=0 width='100%' ><TR><TD>
<center><TABLE width='100%'><TR><TD>
<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
<div class='panel panel-success'>
<TABLE BORDER=0 CELLSPACING=1 class='table'><tr>
<TABLE BORDER=0 class='table'><tr bgcolor='#D4D0B3' style='color:black;'>
<td align='center'>Dates</td>
<td align='center'>To</td>
<td align='center'>Campaigns</td>
<td align='center'></td>
<td align='center'></td>
</tr></div>
<tr><td></td></tr>
<tr bgcolor='#E8E6DA'>
<td align='center'><input type="text" name="date_from" value="<?php echo $date_from;?>"/>
		<script language="JavaScript">
			var o_cal = new tcal ({
		        // form name
		        'formname': 'report',
		        // input name
		        'controlname': 'date_from'
			});
			o_cal.a_tpl.yearscroll = false;
		</script>
          </td>
           <td align='center'><input type="text" name="date_to" value="<?php echo $date_to;?>"/>
<script language="JavaScript">
var o_cal = new tcal ({
        // form name
        'formname': 'report',
        // input name
     'controlname': 'date_to'
});
o_cal.a_tpl.yearscroll = false;
</script>
         </td>      
	<td align='center'>
		<select name="campaign[]" id="campaign" multiple>
			
			<?php
			$sql_get_campaign = "select campaign_id from vicidial_campaigns";
			$result_get_campaign = mysql_query($sql_get_campaign);
			while($row_get_campaign = mysql_fetch_array($result_get_campaign))
			{
                echo "<option value='$row_get_campaign[0]'";
                    /*if($campaign == $row_get_campaign[0])
                    {
                        echo "Selected";
                    }*/
                 if(in_array($row_get_campaign[0],$campaign)) {
                     echo "Selected";

                 }
                    echo ">$row_get_campaign[0]</option>";
			
			}
			?>
		</select>
	</td>
        <td colspan="2" align="center"><input type="submit" name="generate" value="Submit" class='btn btn-orange' /></td></tr>
    </table>
</form>
<br><TABLE width='100%'><TR><TD>
<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
<div class='panel panel-default' style='margin:0 0%;'>
<table class='table report-heading' ><tr><td class='heading-orange' align='center'><b>Agent Login/Logout Time Report </b></td><td class='heading-black'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php if($_POST['generate']) {echo $date_from." to ".$date_to;}?></td><td class='heading-black'><?php if($_POST['generate']) {?><a class="btn btn-orange pull-right" href="/admin_new/export_outbound_call_report.php?date_from=<?php echo $query_date_BEGIN?>&date_to=<?php echo $query_date_END ?>&campaign=<?php echo $campaign;?>">
<i class="glyphicon glyphicon-save" style="color:white"></i>
</a><?php }?></td><tr></table>
<?php
if($_POST['display'])
{
if(isset($_POST['generate']))
{
	$today_date=date('Y-m-d');
	$date_from=$_POST['date_from']; 
	$date_to=$_POST['date_to']; 
	$campaign = $_POST['campaign'];

	if($date_from =='' )
	{
		$date_from=$today_date;
	}
	if($date_to =='' )
	{
		$date_to=$today_date;
	}

	$time_BEGIN = "00:00:00";
        $time_END = "23:59:59";
        $query_date_BEGIN = "$date_from $time_BEGIN";
        $query_date_END = "$date_to $time_END";

//echo "hello :".$campaign;

//echo "<pre>";print_r($campaign);
	
	if(!empty($campaign) )
    {
$keywords_imploded = implode("','",$campaign);
      //  $call_flow_sql = "select vc.full_name,v.user,min(v.event_date) as first, max(v.event_date) as last ,TIMEDIFF(max(v.event_date),min(v.event_date))  as total from vicidial_user_log v join vicidial_users vc on v.user=vc.user where event_date>='$query_date_BEGIN' and event_date<='$query_date_END' and campaign_id  in ('$keywords_imploded')  group by v.user";
          $call_flow_sql = "select vc.full_name,v.user,min(v.event_date) as first from vicidial_user_log v join vicidial_users vc on v.user=vc.user where event_date>='$query_date_BEGIN' and event_date<='$query_date_END' and campaign_id  in ('$keywords_imploded') and event='LOGIN'  group by v.user";

    }
    if(empty($campaign)){
       // $call_flow_sql = "select vc.full_name,v.user,min(v.event_date) as first, max(v.event_date) as last ,TIMEDIFF(max(v.event_date),min(v.event_date))  as total from vicidial_user_log v join vicidial_users vc on v.user=vc.user where event_date>='$query_date_BEGIN' and event_date<='$query_date_END'  group by v.user";
        $call_flow_sql = "select vc.full_name,v.user,min(v.event_date) as first from vicidial_user_log v join vicidial_users vc on v.user=vc.user where event_date>='$query_date_BEGIN' and event_date<='$query_date_END' and event='LOGIN'   group by v.user";

    }

	
	//echo $call_flow_sql;
}
?>


<div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>
<br><tr style='background-color:#d4d0b3' >
<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><b>Row</b></font></td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Agent Name</b></font></td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Agent Extension</b></font></td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Time of First Login</b></font></td>
<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Time of Last Logout</b></font></td>
<!--<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Total Logged in Time</b></font></td>-->

	</tr>
	<?php
		$c=1;
    $login='';
    $logout='';
                $call_flow_result = mysql_query($call_flow_sql);
                $result= mysql_affected_rows();
                while ($call_flow_row = mysql_fetch_array($call_flow_result))
                {
                                $username = $call_flow_row['full_name'];
                                $user_id = $call_flow_row['user'];
                                $login = $call_flow_row['first'];

                    $logout_sql = "select max(v.event_date) as last  from vicidial_user_log v  where event_date>='$query_date_BEGIN' and event_date<='$query_date_END' and event='LOGOUT' and user='$user_id' ";

                    $logout_result = mysql_query($logout_sql);
                    $logs_result= mysql_affected_rows();
                    $logout_array=mysql_fetch_row($logout_result);
                    if($logout_array) {

                        $logout = $logout_array[0];
                    }

                    // $logout = $call_flow_row['last'];
                               // $total = $call_flow_row['total'];

	?>
		<tr>
		<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $c;?></td>
                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $username;?></td>
                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $user_id;?></td>
                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $login;?></td>
                <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $logout;?></td>
            <!--    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php echo $total;?></td>-->

                </tr>

	<?php
				$c++;
		}
	?>
	</table>
	</td>
	</tr>
</table>
<?php
} 
?>
</body>
</html>

