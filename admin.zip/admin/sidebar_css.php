<style type="text/css">
.left-menu
{
	padding-top:2%;
	width:15%;
}
.left-menu .item {
    	height:auto;
    	padding-left:10%;
        padding-top:3%;
        padding-bottom:3%;
    	font-size:larger;
}
.left-menu .item a {
    	color:#3c3838;
    	display:block;
    	font-size:medium;
    	text-decoration:none;
        padding-top:2%;
}
.left-menu .item:hover, .left-menu .item-head:hover {
	background-color:#3c3838;
    height:auto;
}
.left-menu .item:hover a {
    color: #ffffff;
}
.left-menu table {
    background-color: #fff;
    width: 100%;
    height: 100%;
}
.left-menu .item-head {
    cursor: pointer;
}
</style>