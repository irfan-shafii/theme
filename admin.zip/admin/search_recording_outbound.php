<?php
session_cache_limiter('private_no_expire');
session_start();
ob_start();
header ("Content-type: text/html; charset=utf-8");
$agentReport = true;
require("dbconnect.php");
require("functions.php");
?>
	<script language="javascript">
		function checkAll(){
			for (var i=0;i<document.forms[1].elements.length;i++)
			{
				var e=document.forms[1].elements[i];
				if ((e.name != 'allbox') && (e.type=='checkbox'))
				{
					e.checked=document.forms[1].allbox.checked;
				}
			}
		}
		function setDownloadAction() {
			document.form1.action = "download.php";
			document.form1.submit();
		}
		function setDeleteAction() {
			if(confirm("Are you sure want to delete these rows?")) {
				document.form1.action = "delete.php";
				document.form1.submit();
			}
		}
	</script>
<?php
#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
{
	$row=mysql_fetch_row($rslt);
	$non_latin =						$row[0];
	$SSoutbound_autodial_active =		$row[1];
	$user_territories_active =			$row[2];
}
##### END SETTINGS LOOKUP #####echo
###########################################

$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];

//$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
//$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["begin_date"]))				{$begin_date=$_GET["begin_date"];}
elseif (isset($_POST["begin_date"]))	{$begin_date=$_POST["begin_date"];}
if (isset($_GET["end_date"]))				{$end_date=$_GET["end_date"];}
elseif (isset($_POST["end_date"]))		{$end_date=$_POST["end_date"];}
if (isset($_GET["user"]))					{$user=$_GET["user"];}
elseif (isset($_POST["user"]))			{$user=$_POST["user"];}
if (isset($_GET["campaign"]))				{$campaign=$_GET["campaign"];}
elseif (isset($_POST["campaign"]))		{$campaign=$_POST["campaign"];}
if (isset($_GET["DB"]))						{$DB=$_GET["DB"];}
elseif (isset($_POST["DB"]))			{$DB=$_POST["DB"];}
if (isset($_GET["submit"]))					{$submit=$_GET["submit"];}
elseif (isset($_POST["submit"]))		{$submit=$_POST["submit"];}
if (isset($_GET["SUBMIT"]))					{$SUBMIT=$_GET["SUBMIT"];}
elseif (isset($_POST["SUBMIT"]))		{$SUBMIT=$_POST["SUBMIT"];}
//$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
//$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);
$STARTtime = date("U");
$TODAY = date("Y-m-d");
if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];
$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");
if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
{
	$referaall_url=base64_encode("search_recording_outbound");
	header("Location: login.php?refereer=$referaall_url");
	//Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
	//Header("HTTP/1.0 401 Unauthorized");
	//echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
	exit;
}
else
{
	if($auth>0)
	{
		$stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
		$rslt=mysql_query($stmt, $link);
		$row=mysql_fetch_row($rslt);
		$LOGfullname=$row[0];

		fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
		fclose($fp);
	}
	else
	{
		fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
		fclose($fp);
		echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
		exit;
	}
	$stmt="SELECT full_name from vicidial_users where user='$user';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$full_name = $row[0];
}
?>
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<script language="JavaScript" src="calendar_db.js"></script>
		<link rel="stylesheet" href="calendar.css">
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
		<title>ADMINISTRATION: Outbound Call recording</title>
		<?php
		require("top-menu.php");
		##### BEGIN Set variables to make header show properly #####
		$ADD =					'3';
		$hh =					'reports';
		$LOGast_admin_access =	'1';
		$ADMIN =				'index.php';
		$page_width='770';
		$section_width='770';
		$header_font_size='3';
		$subheader_font_size='2';
		$subcamp_font_size='2';
		$header_selected_bold='<b>';
		$header_nonselected_bold='';
		$users_color =		'#FFFF99';
		$users_font =		'BLACK';
		$users_color =		'#E6E6E6';
		$subcamp_color =	'#C6C6C6';
		##### END Set variables to make header show properly #####
		#require("admin_header.php");
		echo "<center><TABLE width='50%'><TR><TD>\n";
		echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
		echo "<div class='panel panel-default' style='margin:0 0%;'>";
		echo "<div class='panel-heading'><h3 class='panel-title'> Outbound Call Recording</h3></div>";
		echo "<div class='panel-body' style='padding:0;'>";
		echo "<form action='' method=POST name=vicidial_report id=vicidial_report>";
		echo "<input type=hidden name=DB value=\"$DB\">";
		echo "<table width='100%' class=\"table\" cellspacing ='0' cellpadding = '1'>";
		$users = mysql_query('select * from vicidial_users');
		$statuses = mysql_query('select * from vicidial_statuses');
		$campaign_names = mysql_query('select campaign_id,campaign_name from vicidial_campaigns');
		$list_names = mysql_query('select list_id,list_name from vicidial_lists');
		?>
		<tr bgcolor=#e8e6da>
			<td align=left class='td_padding'>Date</td>
			<td align=left>
				<input type=text name=date_from id=date_from style="width: 100px" value="<?php echo $filter['date_from']?>">
				<script language="JavaScript">
					var o_cal = new tcal ({
						'formname': 'vicidial_report',
						'controlname': 'date_from'
					});
					o_cal.a_tpl.yearscroll = false;
				</script>
				to <input type=text name=date_to id=date_to style="width: 100px" value="<?php echo $filter['date_to']?>">
				<script language="JavaScript">
					var o_cal = new tcal ({
						'formname': 'vicidial_report',
						'controlname': 'date_to'
					});
					o_cal.a_tpl.yearscroll = false;
				</script>
			</td></tr>
		<tr bgcolor=#f7f5f0>
			<td align=left class='td_padding'>Agent name</td>
			<td align=left>
				<select name=agent_name>
					<option></option>
					<?php while ($user = mysql_fetch_assoc($users)) {
						echo '<option value="' . $user['user'] . '"' . ($user['user'] == $filter['vicidial_users.user'] ? ' selected="selected"': '') . '>' . $user['full_name'] . '</option>';
					}?>
				</select>
			</td>
		</tr>
		<tr bgcolor=#e8e6da>
			<td align=left class='td_padding'>Campaign Name</td>
			<td align=left>
				<select name=campaign_id>
					<option></option>
					<?php while ($campaign_name = mysql_fetch_assoc($campaign_names)) { ?>
						<option value="<?php echo $campaign_name['campaign_id'];?>" ><?php echo $campaign_name['campaign_id']."-".$campaign_name['campaign_name']; ?></option>
					<?php }?>
				</select>
			</td>
		</tr>

		<tr bgcolor=#f7f5f0>
			<td align=left class='td_padding'>List Name</td>
			<td align=left>
				<select name=list_id>
					<option></option>
					<?php while ($list_name = mysql_fetch_assoc($list_names)) { ?>
						<option value="<?php echo $list_name['list_id'];?>" ><?php echo $list_name['list_name']; ?></option>
					<?php }?>
				</select>
			</td>
		</tr>
		<tr bgcolor=#e8e6da>
			<td align=left class='td_padding'>Phone number</td>
			<td align=left><input type=text name=phone_number value="<?php echo $filter['phone_number']?>"></td>
		</tr>
		<tr bgcolor=#f7f5f0>
			<td align=left class='td_padding'>Status</td><td>
				<select name=status>
					<option></option>
					<?php while ($status = mysql_fetch_assoc($statuses)) {
						echo '<option value="' . $status['status'] . '"' . ($status['status'] == $filter['vicidial_log.status'] ? ' selected="selected"': '') . '>' . $status['status_name'] . '</option>';
					}?>
				</select>
			</td></tr>
		<tr bgcolor=#e8e6da>
			<td align=left class='td_padding'>Length</td>
			<td align=left>
				<select name='length' id="length">
					<option></option>
					<option value="Less than 1 Min">Less than 1 Min</option>
					<option value="1 To 5 Min">1 To 5 Min</option>
					<option value="5 To 10 Min">5 To 10 Min</option>
					<option value="Grater than 10 Min">Grater than 10 Min</option>
				</select>
			</td>
		<tr bgcolor=#e8e6da>
			<td colspan=2 align='center'>
				<input type=submit name=submit value=submit class='btn btn-orange'>
			</td>
		</tr>
		</table></div></table>
		</form>
		</center>
		<?php

		if($_POST['submit']) {
#echo "<pre>";print_r($_REQUEST);exit;
			$today = date('Y-m-d');
			$date_from = $_POST['date_from'];
			$date_to = $_POST['date_to'];
			$agent = $_POST['agent_name'];
			$ingroup = $_POST['campaign_id'];
			$list = $_POST['list_id'];
			$status = $_POST['status'];
			$phone_number = $_POST['phone_number'];
			$length = $_POST['length'];

			if($date_from == ""){
				$date_from = $today;
			}
			if($date_to == ""){
				$date_to = $today;
			}

//$where1=1;
//$where2=1;
			$where_cond= " where t1.start_time >= '$date_from 00:00:00' and t1.start_time <= '$date_to 23:59:59' ";
			/*if($agent != ""){
            $where1 .= " and user='$agent'";
            }

            if($ingroup != ""){
            $where2 .="  and campaign_id='$ingroup'";
            }

            if($list != ""){
            $where2 .="  and list_id='$list'";
            }

            if($status != ""){
            $where2 .="  and status='$status'";
            }
            if($phone_number != ""){
            $where2 .="  and phone_number='$phone_number'";
            }
            if($length != ""){

                if($length == "Less than 1 Min"){

                    $where2 .="  and length_in_sec <= 60";
                }
                if($length == "1 To 5 Min"){

                    $where2 .="  and (length_in_sec >= 60 and length_in_sec<=300)";
                }
                if($length == "5 To 10 Min"){

                    $where2 .="  and (length_in_sec >= 300 and length_in_sec<=600)";
                }

                if($length == "Grater than 10 Min"){

                    $where2 .="  and length_in_sec >= 600";
                }

                if(trim($PHP_AUTH_USER) == "saleem" ){

                    $where2 .="  and user_group='AGENTS' ";
                }

            }
            */

			if($agent != ""){
				$where_cond .= " and t1.user='$agent'";
			}

			if($ingroup != ""){
				$where_cond .=" and t2.campaign_id='$ingroup'";
			}

			if($status != ""){
				$where_cond .=" and t2.status='$status'";
			}
			if($phone_number != ""){
				$where_cond .=" and t2.phone_number='$phone_number'";
			}

			if($length != ""){

				if($length == "Less than 1 Min"){

					$where_cond .=" and t2.length_in_sec <= 60";
				}
				if($length == "1 To 5 Min"){

					$where_cond .=" and (t2.length_in_sec >= 60 and t2.length_in_sec<=300)";
				}
				if($length == "5 To 10 Min"){

					$where_cond .=" and (t2.length_in_sec >= 300 and t2.length_in_sec<=600)";
				}
				if($length == "Grater than 10 Min"){

					$where_cond .=" and t2.length_in_sec >= 600";
				}

			}
			$stmt = "select t1.recording_id, t1.start_time,t1.filename,t1.location,t1.lead_id,t1.user,t1.vicidial_id,t2.list_id,t2.lead_id,t2.campaign_id,t2.status,t2.length_in_sec,t2.phone_number,t2.uniqueid  from recording_log  t1 join vicidial_log t2 on t1.lead_id = t2.lead_id $where_cond   group by t1.recording_id";

//echo $stmt;
//$stmt = "select * from (select start_time,filename,location,lead_id,user,vicidial_id from recording_log where start_time >= '$date_from 00:00:00' and start_time <= '$date_to 23:59:59' and {$where1}) as t1 , (select uniqueid,lead_id,list_id,campaign_id,status,length_in_sec,phone_number from vicidial_log where {$where2}) as t2 where t1.lead_id = t2.lead_id ";
#echo "<br /><center><input type='button' value='DOWNLOAD' name='download' onClick='setDownloadAction();' > <input type='button' value='DELETE' name='delete' onClick='setDeleteAction();'></center> <br /><br />";
//echo $stmt;die;
//Mehul
			echo "<form name='form1' method='POST' action=''>";
##### vicidial recordings for this time period #####
			echo "<br><TABLE width='100%'><TR><TD>\n";
			echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
			echo "<div class='panel panel-default' style='margin:0 0%;'>";
			echo "<table class='table report-heading' ><tr><td class='heading-orange' align='center' style='width:200px;'><b>Outbound Call Recording </b></td><td style='border-top:none;'></td><td class='heading-black'> $date_from - $date_to &nbsp;&nbsp;&nbsp;<a href='javascript:void(0);' onClick='setDownloadAction();' class='btn btn-orange pull-right' style='margin-right:10px;'><i class='glyphicon glyphicon-save'></i></a></td><tr></table><br>";
#echo "<B>Recording For $date_from - $date_to </B>\n";
			echo "<div class='panel-body' style='padding:0;'><table width='100%' class='table' cellspacing=0 cellpadding=1>";
			echo "<tr bgcolor='#D4D0B3'>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><input type='checkbox' value='on' name='allbox' onClick='checkAll();'></font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >#</font></td>";
echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Recording Id</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Date/Time</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Campaign</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >List</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Agent</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Status</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Phone Number</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Sec</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Location</font></td>";
			echo "<td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" >Play</font></td>";
			echo "</tr>";
#exit;
			$result=mysql_query($stmt, $link);
			$logs_to_print = mysql_num_rows($rslt);

			$u=0;
			while ($row = mysql_fetch_array($result))
			{
				if (eregi("1$|3$|5$|7$|9$", $u))
				{$bgcolor='bgcolor="#E8E6DA"';}
				else
				{$bgcolor='bgcolor="#F7F5F0"';}


				$location = $row[2];
				$filename = $row['filename'];
$recording_id = $row['recording_id'];
				if (strlen($location)>20)
				{
					$locat = substr($location,0,27);  $locat = "$locat...";
					$new_location=$new_location;
				}
				else
				{$locat = $location; $new_location=$new_location;}
				if (eregi("http",$location))
				{$location = "<a href=\"$location\">$locat</a>"; $new_location=$new_location; }
				else
				{$location = $locat;}

				$u++;
				echo "<tr $bgcolor>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><input type='checkbox' name='check[]' value='$filename'></font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$u</font></td>";

echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[recording_id]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[start_time]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[campaign_id]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[list_id]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[user]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[status]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[phone_number]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$row[length_in_sec]</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" >$location</font></td>";
				echo "<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><a href='faisal_play.php?filename=$filename&recording_id=$recording_id'><i class='glyphicon glyphicon-play-circle'></i></a></font></td>";
				echo "</tr>\n";

				$tot_rec = $tot_rec + 1;
			}

//Mehul
			echo "\n";
#echo "<tr><td colspan='12' align='center'><input type='button' value='DOWNLOAD' name='download' onClick='setDownloadAction();' > <input type='button' value='DELETE' name='delete' onClick='setDeleteAction();' ></td></tr>";
			echo "<tr><td colspan='10' align='center'>&nbsp;&nbsp;&nbsp;<a href='javascript:void(0);' onClick='setDownloadAction();' class='btn btn-orange' style='margin-right:10px;'><i class='glyphicon glyphicon-save'></i></a></td></tr>";
			echo "</table></div></table>";

			echo "</form>";

		}
		?>
		</TD></TR><TABLE>
			</body>
	</html>

<?php
exit;
?>
