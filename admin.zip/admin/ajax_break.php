<?php
require("dbconnect.php");
require("functions.php");
$user_id=$_POST['userid'];
 $call_flow_sql = "select break_code from breaktimeCode where user_id= ".$user_id;
$c="";
$call_flow_result = mysql_query($call_flow_sql);
$result= mysql_num_rows($call_flow_result);

if($result > 0) {

    $call_flow_row = mysql_fetch_row($call_flow_result);

    $c=$call_flow_row[0];
}
echo $c;
die;
?>