### MySQL Details ###
MUSER="root"
MPASS="ovs1123"

### Make Temperory Directory to Save database backup ###
cd ~/webform/


### Creating Dump of Mysql Databases ###
mysqldump -u$MUSER -p$MPASS asterisk vicidial_lists vicidial_campaigns vicidial_list vicidial_statuses > asterisk.$(date +%Y-%m-%d).sql


### Compress the Backup file at location /home/ftps/ ###
tar cvzf asterisk_backup$(date +%Y-%m-%d).tar.gz asterisk.$(date +%Y-%m-%d).sql

## Copy backup file to server 202.157.95.77  ##
scp asterisk_backup$(date +%Y-%m-%d).tar.gz root@192.168.1.2:/tmp/


### Remove the Temperory Folder ###
rm -rf asterisk.$(date +%Y-%m-%d).sql
rm -rf asterisk_backup$(date +%Y-%m-%d).tar.gz




