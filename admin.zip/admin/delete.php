<?php
### AST_agent_performance_detail.php
### 
### Copyright (C) 2007  Matt Florell <vicidial@gmail.com>    LICENSE: GPLv2
###
# CHANGES
#
# 71119-2359 - First build
# 71121-0144 - Replace existing AST_agent_performance_detail.php script with this one
#            - Fixed zero division bug
#

include_once("./dbconnect.php");
include_once("./value.php");

#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
        {
        $row=mysql_fetch_row($rslt);
        $non_latin =                                            $row[0];
        $SSoutbound_autodial_active =           $row[1];
        $user_territories_active =                      $row[2];
        }
##### END SETTINGS LOOKUP #####echo
###########################################
$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];


$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
        {
    Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
    exit;
        }
else
        {

        if($auth>0)
                {
                $stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
                $rslt=mysql_query($stmt, $link);
                $row=mysql_fetch_row($rslt);
                $LOGfullname=$row[0];

                fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
                fclose($fp);
                }
        else
                {
                fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
                fclose($fp);
                echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
                exit;
                }

        $stmt="SELECT full_name from vicidial_users where user='$user';";
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $full_name = $row[0];
        }

include("recording_path.php");
$num=$_POST['num'];
$i = 0;

//$recording_path="/var/spool/asterisk/monitorDONE/";

while($i <= $num)
{ 
    $name = "check".$i;
     if(array_key_exists("$name",$_POST))
    {
        $filename = $_POST["$name"];
        $filename = addcslashes($filename,' ');


        //$down .= "/var/spool/asterisk/monitorDONE/".$filename."\t";
        $delete = $recording_path.$filename."\t";
        $db_filename=substr($filename, 0, -8);
        echo $db_filename;
    }

    $i++;
//echo $delete."<br>";
shell_exec("/bin/cp $delete /var/lib/temp");

shell_exec("/bin/rm -rf $delete");
$sql="update recording_log set location='DELETED' where filename='$db_filename'";
mysql_query($sql);

} 

//include("PP_header.php");
?>

 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml">
<head>

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<title>Delete Recording File</title>
</head>

<body>
<?php require("admin_header.php"); ?>


<table WIDTH=<?=$page_width ?> cellpadding=4 cellspacing=0 align='center'>

</table><br><br>

<table border=0 width="600" cellpadding=0 cellspacing=0 align="center">
<tr>
<td width="100%"  height="20" class="main3" align=center>DELETED FILE REPORT</td>
</tr>
<tr height="10"><td></td></tr>
<tr><td>

<form name="form1" method="POST" action="delete.php">

  <?
if($delete == "")
{
?>
  <table border="0" cellpadding="0" cellspacing="0" bordercolor="#000000" width="500">
    <tr height="20">
    <td>&nbsp;</td>
    </tr>
   <tr><td align="center" class="main5">No file has been selected for Deleting<td></tr>
       <tr height="20">
    <td>&nbsp;</td>
    </tr>
    <tr><td align="center"><input type="button" name="back" class="buttonstyle" value="Go Back" onclick="javascript:history.back();"><td></tr>
       <tr height="20">
    <td>&nbsp;</td>
    </tr>    
    </table>

<?    
}
else
{
//echo "/usr/bin/sudo /bin/cp $down  /var/www/html/admin/recordings/";exit;
//Mehul [Give folder path where we want to do copy and tar.gz]
//shell_exec("/usr/bin/sudo /bin/rm -rf /home/recording/*.*");
//shell_exec("/bin/cp $down  /var/www/html/admin/recordings/");
//shell_exec("/bin/tar czPf /var/www/html/admin/recordings/recording.tar.gz recordings");

echo "<center>Your Selected Files are deleted..!</center>";

//echo "<input type='button' name='back' class='buttonstyle' value='GO BACK' onclick='javascript:history.back();'>";

}?>   

</form>

</td></tr>

<tr><td width="100%" height="5" background="image/table_bottom.gif">
</td></tr>
<tr height="9"><td></td></tr>
</table>
</body>
</html>


<?
//include("PP_footer.php");    
?>
