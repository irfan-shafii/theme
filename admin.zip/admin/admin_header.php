<?php
# admin_header.php - VICIDIAL administration header
#
# Copyright (C) 2012  Matt Florell <vicidial@gmail.com>    LICENSE: AGPLv2
# 

# CHANGES
# 90310-0709 - First Build
# 90508-0542 - Added Call Menu option, changed script to use long PHP tags
# 90514-0605 - Added audio prompt selection functions
# 90530-1206 - Changed List Mix to allow for 40 mixes and a default populate option
# 90531-2339 - Added Dynamic options for Call Menu
# 90612-0852 - Changed relative links
# 90635-0943 - Added javascript for dynamic menus in In-Groups
# 90627-0548 - Added no-agent-no-queue options
# 90628-1016 - Added Text-to-speech options
# 90830-2213 - Added Music On Hold options
# 90904-1534 - Added launch_moh_chooser
# 90916-2334 - Added Voicemail options
# 91223-1030 - Added VIDPROMPT options for in-group routing in Call Menus
# 100311-2210 - Added callcard_enabled Admin element
# 100428-1039 - Added custom fields display
# 100507-1339 - Added copy carrier submenu
# 100616-2350 - Added VIDPROMPT call menu options
# 100728-0904 - Changed Lead Loader link to the new 3rd gen lead loader
# 100802-2127 - Changed Admin to point to links page instead of Phones listings
# 100831-2255 - Added password strength checking function
# 100914-1311 - Removed other links for reports-only users
# 101022-1323 - Added IGU_selectall function
# 101107-1133 - Added auto-refresh code
# 110215-1720 - Added the Add a new lead link
# 110322-1228 - Added user ID logged in as next to Logout link
# 110624-1439 - Added Screen Labels sub-section to Admin
# 110831-2048 - Added AC-CID to campaign submenu
# 110922-1707 - Added RA-EXTEN to campaign submenu
# 111015-2305 - Added Contacts menu to Admin
# 111106-0939 - Changes for user group restrictions
# 111116-0208 - Added ALT and ADDR3 in-group handle methods
# 120402-2134 - Changed lead loader link to fourth gen
#


######################### SMALL HTML HEADER BEGIN #######################################
if($short_header)
	{
	?>
	<TABLE CELLPADDING=0 CELLSPACING=0 BGCOLOR="#015B91"><TR>
	<TD><IMG SRC="vicidial_admin_web_logo_small.gif" WIDTH=71 HEIGHT=22> &nbsp; </TD>
	<?php if ($reports_only_user < 1) {
		?>
	<TD> &nbsp; <A HREF="admin.php" ALT="Users"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Users</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=10" ALT="Campaigns"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Campaigns</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=100" ALT="Lists"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Lists</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=1000000" ALT="Scripts"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Scripts</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=10000000" ALT="Filters"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Filters</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=1000" ALT="Inbound"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Inbound</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=100000" ALT="User Groups"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>User Groups</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=10000" ALT="Remote Agents"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Remote Agents</B></A> &nbsp; </TD>
	<TD> &nbsp; <A HREF="admin.php?ADD=999998" ALT="Admin"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Admin</B></A> &nbsp; </TD>
	<?php 
		} 
	else 
		{ ?>
	<TD width=600> &nbsp; &nbsp; </TD>
	<?php } ?>
	<TD> &nbsp; <A HREF="admin.php?ADD=999999" ALT="Reports"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B>Reports</B></A> &nbsp; </TD>
	</TR>
	</TABLE>
	<?php
	}
######################### SMALL HTML HEADER END #######################################


######################### FULL HTML HEADER BEGIN #######################################
else
{
if ($hh=='users') 
	{$users_hh="bgcolor =\"$users_color\""; $users_fc="$users_font"; $users_bold="$header_selected_bold";}
	else {$users_hh=''; $users_fc='WHITE'; $users_bold="$header_nonselected_bold";}
if ($hh=='campaigns') 
	{$campaigns_hh="bgcolor=\"$campaigns_color\""; $campaigns_fc="$campaigns_font"; $campaigns_bold="$header_selected_bold";}
	else {$campaigns_hh=''; $campaigns_fc='WHITE'; $campaigns_bold="$header_nonselected_bold";}
if ($SSoutbound_autodial_active > 0)
	{
	if ($hh=='lists') 
		{$lists_hh="bgcolor=\"$lists_color\""; $lists_fc="$lists_font"; $lists_bold="$header_selected_bold";}
		else {$lists_hh=''; $lists_fc='WHITE'; $lists_bold="$header_nonselected_bold";}
	}
if ($hh=='ingroups') 
	{$ingroups_hh="bgcolor=\"$ingroups_color\""; $ingroups_fc="$ingroups_font"; $ingroups_bold="$header_selected_bold";}
	else {$ingroups_hh=''; $ingroups_fc='WHITE'; $ingroups_bold="$header_nonselected_bold";}
if ($hh=='remoteagent') 
	{$remoteagent_hh="bgcolor=\"$remoteagent_color\""; $remoteagent_fc="$remoteagent_font"; $remoteagent_bold="$header_selected_bold";}
	else {$remoteagent_hh=''; $remoteagent_fc='WHITE'; $remoteagent_bold="$header_nonselected_bold";}
if ($hh=='usergroups') 
	{$usergroups_hh="bgcolor=\"$usergroups_color\""; $usergroups_fc="$usergroups_font"; $usergroups_bold="$header_selected_bold";}
	else {$usergroups_hh=''; $usergroups_fc='WHITE'; $usergroups_bold="$header_nonselected_bold";}
if ($hh=='scripts') 
	{$scripts_hh="bgcolor=\"$scripts_color\""; $scripts_fc="$scripts_font"; $scripts_bold="$header_selected_bold";}
	else {$scripts_hh=''; $scripts_fc='WHITE'; $scripts_bold="$header_nonselected_bold";}
if ($SSoutbound_autodial_active > 0)
	{
	if ($hh=='filters') 
		{$filters_hh="bgcolor=\"$filters_color\""; $filters_fc="$filters_font"; $filters_bold="$header_selected_bold";}
		else {$filters_hh=''; $filters_fc='WHITE'; $filters_bold="$header_nonselected_bold";}
	}
if ($hh=='admin') 
	{$admin_hh="bgcolor=\"$admin_color\""; $admin_fc="$admin_font"; $admin_bold="$header_selected_bold";}
	else {$admin_hh=''; $admin_fc='WHITE'; $admin_bold="$header_nonselected_bold";}
if ($hh=='reports') 
	{$reports_hh="bgcolor=\"$reports_color\""; $reports_fc="$reports_font"; $reports_bold="$header_selected_bold";}
	else {$reports_hh=''; $reports_fc='WHITE'; $reports_bold="$header_nonselected_bold";}

if ($hh=='recording') 
	{$recording_hh="bgcolor=\"$recording_color\""; $recording_fc="$recording_font"; $recording_bold="$header_selected_bold";}
	else {$recording_hh=''; $recording_fc='WHITE'; $recording_bold="$header_nonselected_bold";}	

echo "</title>\n";
echo "<script language=\"Javascript\">\n";
echo "var field_name = '';\n";
echo "var user = '$PHP_AUTH_USER';\n";
echo "var pass = '$PHP_AUTH_PW';\n";
echo "var epoch = '" . date("U") . "';\n";

if ($TCedit_javascript > 0)
	{
	 ?>

	function run_submit()
		{
		calculate_hours();
		var go_submit = document.getElementById("go_submit");
		if (go_submit.disabled == false)
			{
			document.edit_log.submit();
			}
		}

	// Calculate login time
	function calculate_hours() 
		{
		var now_epoch = '<?php echo $StarTtimE ?>';
		var i=0;
		var total_percent=0;
		var SPANlogin_time = document.getElementById("LOGINlogin_time");
		var LI_date = document.getElementById("LOGINbegin_date");
		var LO_date = document.getElementById("LOGOUTbegin_date");
		var LI_datetime = LI_date.value;
		var LO_datetime = LO_date.value;
		var LI_datetime_array=LI_datetime.split(" ");
		var LI_date_array=LI_datetime_array[0].split("-");
		var LI_time_array=LI_datetime_array[1].split(":");
		var LO_datetime_array=LO_datetime.split(" ");
		var LO_date_array=LO_datetime_array[0].split("-");
		var LO_time_array=LO_datetime_array[1].split(":");

		// Calculate milliseconds since 1970 for each date string and find diff
		var LI_sec = ( ( (LI_time_array[2] * 1) * 1000) );
		var LI_min = ( ( ( (LI_time_array[1] * 1) * 1000) * 60 ) );
		var LI_hour = ( ( ( (LI_time_array[0] * 1) * 1000) * 3600 ) );
		var LI_date_epoch = Date.parse(LI_date_array[0] + '/' + LI_date_array[1] + '/' + LI_date_array[2]);
		var LI_epoch = (LI_date_epoch + LI_sec + LI_min + LI_hour);
		var LO_sec = ( ( (LO_time_array[2] * 1) * 1000) );
		var LO_min = ( ( ( (LO_time_array[1] * 1) * 1000) * 60 ) );
		var LO_hour = ( ( ( (LO_time_array[0] * 1) * 1000) * 3600 ) );
		var LO_date_epoch = Date.parse(LO_date_array[0] + '/' + LO_date_array[1] + '/' + LO_date_array[2]);
		var LO_epoch = (LO_date_epoch + LO_sec + LO_min + LO_hour);
		var temp_LI_epoch = (LI_epoch / 1000 );
		var temp_LO_epoch = (LO_epoch / 1000 );
		var epoch_diff = ( (LO_epoch - LI_epoch) / 1000 );
		var temp_diff = epoch_diff;

		document.getElementById("login_time").innerHTML = "ERROR, Please check date fields";

		var go_submit = document.getElementById("go_submit");
		go_submit.disabled = true;
		// length is a positive number and no more than 24 hours, datetime is earlier than right now
		if ( (epoch_diff < 86401) && (epoch_diff > 0) && (temp_LI_epoch < now_epoch) && (temp_LO_epoch < now_epoch) )
			{
			go_submit.disabled = false;

			hours = Math.floor(temp_diff / (60 * 60)); 
			temp_diff -= hours * (60 * 60);

			mins = Math.floor(temp_diff / 60); 
			temp_diff -= mins * 60;

			secs = Math.floor(temp_diff); 
			temp_diff -= secs;

			document.getElementById("login_time").innerHTML = hours + ":" + mins;

			var form_LI_epoch = document.getElementById("LOGINepoch");
			var form_LO_epoch = document.getElementById("LOGOUTepoch");
			form_LI_epoch.value = (LI_epoch / 1000);
			form_LO_epoch.value = (LO_epoch / 1000);
			}
		}



	<?php
	}
######################
# ADD=31 or 34 and SUB=29 for list mixes
######################
if ( ( ($ADD==34) or ($ADD==31) or ($ADD==49) ) and ($SUB==29) and ($LOGmodify_campaigns==1) and ( (eregi("$campaign_id",$LOGallowed_campaigns)) or (eregi("ALL-CAMPAIGNS",$LOGallowed_campaigns)) ) ) 
	{

	?>
	// List Mix status add and remove
	function mod_mix_status(stage,vcl_id,entry) 
		{
		if (stage=="ALL")
			{
			var count=0;
			var ROnew_statuses = document.getElementById("ROstatus_X_" + vcl_id);

			while (count < entry)
				{
				var old_statuses = document.getElementById("status_" + count + "_" + vcl_id);
				var ROold_statuses = document.getElementById("ROstatus_" + count + "_" + vcl_id);

				old_statuses.value = ROnew_statuses.value;
				ROold_statuses.value = ROnew_statuses.value;
				count++;
				}
			}
		else
			{
			if (stage=="EMPTY")
				{
				var count=0;
				var ROnew_statuses = document.getElementById("ROstatus_X_" + vcl_id);

				while (count < entry)
					{
					var old_statuses = document.getElementById("status_" + count + "_" + vcl_id);
					var ROold_statuses = document.getElementById("ROstatus_" + count + "_" + vcl_id);
					
					if (ROold_statuses.value.length < 3)
						{
						old_statuses.value = ROnew_statuses.value;
						ROold_statuses.value = ROnew_statuses.value;
						}
					count++;
					}
				}

			else
				{
				var mod_status = document.getElementById("dial_status_" + entry + "_" + vcl_id);
				if (mod_status.value.length < 1)
					{
					alert("You must select a status first");
					}
				else
					{
					var old_statuses = document.getElementById("status_" + entry + "_" + vcl_id);
					var ROold_statuses = document.getElementById("ROstatus_" + entry + "_" + vcl_id);
					var MODstatus = new RegExp(" " + mod_status.value + " ","g");
					if (stage=="ADD")
						{
						if (old_statuses.value.match(MODstatus))
							{
							alert("The status " + mod_status.value + " is already present");
							}
						else
							{
							var new_statuses = " " + mod_status.value + "" + old_statuses.value;
							old_statuses.value = new_statuses;
							ROold_statuses.value = new_statuses;
							mod_status.value = "";
							}
						}
					if (stage=="REMOVE")
						{
						var MODstatus = new RegExp(" " + mod_status.value + " ","g");
						old_statuses.value = old_statuses.value.replace(MODstatus, " ");
						ROold_statuses.value = ROold_statuses.value.replace(MODstatus, " ");
						}
					}
				}
			}
		}

	// List Mix percent difference calculation and warning message
	function mod_mix_percent(vcl_id,entries) 
		{
		var i=0;
		var total_percent=0;
		var percent_diff='';
		while(i < entries)
			{
			var mod_percent_field = document.getElementById("percentage_" + i + "_" + vcl_id);
			temp_percent = mod_percent_field.value * 1;
			total_percent = (total_percent + temp_percent);
			i++;
			}

		var mod_diff_percent = document.getElementById("PCT_DIFF_" + vcl_id);
		percent_diff = (total_percent - 100);
		if (percent_diff > 0)
			{
			percent_diff = '+' + percent_diff;
			}
		var mix_list_submit = document.getElementById("submit_" + vcl_id);
		if ( (percent_diff > 0) || (percent_diff < 0) )
			{
			mix_list_submit.disabled = true;
			document.getElementById("ERROR_" + vcl_id).innerHTML = "<font color=red><B>The Difference % must be 0</B></font>";
			}
		else
			{
			mix_list_submit.disabled = false;
			document.getElementById("ERROR_" + vcl_id).innerHTML = "";
			}

		mod_diff_percent.value = percent_diff;
		}

	function submit_mix(vcl_id,entries) 
		{
		var h=1;
		var j=1;
		var list_mix_container='';
		var mod_list_mix_container_field = document.getElementById("list_mix_container_" + vcl_id);
		while(h < 41)
			{
			var i=0;
			while(i < entries)
				{
				var mod_list_id_field = document.getElementById("list_id_" + i + "_" + vcl_id);
				var mod_priority_field = document.getElementById("priority_" + i + "_" + vcl_id);
				var mod_percent_field = document.getElementById("percentage_" + i + "_" + vcl_id);
				var mod_statuses_field = document.getElementById("status_" + i + "_" + vcl_id);
				if (mod_priority_field.value==h)
					{
					list_mix_container = list_mix_container + mod_list_id_field.value + "|" + j + "|" + mod_percent_field.value + "|" + mod_statuses_field.value + "|:";
					j++;
					}
				i++;
				}
			h++;
			}
		mod_list_mix_container_field.value = list_mix_container;
		var form_to_submit = document.getElementById("" + vcl_id);
		form_to_submit.submit();
		}
	<?php
	}
	?>
	var weak = new Image();
	weak.src = "images/weak.png";
	var medium = new Image();
	medium.src = "images/medium.png";
	var strong = new Image();
	strong.src = "images/strong.png";

	function pwdChanged(pwd_field_str, pwd_img_str) 
		{
		var pwd_field = document.getElementById(pwd_field_str);
		var pwd_img = document.getElementById(pwd_img_str);

		var strong_regex = new RegExp( "^(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])", "g" );
		var medium_regex = new RegExp( "^(?=.{6,})(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9]))).*$", "g" );

		if (strong_regex.test(pwd_field.value) ) 
			{
			if (pwd_img.src != strong.src)
				{pwd_img.src = strong.src;}
			} 
		else if (medium_regex.test( pwd_field.value) ) 
			{
			if (pwd_img.src != medium.src) 
				{pwd_img.src = medium.src;}
			}
		else 
			{
			if (pwd_img.src != weak.src) 
				{pwd_img.src = weak.src;}
			}
		}

	function openNewWindow(url) 
		{
		window.open (url,"",'width=620,height=300,scrollbars=yes,menubar=yes,address=yes');
		}
	function scriptInsertField() 
		{
		openField = '--A--';
		closeField = '--B--';
		var textBox = document.scriptForm.script_text;
		var scriptIndex = document.getElementById("selectedField").selectedIndex;
		var insValue =  document.getElementById('selectedField').options[scriptIndex].value;
		if (document.selection) 
			{
			//IE
			textBox = document.scriptForm.script_text;
			insValue = document.scriptForm.selectedField.options[document.scriptForm.selectedField.selectedIndex].text;
			textBox.focus();
			sel = document.selection.createRange();
			sel.text = openField + insValue + closeField;
			} 
		else if (textBox.selectionStart || textBox.selectionStart == 0) 
			{
			//Mozilla
			var startPos = textBox.selectionStart;
			var endPos = textBox.selectionEnd;
			textBox.value = textBox.value.substring(0, startPos)
			+ openField + insValue + closeField
			+ textBox.value.substring(endPos, textBox.value.length);
			}
		else 
			{
			textBox.value += openField + insValue + closeField;
			}
		}

	<?php

#### Javascript for auto-generate of user ID Button
if ( ($SSadmin_modify_refresh > 1) and (preg_match("/^3|^4/",$ADD)) )
	{
	?>
	var ar_seconds=<?php echo "$SSadmin_modify_refresh;"; ?>

	function modify_refresh_display()
		{
		if (ar_seconds > 0)
			{
			ar_seconds = (ar_seconds - 1);
			document.getElementById("refresh_countdown").innerHTML = "<font color=black> screen refresh in: " + ar_seconds + " seconds</font>";
			setTimeout("modify_refresh_display()",1000);
			}
		}

	<?php
	}

#### Javascript for auto-generate of user ID Button
if ( ($ADD==1) or ($ADD=="1A") )
	{
	?>

	function user_auto()
		{
		var user_toggle = document.getElementById("user_toggle");
		var user_field = document.getElementById("user");
		if (user_toggle.value < 1)
			{
			user_field.value = 'AUTOGENERATEZZZ';
			user_field.disabled = true;
			user_toggle.value = 1;
			}
		else
			{
			user_field.value = '';
			user_field.disabled = false;
			user_toggle.value = 0;
			}
		}

	function user_submit()
		{
		var user_field = document.getElementById("user");
		user_field.disabled = false;
		document.userform.submit();
		}

	<?php
	}

#### Javascript for auto-generate of user ID Button
else
	{
	?>
	function launch_chooser(fieldname,stage)
		{
		var audiolistURL = "./non_agent_api.php";
		var left = (screen.width/4);
		var top = (screen.height/4);
		var audiolistQuery = "source=admin&function=sounds_list&user=" + user + "&pass=" + pass + "&format=selectframe&stage=" + stage + "&comments=" + fieldname;
		var Iframe_content = '<IFRAME SRC="' + audiolistURL + '?' + audiolistQuery + '"  style="width:740;height:440;background-color:white;" scrolling="NO" frameborder="0" allowtransparency="true" id="audio_chooser_frame' + epoch + '" name="audio_chooser_frame" width="740" height="460" STYLE="z-index:2"> </iframe>';

		document.getElementById("audio_chooser_span").style.position = "absolute";
		document.getElementById("audio_chooser_span").style.left = left + "px";
		document.getElementById("audio_chooser_span").style.top = top + "px";
		document.getElementById("audio_chooser_span").style.visibility = 'visible';
		document.getElementById("audio_chooser_span").innerHTML = Iframe_content;
		//document.getElementById("audio_chooser_span").style.left = "220px";
		//document.getElementById("audio_chooser_span").style.top = vposition + "px";
		}

	function launch_moh_chooser(fieldname,stage)
		{
		var left = (screen.width/4);
		var top = (screen.height/4);
		var audiolistURL = "./non_agent_api.php";
		var audiolistQuery = "source=admin&function=moh_list&user=" + user + "&pass=" + pass + "&format=selectframe&stage=" + stage + "&comments=" + fieldname;
		var Iframe_content = '<IFRAME SRC="' + audiolistURL + '?' + audiolistQuery + '"  style="width:740;height:440;background-color:white;" scrolling="NO" frameborder="0" allowtransparency="true" id="audio_chooser_frame' + epoch + '" name="audio_chooser_frame" width="740" height="460" STYLE="z-index:2"> </iframe>';

		document.getElementById("audio_chooser_span").style.position = "absolute";
		document.getElementById("audio_chooser_span").style.left = left + "px";
		document.getElementById("audio_chooser_span").style.top = top + "px";
		document.getElementById("audio_chooser_span").style.visibility = 'visible';
		document.getElementById("audio_chooser_span").innerHTML = Iframe_content;
		//document.getElementById("audio_chooser_span").style.left = "220px";
		//document.getElementById("audio_chooser_span").style.top = vposition + "px";
		}

	function launch_vm_chooser(fieldname,stage)
		{
		var left = (screen.width/4);
		var top = (screen.height/4);		
		var audiolistURL = "./non_agent_api.php";
		var audiolistQuery = "source=admin&function=vm_list&user=" + user + "&pass=" + pass + "&format=selectframe&stage=" + stage + "&comments=" + fieldname;
		var Iframe_content = '<IFRAME SRC="' + audiolistURL + '?' + audiolistQuery + '"  style="width:740;height:440;background-color:white;" scrolling="NO" frameborder="0" allowtransparency="true" id="audio_chooser_frame' + epoch + '" name="audio_chooser_frame" width="740" height="460" STYLE="z-index:2"> </iframe>';

		document.getElementById("audio_chooser_span").style.position = "absolute";
		document.getElementById("audio_chooser_span").style.left = left + "px";
		document.getElementById("audio_chooser_span").style.top = top + "px";
		document.getElementById("audio_chooser_span").style.visibility = 'visible';
		document.getElementById("audio_chooser_span").innerHTML = Iframe_content;
		//document.getElementById("audio_chooser_span").style.left = "220px";
		//document.getElementById("audio_chooser_span").style.top = vposition + "px";
		}

	function close_chooser()
		{
		document.getElementById("audio_chooser_span").style.visibility = 'hidden';
		document.getElementById("audio_chooser_span").innerHTML = '';
		}


	function user_submit()
		{
		var user_field = document.getElementById("user");
		user_field.disabled = false;
		document.userform.submit();
		}

	<?php
	}

### Javascript for shift end-time calculation and display
if ( ($ADD==131111111) or ($ADD==331111111) or ($ADD==431111111) )
	{
	?>
	function shift_time()
		{
		var start_time = document.getElementById("shift_start_time");
		var end_time = document.getElementById("shift_end_time");
		var length = document.getElementById("shift_length");

		var st_value = start_time.value;
		var et_value = end_time.value;
		while (st_value.length < 4) {st_value = "0" + st_value;}
		while (et_value.length < 4) {et_value = "0" + et_value;}
		var st_hour=st_value.substring(0,2);
		var st_min=st_value.substring(2,4);
		var et_hour=et_value.substring(0,2);
		var et_min=et_value.substring(2,4);
		if (st_hour > 23) {st_hour = 23;}
		if (et_hour > 23) {et_hour = 23;}
		if (st_min > 59) {st_min = 59;}
		if (et_min > 59) {et_min = 59;}
		start_time.value = st_hour + "" + st_min;
		end_time.value = et_hour + "" + et_min;

		var start_time_hour=start_time.value.substring(0,2);
		var start_time_min=start_time.value.substring(2,4);
		var end_time_hour=end_time.value.substring(0,2);
		var end_time_min=end_time.value.substring(2,4);
		start_time_hour=(start_time_hour * 1);
		start_time_min=(start_time_min * 1);
		end_time_hour=(end_time_hour * 1);
		end_time_min=(end_time_min * 1);

		if (start_time.value == end_time.value)
			{
			var shift_length = '24:00';
			}
		else
			{
			if ( (start_time_hour > end_time_hour) || ( (start_time_hour == end_time_hour) && (start_time_min > end_time_min) ) )
				{
				var shift_hour = ( (24 - start_time_hour) + end_time_hour);
				var shift_minute = ( (60 - start_time_min) + end_time_min);
				if (shift_minute >= 60) 
					{
					shift_minute = (shift_minute - 60);
					}
				else
					{
					shift_hour = (shift_hour - 1);
					}
				}
			else
				{
				var shift_hour = (end_time_hour - start_time_hour);
				var shift_minute = (end_time_min - start_time_min);
				}
			if (shift_minute < 0) 
				{
				shift_minute = (shift_minute + 60);
				shift_hour = (shift_hour - 1);
				}

			if (shift_hour < 10) {shift_hour = '0' + shift_hour}
			if (shift_minute < 10) {shift_minute = '0' + shift_minute}
			var shift_length = shift_hour + ':' + shift_minute;
			}
	//	alert(start_time_hour + '|' + start_time_min + '|' + end_time_hour + '|' + end_time_min + '|--|' + shift_hour + ':' + shift_minute + '|' + shift_length + '|');

		length.value = shift_length;
		}

	<?php
	}




### Javascript for shift end-time calculation and display
if ( ($ADD==3111) or ($ADD==4111) or ($ADD==5111) )
	{
	?>
	function IGU_selectall(temp_count,temp_fields)
		{
		var fields_array=temp_fields.split('|');
		var inc=0;
		while (temp_count >= inc)
			{
			if (fields_array[inc].length > 0)
				{
				document.getElementById(fields_array[inc]).checked=true;
			//	document.admin_form.fields_array[inc].checked=true;
				}
			inc++;
			}
		}

	<?php
	}


$stmt="SELECT menu_id,menu_name from vicidial_call_menu $whereLOGadmin_viewable_groupsSQL order by menu_id limit 10000;";
$rslt=mysql_query($stmt, $link);
$menus_to_print = mysql_num_rows($rslt);
$call_menu_list='';
$i=0;
while ($i < $menus_to_print)
	{
	$row=mysql_fetch_row($rslt);
	$call_menu_list .= "<option value=\"$row[0]\">$row[0] - $row[1]</option>";
	$i++;
	}

### select list contents generation for dynamic route displays in call menu and in-group screens
if ( ($ADD==3511) or ($ADD==2511) or ($ADD==2611) or ($ADD==4511) or ($ADD==5511) or ($ADD==3111) or ($ADD==2111) or ($ADD==2011) or ($ADD==4111) or ($ADD==5111) )
	{
	$stmt="SELECT did_pattern,did_description,did_route from vicidial_inbound_dids where did_active='Y' $LOGadmin_viewable_groupsSQL order by did_pattern;";
	$rslt=mysql_query($stmt, $link);
	$dids_to_print = mysql_num_rows($rslt);
	$did_list='';
	$i=0;
	while ($i < $dids_to_print)
		{
		$row=mysql_fetch_row($rslt);
		$did_list .= "<option value=\"$row[0]\">$row[0] - $row[1] - $row[2]</option>";
		$i++;
		}

	$stmt="SELECT group_id,group_name from vicidial_inbound_groups where active='Y' and group_id NOT LIKE \"AGENTDIRECT%\" $LOGadmin_viewable_groupsSQL order by group_id;";
	$rslt=mysql_query($stmt, $link);
	$ingroups_to_print = mysql_num_rows($rslt);
	$ingroup_list='';
	$i=0;
	while ($i < $ingroups_to_print)
		{
		$row=mysql_fetch_row($rslt);
		$ingroup_list .= "<option value=\"$row[0]\">$row[0] - $row[1]</option>";
		$i++;
		}

	$stmt="SELECT campaign_id,campaign_name from vicidial_campaigns where active='Y' $LOGallowed_campaignsSQL order by campaign_id;";
	$rslt=mysql_query($stmt, $link);
	$IGcampaigns_to_print = mysql_num_rows($rslt);
	$IGcampaign_id_list='';
	$i=0;
	while ($i < $IGcampaigns_to_print)
		{
		$row=mysql_fetch_row($rslt);
		$IGcampaign_id_list .= "<option value=\"$row[0]\">$row[0] - $row[1]</option>";
		$i++;
		}

	$IGhandle_method_list = '<option>CID</option><option>CIDLOOKUP</option><option>CIDLOOKUPRL</option><option>CIDLOOKUPRC</option><option>CIDLOOKUPALT</option><option>CIDLOOKUPRLALT</option><option>CIDLOOKUPRCALT</option><option>CIDLOOKUPADDR3</option><option>CIDLOOKUPRLADDR3</option><option>CIDLOOKUPRCADDR3</option><option>CIDLOOKUPALTADDR3</option><option>CIDLOOKUPRLALTADDR3</option><option>CIDLOOKUPRCALTADDR3</option><option>ANI</option><option>ANILOOKUP</option><option>ANILOOKUPRL</option><option>VIDPROMPT</option><option>VIDPROMPTLOOKUP</option><option>VIDPROMPTLOOKUPRL</option><option>VIDPROMPTLOOKUPRC</option><option>CLOSER</option><option>3DIGITID</option><option>4DIGITID</option><option>5DIGITID</option><option>10DIGITID</option>';

	$IGsearch_method_list = '<option value="LB">LB - Load Balanced</option><option value="LO">LO - Load Balanced Overflow</option><option value="SO">SO - Server Only</option>';

	$stmt="SELECT login,server_ip,extension,dialplan_number from phones where active='Y' $LOGadmin_viewable_groupsSQL order by login,server_ip;";
	$rslt=mysql_query($stmt, $link);
	$phones_to_print = mysql_num_rows($rslt);
	$phone_list='';
	$i=0;
	while ($i < $phones_to_print)
		{
		$row=mysql_fetch_row($rslt);
		$phone_list .= "<option value=\"$row[0]\">$row[0] - $row[1] - $row[2] - $row[3]</option>";
		$i++;
		}
	}

# dynamic options for options in call_menu screen
if ( ($ADD==3511) or ($ADD==2511) or ($ADD==2611) or ($ADD==4511) or ($ADD==5511) )
	{

	?>
	function call_menu_option(option,route,value,value_context,chooser_height)
		{
		var call_menu_list = '<?php echo $call_menu_list ?>';
		var ingroup_list = '<?php echo $ingroup_list ?>';
		var IGcampaign_id_list = '<?php echo $IGcampaign_id_list ?>';
		var IGhandle_method_list = '<?php echo $IGhandle_method_list ?>';
		var IGsearch_method_list = '<?php echo $IGsearch_method_list ?>';
		var did_list = '<?php echo $did_list ?>';
		var phone_list = '<?php echo $phone_list ?>';
		var selected_value = '';
		var selected_context = '';
		var new_content = '';

		var select_list = document.getElementById("option_route_" + option);
		var selected_route = select_list.value;
		var span_to_update = document.getElementById("option_value_value_context_" + option);

		if (selected_route=='CALLMENU')
			{
			if (route == selected_route)
				{
				selected_value = '<option SELECTED value="' + value + '">' + value + "</option>\n";
				}
			else
				{value='';}
			new_content = '<span name=option_route_link_' + option + ' id=option_route_link_' + option + "><a href=\"./admin.php?ADD=3511&menu_id=" + value + "\">Call Menu: </a></span><select size=1 name=option_route_value_" + option + " id=option_route_value_" + option + " onChange=\"call_menu_link('" + option + "','CALLMENU');\">" + call_menu_list + "\n" + selected_value + '</select>';
			}
		if (selected_route=='INGROUP')
			{
			if (value_context.length < 10)
				{value_context = 'CID,LB,998,TESTCAMP,1,,,,';}
			var value_context_split =		value_context.split(",");
			var IGhandle_method =			value_context_split[0];
			var IGsearch_method =			value_context_split[1];
			var IGlist_id =					value_context_split[2];
			var IGcampaign_id =				value_context_split[3];
			var IGphone_code =				value_context_split[4];
			var IGvid_enter_filename =		value_context_split[5];
			var IGvid_id_number_filename =	value_context_split[6];
			var IGvid_confirm_filename =	value_context_split[7];
			var IGvid_validate_digits =		value_context_split[8];

			if (route == selected_route)
				{
				selected_value = '<option SELECTED>' + value + '</option>';
				}

			new_content = '<input type=hidden name=option_route_value_context_' + option + ' id=option_route_value_context_' + option + ' value="' + selected_value + '">';
			new_content = new_content + '<span name=option_route_link_' + option + 'id=option_route_link_' + option + '>';
			new_content = new_content + '<a href="admin.php?ADD=3111&group_id=' + value + '">In-Group:</a> </span>';
			new_content = new_content + '<select size=1 name=option_route_value_' + option + ' id=option_route_value_' + option + ' onChange="call_menu_link("' + option + '","INGROUP");">';
			new_content = new_content + '' + ingroup_list + "\n" + selected_value + '</select>';
			new_content = new_content + ' &nbsp; Handle Method: <select size=1 name=IGhandle_method_' + option + ' id=IGhandle_method_' + option + '>';
			new_content = new_content + '' + IGhandle_method_list + "\n" + '<option SELECTED>' + IGhandle_method + '</select>';
			new_content = new_content + ' &nbsp; <a href="javascript:openNewWindow(\'admin.php?ADD=99999#vicidial_call_menu-ingroup_settings\')"><IMG SRC="help.gif" WIDTH=20 HEIGHT=20 BORDER=0 ALT="HELP" ALIGN=TOP></a>';
			new_content = new_content + 'Search Method: <select size=1 name=IGsearch_method_' + option + ' id=IGsearch_method_' + option + '>';
			new_content = new_content + '' + IGsearch_method_list + "\n" + '<option SELECTED>' + IGsearch_method + '</select>';
			new_content = new_content + ' &nbsp; List ID: <input type=text size=5 maxlength=14 name=IGlist_id_' + option + ' id=IGlist_id_' + option + ' value="' + IGlist_id + '">';
			new_content = new_content + 'Campaign ID: <select size=1 name=IGcampaign_id_' + option + ' id=IGcampaign_id_' + option + '>';
			new_content = new_content + '' + IGcampaign_id_list + "\n" + '<option SELECTED>' + IGcampaign_id + '</select>';
			new_content = new_content + ' &nbsp; Phone Code: <input type=text size=5 maxlength=14 name=IGphone_code_' + option + ' id=IGphone_code_' + option + ' value="' + IGphone_code + '">';
			new_content = new_content + " &nbsp; VID Enter Filename: <input type=text name=IGvid_enter_filename_" + option + " id=IGvid_enter_filename_" + option + " size=40 maxlength=255 value=\"" + IGvid_enter_filename + "\"> <a href=\"javascript:launch_chooser('IGvid_enter_filename_" + option + "','date'," + chooser_height + ");\">audio chooser</a>";
			new_content = new_content + " &nbsp; VID ID Number Filename: <input type=text name=IGvid_id_number_filename_" + option + " id=IGvid_id_number_filename_" + option + " size=40 maxlength=255 value=\"" + IGvid_id_number_filename + "\"> <a href=\"javascript:launch_chooser('IGvid_id_number_filename_" + option + "','date'," + chooser_height + ");\">audio chooser</a>";
			new_content = new_content + " &nbsp; VID Confirm Filename: <input type=text name=IGvid_confirm_filename_" + option + " id=IGvid_confirm_filename_" + option + " size=40 maxlength=255 value=\"" + IGvid_confirm_filename + "\"> <a href=\"javascript:launch_chooser('IGvid_confirm_filename_" + option + "','date'," + chooser_height + ");\">audio chooser</a>";
			new_content = new_content + ' &nbsp; VID Digits: <input type=text size=3 maxlength=3 name=IGvid_validate_digits_' + option + ' id=IGvid_validate_digits_' + option + ' value="' + IGvid_validate_digits + '">';
			}
		if (selected_route=='DID')
			{
			if (route == selected_route)
				{
				selected_value = '<option SELECTED value="' + value + '">' + value + "</option>\n";
				}
			else
				{value='';}
			new_content = '<span name=option_route_link_' + option + ' id=option_route_link_' + option + '><a href="admin.php?ADD=3311&did_pattern=' + value + '">DID:</a> </span><select size=1 name=option_route_value_' + option + ' id=option_route_value_' + option + " onChange=\"call_menu_link('" + option + "','DID');\">" + did_list + "\n" + selected_value + '</select>';
			}
		if (selected_route=='HANGUP')
			{
			if (route == selected_route)
				{
				selected_value = value;
				}
			else
				{value='vm-goodbye';}
			new_content = "Audio File: <input type=text name=option_route_value_" + option + " id=option_route_value_" + option + " size=40 maxlength=255 value=\"" + selected_value + "\"> <a href=\"javascript:launch_chooser('option_route_value_" + option + "','date'," + chooser_height + ");\">audio chooser</a>";
			}
		if (selected_route=='EXTENSION')
			{
			if (route == selected_route)
				{
				selected_value = value;
				selected_context = value_context;
				}
			else
				{value='8304';}
			new_content = "Extension: <input type=text name=option_route_value_" + option + " id=option_route_value_" + option + " size=20 maxlength=255 value=\"" + selected_value + "\"> &nbsp; Context: <input type=text name=option_route_value_context_" + option + " id=option_route_value_context_" + option + " size=20 maxlength=255 value=\"" + selected_context + "\"> ";
			}
		if (selected_route=='PHONE')
			{
			if (route == selected_route)
				{
				selected_value = '<option SELECTED value="' + value + '">' + value + "</option>\n";
				}
			else
				{value='';}
			new_content = 'Phone: <select size=1 name=option_route_value_' + option + ' id=option_route_value_' + option + '>' + phone_list + "\n" + selected_value + '</select>';
			}
		if (selected_route=='VOICEMAIL')
			{
			if (route == selected_route)
				{
				selected_value = value;
				}
			else
				{value='';}
			new_content = "Voicemail Box: <input type=text name=option_route_value_" + option + " id=option_route_value_" + option + " size=12 maxlength=10 value=\"" + selected_value + "\"> <a href=\"javascript:launch_vm_chooser('option_route_value_" + option + "','date'," + chooser_height + ");\">voicemail chooser</a>";
			}
		if (selected_route=='AGI')
			{
			if (route == selected_route)
				{
				selected_value = value;
				}
			else
				{value='';}
			new_content = "AGI: <input type=text name=option_route_value_" + option + " id=option_route_value_" + option + " size=80 maxlength=255 value=\"" + selected_value + "\"> ";
			}

		if (new_content.length < 1)
			{new_content = selected_route}

		span_to_update.innerHTML = new_content;
		}

	function call_menu_link(option,route)
		{
		var selected_value = '';
		var new_content = '';

		var select_list = document.getElementById("option_route_value_" + option);
		var selected_value = select_list.value;
		var span_to_update = document.getElementById("option_route_link_" + option);

		if (route=='CALLMENU')
			{
			new_content = "<a href=\"admin.php?ADD=3511&menu_id=" + selected_value + "\">Call Menu:</a>";
			}
		if (route=='INGROUP')
			{
			new_content = "<a href=\"admin.php?ADD=3111&group_id=" + selected_value + "\">In-Group:</a>";
			}
		if (route=='DID')
			{
			new_content = "<a href=\"admin.php?ADD=3311&did_pattern=" + selected_value + "\">DID:</a>";
			}

		if (new_content.length < 1)
			{new_content = selected_route}

		span_to_update.innerHTML = new_content;
		}

	<?php
	}

### Javascript for dynamic in-group option value entries
if ( ($ADD==3111) or ($ADD==2111) or ($ADD==2011) or ($ADD==4111) or ($ADD==5111) )
	{

	?>
	function dynamic_call_action(option,route,value,chooser_height)
		{
		var call_menu_list = '<?php echo $call_menu_list ?>';
		var ingroup_list = '<?php echo $ingroup_list ?>';
		var IGcampaign_id_list = '<?php echo $IGcampaign_id_list ?>';
		var IGhandle_method_list = '<?php echo $IGhandle_method_list ?>';
		var IGsearch_method_list = '<?php echo $IGsearch_method_list ?>';
		var did_list = '<?php echo $did_list ?>';
		var selected_value = '';
		var selected_context = '';
		var new_content = '';

		var select_list = document.getElementById(option + "");
		var selected_route = select_list.value;
		var span_to_update = document.getElementById(option + "_value_span");

		if (selected_route=='CALLMENU')
			{
			if (route == selected_route)
				{
				selected_value = '<option SELECTED value="' + value + '">' + value + "</option>\n";
				}
			else
				{value = '';}
			new_content = '<span name=' + option + '_value_link id=' + option + '_value_link><a href="./admin.php?ADD=3511&menu_id=' + value + '">Call Menu: </a></span><select size=1 name=' + option + '_value id=' + option + "_value onChange=\"dynamic_call_action_link('" + option + "','CALLMENU');\">" + call_menu_list + "\n" + selected_value + '</select>';
			}
		if (selected_route=='INGROUP')
			{
			if ( (route != selected_route) || (value.length < 10) )
				{value = 'SALESLINE,CID,LB,998,TESTCAMP,1,,,,';}
			var value_split = value.split(",");
			var IGgroup_id =				value_split[0];
			var IGhandle_method =			value_split[1];
			var IGsearch_method =			value_split[2];
			var IGlist_id =					value_split[3];
			var IGcampaign_id =				value_split[4];
			var IGphone_code =				value_split[5];
			var IGvid_enter_filename =		value_split[6];
			var IGvid_id_number_filename =	value_split[7];
			var IGvid_confirm_filename =	value_split[8];
			var IGvid_validate_digits =		value_split[9];

			if (route == selected_route)
				{
				selected_value = '<option SELECTED>' + IGgroup_id + '</option>';
				}

			new_content = new_content + '<span name=' + option + '_value_link id=' + option + '_value_link><a href="admin.php?ADD=3111&group_id=' + IGgroup_id + '">In-Group:</a> </span> ';
			new_content = new_content + '<select size=1 name=IGgroup_id_' + option + ' id=IGgroup_id_' + option + " onChange=\"dynamic_call_action_link('IGgroup_id_" + option + "','INGROUP');\">";
			new_content = new_content + '' + ingroup_list + "\n" + selected_value + '</select>';
			new_content = new_content + ' &nbsp; Handle Method: <select size=1 name=IGhandle_method_' + option + ' id=IGhandle_method_' + option + '>';
			new_content = new_content + '' + IGhandle_method_list + "\n" + '<option SELECTED>' + IGhandle_method + '</select>';
			new_content = new_content + 'Search Method: <select size=1 name=IGsearch_method_' + option + ' id=IGsearch_method_' + option + '>';
			new_content = new_content + '' + IGsearch_method_list + "\n" + '<option SELECTED>' + IGsearch_method + '</select>';
			new_content = new_content + ' &nbsp; List ID: <input type=text size=5 maxlength=14 name=IGlist_id_' + option + ' id=IGlist_id_' + option + ' value="' + IGlist_id + '">';
			new_content = new_content + 'Campaign ID: <select size=1 name=IGcampaign_id_' + option + ' id=IGcampaign_id_' + option + '>';
			new_content = new_content + '' + IGcampaign_id_list + "\n" + '<option SELECTED>' + IGcampaign_id + '</select>';
			new_content = new_content + ' &nbsp; Phone Code: <input type=text size=5 maxlength=14 name=IGphone_code_' + option + ' id=IGphone_code_' + option + ' value="' + IGphone_code + '">';
		//	new_content = new_content + " &nbsp; VID Enter Filename: <input type=text name=IGvid_enter_filename_" + option + " id=IGvid_enter_filename_" + option + " size=40 maxlength=255 value=\"" + IGvid_enter_filename + "\"> <a href=\"javascript:launch_chooser('IGvid_enter_filename_" + option + "','date'," + chooser_height + ");\">audio chooser</a>";
		//	new_content = new_content + " &nbsp; VID ID Number Filename: <input type=text name=IGvid_id_number_filename_" + option + " id=IGvid_id_number_filename_" + option + " size=40 maxlength=255 value=\"" + IGvid_id_number_filename + "\"> <a href=\"javascript:launch_chooser('IGvid_id_number_filename_" + option + "','date'," + chooser_height + ");\">audio chooser</a>";
		//	new_content = new_content + " &nbsp; VID Confirm Filename: <input type=text name=IGvid_confirm_filename_" + option + " id=IGvid_confirm_filename_" + option + " size=40 maxlength=255 value=\"" + IGvid_confirm_filename + "\"> <a href=\"javascript:launch_chooser('IGvid_confirm_filename_" + option + "','date'," + chooser_height + ");\">audio chooser</a>";
		//	new_content = new_content + ' &nbsp; VID Digits: <input type=text size=3 maxlength=3 name=IGvid_validate_digits_' + option + ' id=IGvid_validate_digits_' + option + ' value="' + IGvid_validate_digits + '">';

			}
		if (selected_route=='DID')
			{
			if (route == selected_route)
				{
				selected_value = '<option SELECTED value="' + value + '">' + value + "</option>\n";
				}
			else
				{value = '';}
			new_content = '<span name=' + option + '_value_link id=' + option + '_value_link><a href="admin.php?ADD=3311&did_pattern=' + value + '">DID:</a> </span><select size=1 name=' + option + '_value id=' + option + "_value onChange=\"dynamic_call_action_link('" + option + "','DID');\">" + did_list + "\n" + selected_value + '</select>';
			}
		if (selected_route=='MESSAGE')
			{
			if (route == selected_route)
				{
				selected_value = value;
				}
			else
				{value = 'nbdy-avail-to-take-call|vm-goodbye';}
			new_content = "Audio File: <input type=text name=" + option + "_value id=" + option + "_value size=40 maxlength=255 value=\"" + value + "\"> <a href=\"javascript:launch_chooser('" + option + "_value','date'," + chooser_height + ");\">audio chooser</a>";
			}
		if (selected_route=='EXTENSION')
			{
			if ( (route != selected_route) || (value.length < 3) )
				{value = '8304,default';}
			var value_split = value.split(",");
			var EXextension =	value_split[0];
			var EXcontext =		value_split[1];

			new_content = "Extension: <input type=text name=EXextension_" + option + " id=EXextension_" + option + " size=20 maxlength=255 value=\"" + EXextension + "\"> &nbsp; Context: <input type=text name=EXcontext_" + option + " id=EXcontext_" + option + " size=20 maxlength=255 value=\"" + EXcontext + "\"> ";
			}
		if (selected_route=='VOICEMAIL')
			{
			if (route == selected_route)
				{
				selected_value = value;
				}
			else
				{value = '101';}
			new_content = "Voicemail Box: <input type=text name=" + option + "_value id=" + option + "_value size=12 maxlength=10 value=\"" + value + "\"> <a href=\"javascript:launch_vm_chooser('" + option + "_value','date'," + chooser_height + ");\">voicemail chooser</a>";
			}

		if (new_content.length < 1)
			{new_content = selected_route}

		span_to_update.innerHTML = new_content;
		}

	function dynamic_call_action_link(field,route)
		{
		var selected_value = '';
		var new_content = '';

		if ( (route=='CALLMENU') || (route=='DID') )
			{var select_list = document.getElementById(field + "_value");}
		if (route=='INGROUP')
			{
			var select_list = document.getElementById(field + "");
			field = field.replace(/IGgroup_id_/, "");
			}
		var selected_value = select_list.value;
		var span_to_update = document.getElementById(field + "_value_link");

		if (route=='CALLMENU')
			{
			new_content = '<a href="admin.php?ADD=3511&menu_id=' + selected_value + '">Call Menu:</a>';
			}
		if (route=='INGROUP')
			{
			new_content = '<a href="admin.php?ADD=3111&group_id=' + selected_value + '">In-Group:</a>';
			}
		if (route=='DID')
			{
			new_content = '<a href="admin.php?ADD=3311&did_pattern=' + selected_value + '">DID:</a>';
			}

		if (new_content.length < 1)
			{new_content = selected_route}

		span_to_update.innerHTML = new_content;
		}

	<?php
	}
echo "</script>\n";

##### BEGIN - bar chart CSS style #####
?>

<?php
##### END - bar chart CSS style #####

echo "</head>\n";
if ( ($SSadmin_modify_refresh > 1) and (preg_match("/^3|^4/",$ADD)) )
	{
	echo "<BODY BGCOLOR=white marginheight=0 marginwidth=0 leftmargin=0 topmargin=0 onLoad=\"modify_refresh_display();\">\n";
	}
else
	{
	echo "<BODY BGCOLOR=white marginheight=0 marginwidth=0 leftmargin=0 topmargin=0>\n";
	}
	
echo "<!-- INTERNATIONALIZATION-LINKS-PLACEHOLDER-VICIDIAL -->\n";

$stmt="SELECT admin_home_url,enable_tts_integration,callcard_enabled,custom_fields_enabled from system_settings;";
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$admin_home_url_LU =		$row[0];
$SSenable_tts_integration = $row[1];
$SScallcard_enabled =		$row[2];
$SScustom_fields_enabled =	$row[3];

?>
<?php require('top-menu.php');?>
<div class="container"><div class="pg-main-area">
	<div class="row">
		<div class="col-xs-12 col-md-3">
			

<?php
if ($ADD == 999999) {
?>
<img src="images/report-left.jpg" class="img-responsive" alt="Responsive image">
<?php
}
?>


<?php
###################################################################################################################################
###Code Modified By Ketan Solanki--02-03-2015
if ($ADD != 999999 && $ADD != 999990 && $ADD != 720000000000000 && $ADD != 730000000000000 && $ADD != 710000000000000 && $ADD != 700000000000000) { ?>

<div class="list-group">
    <?php if (strlen($users_hh) > 1):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=0"><i class="fa fa-eye" aria-hidden="true"></i> Show</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1A"><i class="fa fa-files-o" aria-hidden="true"></i> Copy</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=550"><i class="fa fa-search" aria-hidden="true"></i> Search</a>
        <?php if($ADD== 0){?>
        <!--<div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=5&user=<?php echo $user;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete User </a></div>-->       
 		<?php } ?>	
        <?php if($ADD== 3){?>
        	
 			<div class="item sub_item_first"><a href="./AST_agent_days_detail.php?user=<?php echo $user;?>&query_date=<?php echo $REPORTdate;?>&end_date=<?php echo $REPORTdate;?>&group[]=--ALL--&shift=ALL"><font size='3' color='black'></font> >&nbsp;Multiple Day Status report </a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=8&user=<?php echo $user;?>"><font size='3' color='black'></font> >&nbsp;User CallBack Holds </a></div>       
 			<!--<div class="item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=USERS&stage=<?php echo $user;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes To This Record </a></div>-->
        <?php } ?>
        <!--<a class="list-group-item" href="./user_stats.php?user=<?php echo $user ?>"><i class="fa fa-link" aria-hidden="true"></i> User Stats</a>
        <a class="list-group-item" href="./user_status.php?user=<?php echo $user ?>"><i class="fa fa-link" aria-hidden="true"></i> User Status</a>
        <a class="list-group-item" href="./AST_agent_time_sheet.php?agent=<?php echo $user ?>"><i class="fa fa-link" aria-hidden="true"></i> Time Sheet</a>-->
    <?php if (($SSuser_territories_active > 0) or ($user_territories_active > 0)):?>
        <a class="list-group-item" href="./user_territories.php?agent=<?php echo $user ?>">User Territories</a>
    <?php endif; ?>
    <?php endif; ?>
    <?php if (strlen($campaigns_hh) > 1 || $campaigns_sh):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10"><i class="fa fa-eye" aria-hidden="true"></i> Show</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12"><i class="fa fa-files-o" aria-hidden="true"></i> Copy</a>
        <?php if($ADD == 34 || $ADD == 31)
        {
        	$stmt="SELECT count(*) FROM vicidial_hopper where campaign_id='$campaign_id' and status IN('READY') $LOGallowed_campaignsSQL;";
			if ($DB) {echo "$stmt\n";}
			$rslt=mysql_query($stmt, $link);
			$rowx=mysql_fetch_row($rslt);
			$hopper_leads = "$rowx[0]";			
        	?>

        	
        	<div class="item sub_item_first"><a href="#"><font size='3' color='black'></font> >&nbsp;Dialable Leads </a></div>               	
        	<div class="item sub_item"><a href="./AST_VICIDIAL_hopperlist.php?group=<?php echo $campaign_id;?>"><font size='3' color='black'></font> >&nbsp;Hopper Leads:&nbsp;<?php echo $hopper_leads;?> </a></div>       
 			<div class="item sub_item"><a href="./AST_VDADstats.php?group=<?php echo $campaign_id;?>"><font size='3' color='black'></font> >&nbsp;VDAD Report </a></div>       
 			<div class="item sub_item"><a href="<?php echo $ADMIN?>?ADD=81&campaign_id=<?php echo $campaign_id;?>"><font size='3' color='black'></font> >&nbsp;Call Back Holds </a></div>       
 			<!--<div class="item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=CAMPAIGNS&stage=<?php echo $campaign_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
 			<div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=51&campaign_id=<?php echo $campaign_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete Campaign </a></div>       
 		<?php } ?>	
        <!--<a class="list-group-item" href="<?php echo $ADMIN?>?ADD=32"><i class="fa fa-link" aria-hidden="true"></i> Statutes</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=33"><i class="fa fa-link" aria-hidden="true"></i> HotKeys</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=35"><i class="fa fa-link" aria-hidden="true"></i> Lead Recycle</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=36"><i class="fa fa-link" aria-hidden="true"></i> Auto-Alt Dial</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=39"><i class="fa fa-link" aria-hidden="true"></i> List Mix</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=37"><i class="fa fa-link" aria-hidden="true"></i> Pause Codes</a>-->
    <?php endif; ?>
    <?php if (strlen($lists_hh) > 1):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100"><i class="fa fa-eye" aria-hidden="true"></i> Show</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=111"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
        <a class="list-group-item" href="./admin_search_lead.php"><i class="fa fa-search" aria-hidden="true"></i> Search </a>
         <?php if($ADD == 311){?>
 			<div class="item sub_item_first"><a href="<?php echo $ADMIN?>?ADD=811&list_id=<?php echo $list_id;?>"><font size='3' color='black'></font> >&nbsp;Call Back Holds </a></div>       
         <div class="item sub_item"><a href="./list_download.php?list_id=<?php echo $list_id;?>"><font size='3' color='black'></font> >&nbsp;Download List </a></div>               	        	
 			<!--<div class="item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=LISTS&stage=<?php echo $list_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
 			<div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=511&list_id=<?php echo $list_id_;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete List </a></div>
 		<?php } ?>	
        <!--<a class="list-group-item" href="<?php echo $ADMIN?>?ADD=121"><i class="fa fa-plus" aria-hidden="true"></i> Add Number To DNC</a>
        <a class="list-group-item" href="./new_listloader_superL.php"><i class="fa fa-link" aria-hidden="true"></i> Load New Leads</a>-->
    <?php endif;?>
    <?php if (strlen($scripts_hh) > 1):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000"><i class="fa fa-eye" aria-hidden="true"></i> Show</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111111"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
        <?php if($ADD == 3111111){?> 
        <!--<div class="item sub_item_first sub_item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=SCRIPTS&stage=<?php echo $script_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=5111111&script_id=<?php echo $script_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete Script </a></div>
        <?php } ?>
    <?php endif; ?>
    <?php if (strlen($filters_hh) > 1):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000"><i class="fa fa-eye" aria-hidden="true"></i> Show</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
        <?php if($ADD == 31111111){?> 
        <!--<div class="item sub_item_first sub_item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=FILTERS&stage=<?php echo $lead_filter_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=51111111&lead_filter_id=<?php echo $lead_filter_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete Filter </a></div>
        <?php } ?>
    <?php endif; ?>
    <?php if (strlen($ingroups_hh) > 1):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000"><i class="fa fa-eye" aria-hidden="true"></i> Show In-Groups</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111"><i class="fa fa-plus" aria-hidden="true"></i> Add A In-Group</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1211"><i class="fa fa-files-o" aria-hidden="true"></i> Copy In-Group</a>        
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1300"><i class="fa fa-eye" aria-hidden="true"></i> Show DIDs</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1311"><i class="fa fa-plus" aria-hidden="true"></i> Add DID</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1411"><i class="fa fa-files-o" aria-hidden="true"></i> Copy DID</a>       
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1500"><i class="fa fa-eye" aria-hidden="true"></i> Show Call Menus</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1511"><i class="fa fa-plus" aria-hidden="true"></i> Add Call Menu</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1611"><i class="fa fa-files-o" aria-hidden="true"></i> Copy Call Menu</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1700"><i class="fa fa-eye" aria-hidden="true"></i> Show Filter Phone Group</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1711"><i class="fa fa-plus" aria-hidden="true"></i> Add Filter Phone Group</a>        
         <?php if($ADD == 3111){?> 
		<div class="item sub_item_first"><a href="./AST_CLOSERstats.php?group[]=<?php echo $group_id;?>"><font size='3' color='black'></font> >&nbsp;View Reports </a></div>               	
		<!--<div class="item sub_item"><a href="./AST_VICIDIAL_ingrouplist.php?group=<?php echo $group_id;?>"><font size='3' color='black'></font> >&nbsp;Agents Logged </a></div>-->
		<!--<div class="item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=INGROUPS&stage=<?php echo $group_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=5111&group_id=<?php echo $group_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete In-Group </a></div>
        <?php } ?>
         <?php if($ADD == 3311){?> 
		<div class="item sub_item_first"><a href="./AST_DIDstats.php?group[0]=<?php echo $did_id;?>"><font size='3' color='black'></font> >&nbsp;Traffic Reports </a></div>               	
		<div class="item sub_item"><a href="./user_stats.php?user=$did_pattern&did=1&did_id=<?php echo $did_id;?>"><font size='3' color='black'></font> >&nbsp;Recording And Calls </a></div>       
		<!--<div class="item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=DIDS&stage=<?php echo $did_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=5311&did_id=<?php echo $did_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete DID </a></div>
        <?php } ?>
         <?php if($ADD == 3511){?> 		
		<!--<div class="item sub_item_first sub_item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=CALLMENUS&stage=<?php echo $menu_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=5511&menu_id=<?php echo $menu_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete Call Menu </a></div>
        <?php } ?>
        <?php if($ADD == 3711){?> 		
		<!--<div class="item sub_item_first sub_item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=FILTERPHONEGROUPS&stage=<?php echo $filter_phone_group_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=5711&filter_phone_group_id=<?php echo $filter_phone_group_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete FPG </a></div>
        <?php } ?>
    <?php endif; ?>
    <?php if (strlen($usergroups_hh) > 1):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000"><i class="fa fa-eye" aria-hidden="true"></i> Show</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=111111"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
        <!--<a class="list-group-item" href="./group_hourly_stats.php"><i class="fa fa-link" aria-hidden="true"></i> Group Hourly Report</a>
        <a class="list-group-item" href="./user_group_bulk_change.php"><i class="fa fa-link" aria-hidden="true"></i> Bulk Group Change</a>-->
         <?php if($ADD == 311111){?> 
		<div class="item sub_item_first"><a href="<?php echo $PHP_SELF;?>?ADD=8111&user_group=<?php echo $user_group;?>"><font size='3' color='black'></font> >&nbsp;CallBack Holds </a></div>               	
		<div class="item sub_item"><a href="./timeclock_status.php?user_group=<?php echo $user_group;?>"><font size='3' color='black'></font> >&nbsp;TimeClock Status </a></div>       
		<!--<div class="item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=USERGROUPS&stage=<?php echo $user_group;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=511111&user_group=<?php echo $user_group;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete User Group </a></div>
        <?php } ?>
    <?php endif; ?>
    <?php if (strlen($remoteagent_hh) > 1):?>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000"><i class="fa fa-eye" aria-hidden="true"></i> Show</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
       <?php if($ADD == 31111){?> 		     
		<!--<div class="item sub_item_first sub_item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=REMOTEAGENTS&stage=<?php echo $remote_agent_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=51111&remote_agent_id=<?php echo $remote_agent_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete Remote Agent </a></div>
        <?php } ?> 
        <?php if($ADD == 32111){?> 		     
		<!--<div class="item sub_item_first sub_item sub_item_last"><a href="<?php echo $ADMIN?>?ADD=720000000000000&category=EXTENGROUP&stage=<?php echo $extension_id;?>"><font size='3' color='black'></font> >&nbsp;Admin Changes</a></div>-->
        <div class="item" style='background-color:#3c3838;height:auto;'><a href='<?php echo $PHP_SELF;?>?ADD=52111&extension_id=<?php echo $extension_id;?>' class='btn btn-lg btn-black' style='padding:0 40px 0 0; color:white;'>Delete Extension Group </a></div>
        <?php } ?> 
    <?php endif; ?>
    <script type="text/javascript">
    function delete1(page,ids){
   	 var x;
  
	    if (confirm("Are you sure you want to delete ?") == true) {
	        x = "You pressed OK!";
	        if(page==611111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&call_time_id="+ids+"&CoNfIrM=YES";
	   		 }
	   		  if(page==631111111){ 
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&shift_id="+ids+"&CoNfIrM=YES";
	   		 }
	   		  if(page==62111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&alias_id="+ids+"&CoNfIrM=YES";
	   		 } 
	   		 if(page==63111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&group_alias_id="+ids+"&CoNfIrM=YES";
	   		 }
	   		  if(page==641111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&carrier_id="+ids+"&CoNfIrM=YES";
	   		 } 
	   		 if(page==681111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&label_id="+ids+"&CoNfIrM=YES";
	   		 } 
	   		 if(page==671111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&voicemail_id="+ids+"&CoNfIrM=YES";
	   		 }
	    } else {
	        x = "You pressed Cancel!";
	       
	    }
	   
	}
	 function delete2(page,conf_exten,server_ip){
   		var x;
  	
	    if (confirm("Are you sure you want to delete ?") == true) {
	        x = "You pressed OK!";
	         if(page==61111111111){6111111111111
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&extension="+conf_exten+"&server_ip="+server_ip+"&CoNfIrM=YES";
	   		}
	   		 if(page==631111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&template_id="+conf_exten+"&server_ip="+server_ip+"&CoNfIrM=YES";
	   		}
	   		 if(page==611111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&server_id="+conf_exten+"&server_ip="+server_ip+"&CoNfIrM=YES";
	   		}
	   		if(page==6111111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&conf_exten="+conf_exten+"&server_ip="+server_ip+"&CoNfIrM=YES";
	   		}
	   		if(page==61111111111111){
	        window.location ="<?php echo $PHP_SELF;?>?ADD="+page+"&conf_exten="+conf_exten+"&server_ip="+server_ip+"&CoNfIrM=YES";
	   		}
	    } else {
	        x = "You pressed Cancel!";
	       
	    }
	   
	}
    </script>
   
    <?php if (strlen($admin_hh) > 1):?>
      <!-- <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000000"><i class="fa fa-link" aria-hidden="true"></i> Call Times</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=130000000"><i class="fa fa-link" aria-hidden="true"></i> Shifts</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000"><i class="fa fa-link" aria-hidden="true"></i> Phones</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=130000000000"><i class="fa fa-link" aria-hidden="true"></i> Templates</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=140000000000"><i class="fa fa-link" aria-hidden="true"></i> Carriers</a>
         <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000000000"><i class="fa fa-link" aria-hidden="true"></i> Servers</a> 
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000000000"><i class="fa fa-link" aria-hidden="true"></i> Conferences</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=311111111111111"><i class="fa fa-link" aria-hidden="true"></i> System Settings</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=321111111111111"><i class="fa fa-link" aria-hidden="true"></i> System Statuses</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=170000000000"><i class="fa fa-link" aria-hidden="true"></i> Voicemail</a>-->
   	<?php if ($ADD==100000000 || $ADD==111111111 || $ADD==1000000000 || $ADD==1111111111 ||$ADD==511111111 ||$ADD==211111111 || $ADD==2111111111 ||$ADD==4111111111) {?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Call Times</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Call Time</a>
         <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show State Call </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add State Call </a>
        
    <?php } ?>  
    	<?php if ($ADD==311111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Call Times</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Call Time</a>
         <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show State Call </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add State Call Time</a>
        
 			<div class="item sub_item_first"><a href="#" onclick="delete1(611111111,'<?php echo $call_time_id;?>');"><font size='3' color='black'></font> >&nbsp;Delete Call Time</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=CALLTIMES&stage=<?php echo $call_time_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes </a></div>       
 			
    <?php } ?>      

    	<?php if ($ADD==3111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Call Times</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Call Time</a>
         <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show State Call </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add State Call Time</a>
        
 			<div class="item sub_item_first"><a onclick="delete1(6111111111,'<?php echo $call_time_id;?>');"href="#"><font size='3' color='black'></font> >&nbsp;Delete State Call Time</a></div>       
 			<div class="item sub_item sub_item_last"><a href=""></a></div>   
    <?php } ?> 
    <?php if ($ADD==130000000 || $ADD==131111111 ||$ADD==531111111 || $ADD==231111111 || $ADD==631111111||$ADD==431111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=130000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Shifts </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=131111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Shift </a>
       
    <?php } ?>
     <?php if ($ADD==331111111 ){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=130000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Shifts </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=131111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Shift </a>
       
 			<div class="item sub_item_first"><a onclick="delete1(631111111,'<?php echo $shift_id;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Shift</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=SHIFTS&stage=<?php echo $shift_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       
 			
    <?php } ?>      
      <?php if ($ADD==10000000000 || $ADD==11111111111 || $ADD==12000000000 || $ADD==12111111111 || $ADD==13000000000 || $ADD==13111111111 ||$ADD ==51111111111 ||$ADD==21111111111 ||$ADD==22111111111 ||$ADD==23111111111 ||$ADD==61111111111 ||$ADD==62111111111||$ADD==63111111111||$ADD==41111111111||$ADD==42111111111||$ADD==43111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phones</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phone Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone Alias</a>
       <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Group Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Group Alias</a>
       <?php } ?>  
      <?php if ($ADD==31111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phones</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phone Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone Alias</a>
       <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Group Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Group Alias</a>
      
        
 			<div class="item sub_item_first"><a href="./phone_stats.php?extension=<?php echo $row[0]."&server_ip=".$row[5];?>"><font size='3' color='black'></font> >&nbsp;Phone Stats</a></div>       
 			<div class="item sub_item"><a href="./user_stats.php?user=<?php echo $row[0];?>"><font size='3' color='black'></font> >&nbsp;Phone Call Recordings </a></div>       
 			<div class="item sub_item"><a onclick="delete2(61111111111,'<?php echo $extension;?>','<?php echo $server_ip;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Phone</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=PHONES&stage=<?php echo $extension; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       
 			
       <?php } ?>
       <?php if ($ADD==32111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phones</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phone Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone Alias</a>
       <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Group Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Group Alias</a>
      
        
 			<div class="item sub_item_first"><a onclick="delete1(62111111111,'<?php echo $row[0];?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Phone Alias</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=PHONEALIASES&stage=<?php echo $alias_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       
 			
       <?php } ?> 
        <?php if ($ADD==33111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phones</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Phone Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=12111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Phone Alias</a>
       <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Group Alias</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=13111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Group Alias</a>
      
        
 			<div class="item sub_item_first"><a onclick="delete1(63111111111,'<?php echo $row[0];?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Group Alias</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=GROUPALIASES&stage=<?php echo $group_alias_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       
 			
       <?php } ?>         
      <?php if ($ADD==130000000000 || $ADD==131111111111 ||$ADD==231111111111 ||$ADD== 631111111111 ||$ADD==431111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=130000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Templates </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=131111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Template </a>
        
    <?php } ?>
     <?php if ($ADD==331111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=130000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Templates </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=131111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Template </a>
      
 			<div class="item sub_item_first"><a  onclick="delete2(631111111111,'<?php echo $template_id;?>','<?php echo $server_ip;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Conf Template</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=CONFTEMPLATES&stage=<?php echo $template_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       
 	   
    <?php } ?>
     <?php if ($ADD==140000000000 || $ADD==141111111111 || $ADD==140111111111 ||$ADD==241111111111 ||$ADD==641111111111||$ADD==441111111111){?>
      <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=140000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Carrier </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=141111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Carrier </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=140111111111"><i class="fa fa-files-o" aria-hidden="true"></i> Copy Carrier </a>        
        <?php } ?>

 <?php if ($ADD==341111111111 ){?>
      <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=140000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Carrier </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=141111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Carrier </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=140111111111"><i class="fa fa-files-o" aria-hidden="true"></i> Copy Carrier </a>        
        
 			<div class="item sub_item_first"><a onclick="delete1(641111111111,'<?php echo $carrier_id;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Carrier</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=CARRIERS&stage=<?php echo $carrier_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       
 	   
        <?php } ?>

       <?php if ($ADD==100000000000 || $ADD==111111111111 ||$ADD==211111111111 ||$ADD==611111111111 ||$ADD==221111111111||$ADD==411111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Servers</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Server  </a>
        
    <?php } ?>
    <?php if ($ADD==311111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=100000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Servers</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Server  </a>
          
 			<div class="item sub_item_first"><a onclick="delete2(611111111111,'<?php echo $server_id;?>','<?php echo $server_ip;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Conference</a></div>       
 		  <div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=SERVERS&stage=<?php echo $server_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       

    <?php } ?>
    <?php if ($ADD==1000000000000 || $ADD==1111111111111 || $ADD==10000000000000 || $ADD==11111111111111 ||$ADD==21111111111111 ||$ADD==61111111111111 ||$ADD==4111111111111||$ADD==2111111111111||$ADD==41111111111111||$ADD==6111111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Conferences </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Conference</a>
         <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Dialshree Conf</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Dialshree Conf </a>
        
    <?php } ?>
     <?php if ($ADD==3111111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Conferences </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Conference</a>
         <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Dialshree Conf</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Dialshree Conf </a>
        
 			<div class="item sub_item_first"><a onclick="delete2(6111111111111,'<?php echo $conf_exten;?>','<?php echo $server_ip;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Conference</a></div>       
 		  <div class="item sub_item sub_item_last"><a href=""></a></div>       

    <?php } ?>
     <?php if ($ADD==31111111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1000000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Conferences </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=1111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Conference</a>
         <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=10000000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Dialshree Conf</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=11111111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Dialshree Conf </a>
        
 			<div class="item sub_item_first"><a onclick="delete2(61111111111111,'<?php echo $conf_exten;?>','<?php echo $server_ip;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Dialshree Conf</a></div>       
 		  <div class="item sub_item sub_item_last"><a href=""></a></div>       

    <?php } ?>

     <?php if ($ADD==311111111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=311111111111111"><i class="fa fa-cog" aria-hidden="true"></i> System Settings </a>
         
 			<div class="item sub_item_first"></a></div>       
 		  <div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=LABEL&stage=<?php echo $label_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       

    <?php } ?>
     <?php if ($ADD==180000000000 || $ADD==181111111111 || $ADD==581111111111 || $ADD==281111111111 || $ADD==681111111111||$ADD==481111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=180000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Labels</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=181111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Label </a>
        
    <?php } ?>
    <?php if ($ADD==381111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=180000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Labels</a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=181111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Label </a>
         
 			<div class="item sub_item_first"><a onclick="delete1(681111111111,'<?php echo $label_id;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Screen Label</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=LABEL&stage=<?php echo $label_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       

    <?php } ?>
    <?php if ($ADD==321111111111111 || $ADD==331111111111111 || $ADD==341111111111111  ||$ADD==421111111111111){?>															
      <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=321111111111111"><i class="fa fa-link" aria-hidden="true"></i> System Statuses </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=331111111111111"><i class="fa fa-link" aria-hidden="true"></i> Status Categories </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=341111111111111"><i class="fa fa-link" aria-hidden="true"></i> QC Status Codes </a>        
        <?php } ?>
    <?php if ($ADD==170000000000 || $ADD==171111111111 || $ADD==671111111111 ||$ADD==471111111111 || $ADD==271111111111){?>
    	 <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=170000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Voicemail Box </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=171111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Voicemail Entry </a>
         
    <?php } ?>
      <?php if ($ADD==371111111111){?>
    	<a class="list-group-item" href="<?php echo $ADMIN?>?ADD=170000000000"><i class="fa fa-eye" aria-hidden="true"></i> Show Voicemail Box </a>
        <a class="list-group-item" href="<?php echo $ADMIN?>?ADD=171111111111"><i class="fa fa-plus" aria-hidden="true"></i> Add Voicemail Entry </a>
        
 			<div class="item sub_item_first"><a onclick="delete1(671111111111,'<?php echo $voicemail_id;?>');" href="#"><font size='3' color='black'></font> >&nbsp;Delete Voicemail Box</a></div>       
 			<div class="item sub_item sub_item_last"><a href="<?php echo $PHP_SELF;?>?ADD=720000000000000&category=VOICEMAIL&stage=<?php echo $voicemail_id; ?>"><font size='3' color='black'></font> >&nbsp;Admin changes</a></div>       

    <?php } ?>
    <?php endif; ?>
    
    <?php if (strlen($reports_hh)):?>
      <!--  <div>
        <div class="item-head">Real-Time Reports</div>
        <div class="items">
        <a class="list-group-item" href="AST_timeonVDADall.php"><i class="fa fa-link" aria-hidden="true"></i> Real-Time Main Report</a>
        <a class="list-group-item" href="AST_timeonVDADallSUMMARY.php"><i class="fa fa-link" aria-hidden="true"></i> Real-Time Campaign Summary</a>
        </div></div>
        <div>
        <div class="item-head">Inbound and Outbound Calling Reports</div>
        <div class="items">
        <a class="list-group-item" href="AST_CLOSERstats.php"><i class="fa fa-link" aria-hidden="true"></i> Inbound Report</a>
        <a class="list-group-item" href="AST_CLOSER_service_level.php"><i class="fa fa-link" aria-hidden="true"></i> Inbound Service Level Report</a>
        <a class="list-group-item" href="AST_CLOSERsummary_hourly.php"><i class="fa fa-link" aria-hidden="true"></i> Inbound Summary Hourly Report</a>
        <a class="list-group-item" href="AST_DIDstats.php"><i class="fa fa-link" aria-hidden="true"></i> Inbound DID Report</a>
        <a class="list-group-item" href="AST_IVRstats.php"><i class="fa fa-link" aria-hidden="true"></i> Inbound IVR Report</a>
        <a class="list-group-item" href="AST_VDADstats.php"><i class="fa fa-link" aria-hidden="true"></i> Outbound Calling Report</a>
        <a class="list-group-item" href="AST_OUTBOUNDsummary_interval.php"><i class="fa fa-link" aria-hidden="true"></i> Outbound Summary Interval Report</a>
        <a class="list-group-item" href="fcstats.php"><i class="fa fa-link" aria-hidden="true"></i> Fronter - Closer Report</a>
        <a class="list-group-item" href="call_report_export.php"><i class="fa fa-link" aria-hidden="true"></i> Export Calls Report</a>
        </div></div>
        <div>
        <div class="item-head">Agent Reports</div>
        <div class="items">
        <a class="list-group-item" href="dnc_report.php"><i class="fa fa-link" aria-hidden="true"></i> DNC Report</a>
        <a class="list-group-item" href="agent_report.php?section<i class="fa fa-link" aria-hidden="true"></i> =agent_time">Disposition Report</a>
        <a class="list-group-item" href="agent_report.php?section<i class="fa fa-link" aria-hidden="true"></i> =agent_login_logout">Agent login and logout time</a>
        <a class="list-group-item" href="agent_report.php?section<i class="fa fa-link" aria-hidden="true"></i> =timeclock_login">Timeclock login/logout time</a>
        <a class="list-group-item" href="agent_report.php?section<i class="fa fa-link" aria-hidden="true"></i> =closer_logs">Closer in-group selection logs</a>
        <a class="list-group-item" href="agent_report.php?section<i class="fa fa-link" aria-hidden="true"></i> =outbound_calls">Outbound calls for this time period</a>
        <a class="list-group-item" href="agent_report.php?section<i class="fa fa-link" aria-hidden="true"></i> =inbound_calls">Inbound calls for this time period</a>
        <a class="list-group-item" href="agent_report.php?section<i class="fa fa-link" aria-hidden="true"></i> =agent_activity">Agent activity records for this time period</a>
        <a class="list-group-item" href="AST_agent_time_detail.php"><i class="fa fa-link" aria-hidden="true"></i> Agent Time Detail</a>
        <a class="list-group-item" href="AST_agent_status_detail.php"><i class="fa fa-link" aria-hidden="true"></i> Agent Status Detail</a>
        <a class="list-group-item" href="AST_agent_performance_detail.php"><i class="fa fa-link" aria-hidden="true"></i> Agent Performance Detail</a>
        <a class="list-group-item" href="AST_agent_days_detail.php"><i class="fa fa-link" aria-hidden="true"></i> Single Agent Daily</a>
        </div></div>
        <div>
        <div class="item-head">Time Clock Reports</div>
        <div class="items">
        <a class="list-group-item" href="timeclock_report.php"><i class="fa fa-link" aria-hidden="true"></i> User Timeclock Report</a>
        <a class="list-group-item" href="timeclock_status.php"><i class="fa fa-link" aria-hidden="true"></i> User Group Timeclock Status Report</a>
        <a class="list-group-item" href="AST_agent_timeclock_detail.php"><i class="fa fa-link" aria-hidden="true"></i> User Timeclock Detail Report</a>
        </div></div>
        <div>
        <div class="item-head">Other Reports and Links</div>
        <div class="items">
        <a class="list-group-item" href="AST_server_performance.php"><i class="fa fa-link" aria-hidden="true"></i> Server Perforrmance Report</a>
        <a class="list-group-item" href="<?php echo $PHP_SELF ?>?ADD=700000000000000"><i class="fa fa-link" aria-hidden="true"></i> Administration Change Log</a>
        </div></div>
        <div>
        <div class="item-head">Recording Report</div>
        <div class="items">
        <a class="list-group-item" href="search_recording.php"><i class="fa fa-search" aria-hidden="true"></i> Search recordings</a>
        <a class="list-group-item" href="recording_report.php?section=recordings_for_this_time"><i class="fa fa-link" aria-hidden="true"></i> Recordings for this time period</a>
        <a class="list-group-item" href="recording_report.php?section=manual"><i class="fa fa-link" aria-hidden="true"></i> Manual outbound calls for this time period</a>
        </div></div>
        <div>
        <div class="item-head">CDR Report</div>
        <div class="items">
        <a class="list-group-item" href="cdr_report.php"><i class="fa fa-link" aria-hidden="true"></i> CDR Report</a>
        </div></div>        -->
    <?php endif; ?>
	 </div>
<?php  } else { }
###Code Modified By Ketan Solanki--02-03-2015
###################################################################################################################################
?>

<span style="position:absolute;left:300px;top:30px;z-index:1;visibility:hidden;" id="audio_chooser_span">

</span>

		</div>
		<div class="col-xs-12 col-md-9">


<?php 
/* Abhishek 21-2-2015
<TABLE cellpadding=2 cellspacing=0 WIDTH=<?php echo $page_width ?> HEIGHT=15>
<!--<TR BGCOLOR=#015B91><TD ALIGN=LEFT BGCOLOR=#015B91>	<FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B><a href="<?php echo $admin_home_url_LU ?>"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=1>HOME</a> | <A HREF="../agc/timeclock.php?referrer=admin"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=1> Timeclock</A> | <a href="<?php echo $ADMIN ?>?force_logout=1"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=1>Logout</a> <FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=1>(<?php echo $PHP_AUTH_USER ?>)</FONT></TD><TD ALIGN=RIGHT><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B><?php echo date("l F j, Y G:i:s A") ?> &nbsp; </B></TD></TR>-->

<TR BGCOLOR=#015B91>
</TR>
	<?php
	if (strlen($list_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $subcamp_color ?>><TD ALIGN=LEFT COLSPAN=2><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subcamp_font_size ?>> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=10"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subcamp_font_size ?>> Show Campaigns </a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<?php echo $ADMIN ?>?ADD=11"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subcamp_font_size ?>> Add A New Campaign </a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<?php echo $ADMIN ?>?ADD=12"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subcamp_font_size ?>> Copy Campaign </a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="./AST_timeonVDADallSUMMARY.php"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subcamp_font_size ?>> Real-Time Campaigns Summary </a></TD></TR>
		<?php } 

	if (strlen($times_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $times_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=100000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Call Times </a> &nbsp;| <a href="<?php echo $ADMIN ?>?ADD=111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Call Time </a> &nbsp;| <a href="<?php echo $ADMIN ?>?ADD=1000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show State Call Times </a> &nbsp;| <a href="<?php echo $ADMIN ?>?ADD=1111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New State Call Time </a></TD></TR>
		<?php } 
	if (strlen($shifts_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $shifts_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=130000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Shifts </a> &nbsp;| <a href="<?php echo $ADMIN ?>?ADD=131111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Shift </a></TD></TR>
		<?php } 
	if (strlen($phones_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $phones_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=10000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Phones </a>&nbsp;|&nbsp;<a href="<?php echo $ADMIN ?>?ADD=11111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Phone </a>&nbsp;|&nbsp;<a href="<?php echo $ADMIN ?>?ADD=12000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Phone Alias List </a>&nbsp;|&nbsp;<a href="<?php echo $ADMIN ?>?ADD=12111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Phone Alias </a>&nbsp;|&nbsp;<a href="<?php echo $ADMIN ?>?ADD=13000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Group Alias List </a>&nbsp;|&nbsp;<a href="<?php echo $ADMIN ?>?ADD=13111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Group Alias </a></TD></TR>
		<?php }
	if (strlen($conference_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $conference_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=1000000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Conferences </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=1111111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Conference </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=10000000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show VICIDIAL Conferences </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=11111111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New VICIDIAL Conference </a></TD></TR>
		<?php }
	if ( (strlen($server_sh) > 1) and (strlen($admin_hh) > 1) ) { 
		?>
	<TR BGCOLOR=<?php echo $server_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=100000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Servers </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=111111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Server </a></TD></TR>
	<?php }
	if ( (strlen($templates_sh) > 1) and (strlen($admin_hh) > 1) ) { 
		?>
	<TR BGCOLOR=<?php echo $templates_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=130000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Templates </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=131111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Template </a></TD></TR>
	<?php }
	if ( (strlen($carriers_sh) > 1) and (strlen($admin_hh) > 1) ) { 
		?>
	<TR BGCOLOR=<?php echo $carriers_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=140000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Carriers </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=141111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Carrier </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=140111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Copy A Carrier </a></TD></TR>
	<?php }
	if ( (strlen($tts_sh) > 1) and (strlen($admin_hh) > 1) ) { 
		?>
	<TR BGCOLOR=<?php echo $tts_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=150000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show TTS Entries </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=151111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New TTS Entry </a></TD></TR>
	<?php }
	if ( (strlen($cc_sh) > 1) and (strlen($admin_hh) > 1) ) { 
		?>
	<TR BGCOLOR=<?php echo $cc_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="callcard_admin.php"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> CallCard Summary </a> &nbsp; | &nbsp; <a href="callcard_admin.php?action=CALLCARD_RUNS"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Runs </a> &nbsp; | &nbsp; <a href="callcard_admin.php?action=CALLCARD_BATCHES"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Batches </a> &nbsp; | &nbsp; <a href="callcard_admin.php?action=SEARCH"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> CallCard Search </a> &nbsp; | &nbsp; <a href="callcard_report_export.php"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> CallCard Log Export </a> &nbsp; | &nbsp; <a href="callcard_admin.php?action=GENERATE"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> CallCard Generate New Numbers </a></TD></TR>
	<?php }
	if ( (strlen($moh_sh) > 1) and (strlen($admin_hh) > 1) ) { 
		?>
	<TR BGCOLOR=<?php echo $moh_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=160000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show MOH Entries </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=161111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New MOH Entry </a></TD></TR>
	<?php }
	if ( (strlen($vm_sh) > 1) and (strlen($admin_hh) > 1) ) { 
		?>
	<TR BGCOLOR=<?php echo $vm_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=170000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Show Voicemail Entries </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=171111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A New Voicemail Entry </a></TD></TR>
	<?php }
	if (strlen($settings_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $settings_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=311111111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> System Settings </a></TD></TR>
	<?php }
	if (strlen($label_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $label_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=180000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Screen Labels </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=181111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A Screen Label </a></TD></TR>
	<?php }
	if (strlen($cts_sh) > 1) { 
		?>
	<TR BGCOLOR=<?php echo $cts_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=190000000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Contacts </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=191111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Add A Contact </a></TD></TR>
	<?php }
	if ( (strlen($status_sh) > 1) and (!eregi('campaign',$hh) ) ) { 
		?>
	<TR BGCOLOR=<?php echo $status_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="<?php echo $ADMIN ?>?ADD=321111111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> System Statuses </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=331111111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> Status Categories </a> &nbsp; | &nbsp; <a href="<?php echo $ADMIN ?>?ADD=341111111111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>> QC Status Codes </a></TD></TR>
	<?php }

	if ( ($ADD=='3') or ($ADD=='3') ) { 
		?>
	<TR BGCOLOR=<?php echo $users_color ?>><TD ALIGN=LEFT COLSPAN=2> &nbsp; <a href="./user_stats.php?user=<?php echo $user ?>"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>>User Stats </a> &nbsp; | &nbsp; <a href="./user_status.php?user=<?php echo $user ?>"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>>User Status </a> &nbsp; | &nbsp; <a href="./AST_agent_time_sheet.php?agent=<?php echo $user ?>"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>>Time Sheet </a> &nbsp; | &nbsp; <a href="./AST_agent_days_detail.php?user=<?php echo $user ?>"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>>Days Status </a></TD></TR>
	<?php }

	
if (strlen($reports_hh) > 1) { 
	?>
<TR BGCOLOR=<?php echo $reports_color ?>><TD ALIGN=LEFT COLSPAN=2><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=<?php echo $subheader_font_size ?>><B> &nbsp; </B></TD></TR>
<?php } ?>

*/?>
<?php 
######################### FULL HTML HEADER END #######################################
}
