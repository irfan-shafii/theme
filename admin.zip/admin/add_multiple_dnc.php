<?php
#echo "<pre>";print_r($_FILES);exit;
set_time_limit ( 0 );
#error_reporting ( E_ALL );
#ini_set ( 'display_errors', 1 );
ini_set ( 'memory_limit', '2028M' );
ini_set ( 'max_execution_time', 123456 );
ini_set ( 'post_max_size', '500M' );
ini_set ( 'upload_max_filesize', '10M' );
require("dbconnect.php");
###=================== IMPORT FILE ========================//
####### Ketan Solanki 27-02-2015 select file code
if(isset($_POST['submit']) && $_POST['submit']=="submit")
{
	if ($_FILES["filename"]["error"] > 0)
	{
		echo "Error: " . $_FILES["filename"]["error"] . "<br />";
	}
	else
	{
		echo "Upload: " . $_FILES["filename"]["name"] . "<br />";
		echo "Type: " . $_FILES["filename"]["type"] . "<br />";
		$size = (($_FILES["filename"]["size"] / 1024)/1024);
		$size = number_format($size,2);
		if($size>1) 
		{
		    echo "Size: " . $size . " Mb<br />";
		}
		else 
		{
		    echo "Size: " . $size*1024 . " Kb<br />";
		}

		$filename = $_FILES["filename"]["tmp_name"];
########### End ########################################
		$t1 = time();
		$handle = fopen ( $filename, "r" );
		$content = fread ( $handle, filesize ( $filename ) );
		$content = $content;
		fclose ( $handle );
		unset ( $handle );
		$content = explode ( "\n", $content );
		$fieldsx = explode ( ",", trim ( strtolower ( str_replace ( array (
			'"',
			'\'',
			' ' 
		), '', $content [0] ) ) ) );
		unset ( $content [0] );
		unset ( $fieldsx );
		$q = '';
		$q = "INSERT IGNORE INTO vicidial_dnc(phone_number) values";
		mysql_query("START TRANSACTION");
		$q4 = "Delete from 	vicidial_dnc where phone_number in (";
		$content_outer = array_chunk ( $content, 1000 );
		foreach ( $content_outer as $content_inner ) 
		{	
				$query_ins =  $query_del = '';
		foreach ( $content_inner as $kk => $vv ) {
		if (! empty ( $vv )) 
		{ 		
			$vv = str_replace ( '"', "", $vv );
			$values = explode ( ',', $vv );			
			if($values[3] == 'A') 
			{				
				$query_ins .= "(";		 	
				$query_ins .= "'" . $values[1] . "',";	
				$query_ins = substr_replace ( $query_ins, "", - 1 );
				$query_ins .= "),"; 				
			}
			else if($values[3] == 'D') 
			{
				$query_del .= "";				
				$query_del .= "'" . $values[1] . "',";
				$query_del = substr_replace ( $query_del, "", - 1 );
				$query_del .= ",";				
			}
				
		}
	}
	#echo $q;exit;
	if (! empty ( $query_ins )) {
		$query_ins = substr_replace ( $query_ins, "", - 1 );
		$qx = $q . $query_ins; 	
		mysql_query ( $qx ); 
		unset ( $qx );
	}
	if (! empty ( $query_del )) {
		$query_del = substr_replace ( $query_del, "", - 1 );
		$qx4 = $q4 . $query_del.")"; 		
		mysql_query ( $qx4 ); 
		unset ( $qx4 );
	}
}
mysql_query("COMMIT;");
$t2 = time();
echo 'total time '.($t2-$t1);
//exit ();
header("Location: admin.php?ADD=121&msg=File Uploaded Succesfully");
// Ketan Solanki 27-02-2015 Code for select file
}
}
?>