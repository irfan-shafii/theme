<?php
require("dbconnect.php");
require("functions.php");

$call_flow_sql = "select vl.user,vl.server_ip,vl.extension,vl.status,vl.campaign_id,vl.last_call_time,va.sub_status,va.event_time from vicidial_live_agents vl left join vicidial_agent_log va on vl.agent_log_id=va.agent_log_id and vl.user=va.user where vl.status='PAUSED' and va.sub_status in ('MTG','TRG','CPB','BRK','OUT') and date(va.event_time)=CURDATE()  and DATE_ADD(va.event_time, INTERVAL 10 MINUTE) <= NOW() ";

//$call_flow_sql = "select vl.user,vl.server_ip,vl.extension,vl.status,vl.campaign_id,vl.last_call_time,va.sub_status,va.event_time from vicidial_live_agents vl left join vicidial_agent_log va on vl.agent_log_id=va.agent_log_id and vl.user=va.user where vl.status='PAUSED' and va.sub_status in ('MTG','TRG','CPB','BRK','OUT')  ";
$c=1;
$call_flow_result = mysql_query($call_flow_sql);
$result= mysql_affected_rows();
$text_content="";
$text_queue="";
while ($call_flow_row = mysql_fetch_array($call_flow_result)) {


    $user = $call_flow_row['user'];
    $server_ip = $call_flow_row['server_ip'];
    $extension = $call_flow_row['extension'];
    $status = $call_flow_row['status'];
    $campaign_id = $call_flow_row['campaign_id'];
    $pause_code = $call_flow_row['sub_status'];
    $last_call_time = $call_flow_row['last_call_time'];
    $event_time = $call_flow_row['event_time'];


    $text_content.="<tr>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$c."</td>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$user."</td>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$server_ip."</td>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$extension."</td>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$status."</td>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$pause_code."</td>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$campaign_id."</td>";

    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$last_call_time."</td>";
    $text_content.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$event_time."</td>";
    $text_content.="</tr>";

    $c++;
}


$call_queue_sql = "select * from vicidial_auto_calls where status='LIVE'   ";




$k=1;
$call_queue_result = mysql_query($call_queue_sql);
$queue_result= mysql_affected_rows();


while ( $queue_result_row = mysql_fetch_array($call_queue_result))
{



    $server1_ip = $queue_result_row['server_ip'];
    $phone1_number = $queue_result_row['phone_number'];

    $campaign1_id = $queue_result_row['campaign_id'];

    $call1_time = $queue_result_row['call_time'];


    $text_queue.="<tr>";
    $text_queue.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$k."</td>";
    $text_queue.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$server1_ip."</td>";
    $text_queue.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$campaign1_id."</td>";
    $text_queue.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$phone1_number."</td>";
    $text_queue.="<td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\">".$call1_time."</td>";


    $text_queue.="</tr>";
    $k++;
}

echo json_encode(array("break_data"=>$text_content,"queue_data"=>$text_queue))
?>