<?php
session_start();
ob_start();
$short_header=1;
header ("Content-type: text/html; charset=utf-8");
$agentReport = true;
require("dbconnect.php");
require("functions.php");


#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
{
    $row=mysql_fetch_row($rslt);
    $non_latin =                                            $row[0];
    $SSoutbound_autodial_active =           $row[1];
    $user_territories_active =                      $row[2];
}
##### END SETTINGS LOOKUP #####echo
###########################################
$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];
$PHP_SELF=$_SERVER['PHP_SELF'];


$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];




if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
{
    $referaall_url=base64_encode("voicemail-report");
    header("Location: login.php?refereer=$referaall_url");
    /* Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
     Header("HTTP/1.0 401 Unauthorized");
     echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";*/
    exit;
}
###########################################

$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["begin_date"]))                         {$begin_date=$_GET["begin_date"];}
elseif (isset($_POST["begin_date"]))    {$begin_date=$_POST["begin_date"];}
if (isset($_GET["end_date"]))                           {$end_date=$_GET["end_date"];}
elseif (isset($_POST["end_date"]))              {$end_date=$_POST["end_date"];}
if (isset($_GET["user"]))                                       {$user=$_GET["user"];}
elseif (isset($_POST["user"]))                  {$user=$_POST["user"];}
if (isset($_GET["campaign"]))                           {$campaign=$_GET["campaign"];}
elseif (isset($_POST["campaign"]))              {$campaign=$_POST["campaign"];}
if (isset($_GET["DB"]))                                         {$DB=$_GET["DB"];}
elseif (isset($_POST["DB"]))                    {$DB=$_POST["DB"];}
if (isset($_GET["submit"]))                                     {$submit=$_GET["submit"];}
elseif (isset($_POST["submit"]))                {$submit=$_POST["submit"];}
if (isset($_GET["SUBMIT"]))                                     {$SUBMIT=$_GET["SUBMIT"];}
elseif (isset($_POST["SUBMIT"]))                {$SUBMIT=$_POST["SUBMIT"];}

$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

$dirPath="/var/spool/asterisk/voicemail/default/70001/INBOX";
if(isset($_POST['file_type']) && !empty($_POST['file_name'])) {


    $recording_path=$dirPath."/";
    $play_file=$_POST['file_name'];

    // $play_file=$recording_path.basename($file);
    //	$play_file = $file;


    $down =$recording_path.$play_file;
//echo $down;die;

    if($_POST['file_type']=="download") {

        $file=$down;
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($file));
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        ob_clean();
        flush();
        readfile($file);
        exit;
    } else  if($_POST['file_type']=="play") {
        shell_exec("/bin/rm -rf /var/www/html/admin/play/*.*");
        shell_exec("/bin/cp $down  /var/www/html/admin/play/");

        echo "<br/>";
        echo "<audio src='play/$play_file' controls>
    <embed
    src='play/$play_file'
    width='180'
    height='90'
    loop='false'
    />
    </audio>";



    }


    //echo "<pre>";print_r($_POST);die;
}
function dirToArray($dir) {

    $result = array();

    $cdir = scandir($dir);
    foreach ($cdir as $key => $value)
    {
        if (!in_array($value,array(".","..")))
        {
            if (is_dir($dir . DIRECTORY_SEPARATOR . $value))
            {
                $result[$value] = dirToArray($dir . DIRECTORY_SEPARATOR . $value);
            }
            else
            {
                $result[] = $value;
            }
        }
    }

    return $result;
}



$di = new RecursiveDirectoryIterator($dirPath);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
    <title>Voice Mail Report</title>
</head>
<script language="JavaScript" src="calendar_db.js"></script>
<link rel="stylesheet" href="calendar.css">

<body>

<?php
# require("admin_header.php");
require("top-menu.php");

?>
<!--<center><h1>Outbound Call Report</h1></center>


<form action="" method="post" style="margin: auto" name="report">
    <input type="hidden" name="display" value="1" />
    <br><TABLE CELLPADDING=1 CELLSPACING=0 width='100%' ><TR><TD>
                <center><TABLE width='100%'><TR><TD>
                                <FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
                                    <div class='panel panel-success'>
                                        <TABLE BORDER=0 CELLSPACING=1 class='table'><tr>
                                                <TABLE BORDER=0 class='table'><tr bgcolor='#D4D0B3' style='color:black;'>
                                                        <td align='center'>Dates</td>
                                                        <td align='center'>To</td>
                                                        <td align='center'>Campaigns</td>
                                                        <td align='center'></td>
                                                        <td align='center'></td>
                                                    </tr></div>
                        <tr><td></td></tr>
                        <tr bgcolor='#E8E6DA'>
                            <td align='center'><input type="text" name="date_from" value="<?php echo $date_from;?>"/>
                                <script language="JavaScript">
                                    var o_cal = new tcal ({
                                        // form name
                                        'formname': 'report',
                                        // input name
                                        'controlname': 'date_from'
                                    });
                                    o_cal.a_tpl.yearscroll = false;
                                </script>
                            </td>
                            <td align='center'><input type="text" name="date_to" value="<?php echo $date_to;?>"/>
                                <script language="JavaScript">
                                    var o_cal = new tcal ({
                                        // form name
                                        'formname': 'report',
                                        // input name
                                        'controlname': 'date_to'
                                    });
                                    o_cal.a_tpl.yearscroll = false;
                                </script>
                            </td>
                            <td align='center'>
                                <select name="campaign[]" id="campaign" multiple>

                                    <?php
/*    $sql_get_campaign = "select campaign_id from vicidial_campaigns";
    $result_get_campaign = mysql_query($sql_get_campaign);
    while($row_get_campaign = mysql_fetch_array($result_get_campaign))
    {
        echo "<option value='$row_get_campaign[0]'";

        if(in_array($row_get_campaign[0],$campaign)) {
            echo "Selected";

        }
        echo ">$row_get_campaign[0]</option>";

    }*/
?>
                                </select>
                            </td>
                            <td colspan="2" align="center"><input type="submit" name="generate" value="Submit" class='btn btn-orange' /></td></tr>
                    </table>
</form>-->
<br><TABLE width='100%'><TR><TD>
            <FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
                <div class='panel panel-default' style='margin:0 0%;'>
                    <table class='table report-heading' ><tr><td class='heading-orange' align='center'><b>Voice Mail Report </b></td><td class='heading-black'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php if($_POST['generate']) {echo $date_from." to ".$date_to;}?></td><td class='heading-black'><?php if($_POST['generate']) {?><a class="btn btn-orange pull-right" href="/admin_new/export_outbound_call_report.php?date_from=<?php echo $query_date_BEGIN?>&date_to=<?php echo $query_date_END ?>&campaign=<?php echo $campaign;?>">
                                        <i class="glyphicon glyphicon-save" style="color:white"></i>
                                    </a><?php }?></td><tr></table>


                    <div class='panel-body' style='padding:0;'><table width='100%' class='table report-display-table' cellspacing=0 cellpadding=1>
                            <br><tr style='background-color:#d4d0b3' >
                                <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\" ><b>Row</b></font></td>
                                <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Desk Number</b></font></td>
                                <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Extension</b></font></td>
                                <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Customer Number</b></font></td>
                                <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Date Time</b></font></td>
                                <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Download  </b></font></td>
                                <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Play</b></font></td>
                                <!--  <td class='td_padding' style='border-right:1px solid #e8e6da;'><font size=2 color=black FACE=\"Arial,Helvetica\"><b>Total Logged in Time</b></font></td>-->

                            </tr>
                            <?php
                            //$c=1;

                            $mainArray=[];

                            foreach (new RecursiveIteratorIterator($di) as $filename => $file) {
//echo "<pre>";print_r( $filename);die;
                                if(!is_dir($filename)) {

                                    $ext = pathinfo($file->getFileName(), PATHINFO_EXTENSION);

                                    if(trim($ext) == 'txt') {
                                        $fileName=basename($file->getFileName(),".txt");

                                        $myfilePath=$dirPath."/".$file->getFileName();
                                        $var= trim(file_get_contents($myfilePath));
                                        $content= explode("[message]",$var);
                                        $get_string = str_replace("\n", '&', $content[1]);

//echo $content[1];die;
//$rateContent=explode("=",$content[1]);


                                        parse_str($get_string, $get_array);
                                        $downloadFileName=$fileName.".wav";

//echo "<pre>";print_r($get_array);die;
//echo "<pre>";print_r($rateContent);die;

                                        $caller_numer=explode("<",$get_array['callerid']);
                                        $caller_detail=explode(">",$caller_numer[1]);

                                        $mainArray[]=['origmailbox'=>$get_array['origmailbox'],'exten'=>$get_array['exten'],'customer_number'=>$caller_detail[0],'orig_time'=>$get_array['origtime'],'downloadFileName'=>$downloadFileName];


                                    }
                                }

                            }

                            usort($mainArray, function($a, $b){ // sort by time latest
                                return $b['orig_time'] - $a['orig_time'];
                            });
                            //echo "<pre>";print_r($mainArray);die;
                            $c=1;
                            foreach($mainArray as $dataArray) {
                                ?>
                                <tr>
                                    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2
                                                                                                      FACE=\"Arial,Helvetica\"><?php echo $c; ?>
                                    </td>
                                    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2
                                                                                                      FACE=\"Arial,Helvetica\"><?php echo $dataArray['origmailbox']; ?>
                                    </td>

                                    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2
                                                                                                      FACE=\"Arial,Helvetica\"><?php echo $dataArray['exten']; ?>
                                    </td>

                                    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2
                                                                                                      FACE=\"Arial,Helvetica\"><?php echo $dataArray['customer_number']; ?>
                                    </td>
                                    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2
                                                                                                      FACE=\"Arial,Helvetica\"><?php echo date("Y-m-d H:i:s", $dataArray['orig_time']); ?>
                                    </td>

                                    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2
                                                                                                      FACE=\"Arial,Helvetica\"><input
                                                class="btn" onclick="downloadFile('<?php echo $dataArray['downloadFileName']; ?>')"
                                                name="yt1" value="Download" type="button">
                                    </td>
                                    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2
                                                                                                      FACE=\"Arial,Helvetica\"><input
                                                class="btn" onclick="playRecording('<?php echo $dataArray['downloadFileName']; ?>')"
                                                name="yt2" value="Play" type="button">
                                    </td>
                                    <!--    <td class='td_padding' style='border-right:1px solid #ccc;'><font size=2 FACE=\"Arial,Helvetica\"><?php //echo $total;?></td>-->

                                </tr>

                                <?php
                                $c++;
                            }

                            ?>
                        </table>
        </td>
    </tr>
</table>
<form name="downloadForm" id="downloadForm" method="post">

    <input type="hidden" id="file_name" name="file_name" value=""/>
    <input type="hidden" id="file_type" name="file_type" />





</form>

</body>
</html>

<script>

    function downloadFile(location){

        document.getElementById("file_name").value=location;
        document.getElementById("file_type").value="download";
        document.getElementById("downloadForm").submit();


    }

    function playRecording(location){
        document.getElementById("file_name").value=location;
        document.getElementById("file_type").value="play";
        document.getElementById("downloadForm").submit();


    }



    function playAudio(x) {
        x.play();
    }

    function pauseAudio(x) {
        x.pause();
    }
</script>

