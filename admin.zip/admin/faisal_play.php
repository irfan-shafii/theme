<?php
//echo getcwd();die;
session_cache_limiter('private_no_expire');
session_start();
ob_start();
include_once("./dbconnect.php");
include_once("./value.php");
#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
{
    $row=mysql_fetch_row($rslt);
    $non_latin =                                            $row[0];
    $SSoutbound_autodial_active =           $row[1];
    $user_territories_active =                      $row[2];
}
##### END SETTINGS LOOKUP #####echo
###########################################
//$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
//$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];
//$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
//$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
{
    //  $referaall_url=base64_encode("faisal_play");
    //header("Location: login.php?refereer=$referaall_url");

    //exit;
}
else
{
    if($auth>0)
    {
        $stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $LOGfullname=$row[0];

        fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
        fclose($fp);
    }
    else
    {
        fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
        fclose($fp);
        echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
        exit;
    }

    $stmt="SELECT full_name from vicidial_users where user='$user';";
    $rslt=mysql_query($stmt, $link);
    $row=mysql_fetch_row($rslt);
    $full_name = $row[0];
}

include("recording_path.php");

$filename = $_GET['filename'];
$recording_id=$_GET['recording_id'];
$abs_path=explode("_",$filename);

$track_path=$abs_path[2];
$base_path=explode("-",$track_path);
$variable_path=$base_path[0];
//echo $variable_path;
$myDateTime = DateTime::createFromFormat('Ymd', $variable_path);
$newDateString = $myDateTime->format('Y-m-d');
//echo $newDateString;
//$recording_path="/var/spool/asterisk/monitorDONE/";

#$play_file =$filename."-all.wav";
$play_file =$filename."-all.wav";
$down=$recording_path.$newDateString."/".$play_file;
if($_POST['submit']) {


    $agent_name=$_POST['agent_name'];
    $email=$_POST['email'];
    $date_from=$_POST['date_from'];
    $call_reference=$_POST['call_reference'];
    $evaluated_by=$_POST['evaluated_by'];
    $mention_first_name=$_POST['mention_first_name'];
    $volume_voice=$_POST['volume_voice'];
    $customer_needs=$_POST['customer_needs'];
    $explain_process=$_POST['explain_process'];
    $accurate_information=$_POST['accurate_information'];
    $complicated_terms=$_POST['complicated_terms'];
    $positive_words=$_POST['positive_words'];
    $use_slan_words=$_POST['use_slan_words'];
    $informed_customer=$_POST['informed_customer'];
    $offer_asistence=$_POST['offer_asistence'];
    $organization_name=$_POST['organization_name'];
    $total_score=$_POST['total_score'];
    $id_callsv=$_POST['call_evaluation_log'];

    $recostmt="SELECT *  from recording_log where recording_id='$recording_id' limit 1";
    $recorslt=mysql_query($recostmt, $link);
    if(mysql_num_rows($recorslt) >0) {


        $recorow = mysql_fetch_array($recorslt);

        $extension=$recorow['extension'];
        $user_extension=$recorow['user'];
    }

    if($id_callsv >0) {

        $insert_query = "update call_evaluation  set id_recording='$recording_id' ,extension='$extension', user='$user_extension',filename='$filename',   agent_name='$agent_name' , email='$email', date='$date_from',call_reference='$call_reference' , evaluated_by='$evaluated_by', mention_first_name='$mention_first_name' , use_friendly_voice='$volume_voice',identify_customer_needs='$customer_needs' , explain_procedures='$explain_process',  give_accurate_information='$accurate_information',  refrained_using_complicated_terms='$complicated_terms',  used_positive_words='$positive_words',  not_used_slang='$use_slan_words',  thank_customer_for_holding='$informed_customer',  offer_additional_assistance='$offer_asistence',  use_organization_name='$organization_name',  total_score='$total_score',    date_update='" . date("Y-m-d H:i:s") . "' where id_call_evaluation=$id_callsv";
    }
    else {
        $insert_query = "insert into call_evaluation  set id_recording='$recording_id' ,extension='$extension',user='$user_extension', filename='$filename',  agent_name='$agent_name', email='$email' , date='$date_from',call_reference='$call_reference' , evaluated_by='$evaluated_by', mention_first_name='$mention_first_name' , use_friendly_voice='$volume_voice',identify_customer_needs='$customer_needs' , explain_procedures='$explain_process',  give_accurate_information='$accurate_information',  refrained_using_complicated_terms='$complicated_terms',  used_positive_words='$positive_words',  not_used_slang='$use_slan_words',  thank_customer_for_holding='$informed_customer',  offer_additional_assistance='$offer_asistence',  use_organization_name='$organization_name',  total_score='$total_score',  date_add='" . date("Y-m-d H:i:s") . "',  date_update='" . date("Y-m-d H:i:s") . "'";
    }
    // echo $insert_query;die;
    $insert_result = mysql_query($insert_query, $link);


    if($insert_result) {
        $to=$_POST['email'];
        $adminmail="<info@wecarekuwait.com>";
        $subject='Call Evaluation Report';
       // $message="	Name :$agent_name<br>Email :$email<br>Date-from : $date_from<br>Call-reference :$call_reference<br>Evaluated By : $evaluated_by<br>";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        $headers .= "From: $adminmail ". "\r\n";
        $headers .= 'Cc: hanadi.b@wecarekuwait.com ' . "\r\n";
        $headers .= "X-Mailer: PHP ". "\r\n";


       /* $file = $play_file;
        $file_size = filesize($file);
        $handle = fopen($file, "r");
        $content = fread($handle, $file_size);
        fclose($handle);
        $content = chunk_split(base64_encode($content));
        $uid = md5(uniqid(time()));
        $header = "From: ".$adminmail." <".$adminmail.">\r\n";
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
        $header .= "This is a multi-part message in MIME format.\r\n";
        $header .= "--".$uid."\r\n";
        $header .= "Content-type:text/html; charset=iso-8859-1\r\n";
        $header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
       // $header .= $message."\r\n\r\n";
        $header .= "--".$uid."\r\n";
        $header .= "Content-Type: application/octet-stream; name=\"".$play_file."\"\r\n"; // use different content types here
        $header .= "Content-Transfer-Encoding: base64\r\n";
        $header .= "Content-Disposition: attachment; filename=\"".$play_file."\"\r\n\r\n";
        $header .= $content."\r\n\r\n";
        $header .= "--".$uid."--";

*/

        $message=" <table  class=\"table\" cellspacing=\"0\" cellpadding=\"1\"><tbody>
<tr>
        <td><label>Name :</label> ".$agent_name."</td>


        <td><label>Date :</label>".$date_from."</td>

        <td><label>Call Ref :</label>".$call_reference."</td>

        <td><label>Evaluated By :</label>".$evaluated_by."</td>
        </tr>

        <tr>
            <td colspan='4'><label>Email :</label>".$email."</td>
      
        </tr>

        <tr bgcolor=\"#d4d0b3\"> <td colspan=\"4\"><b>Call Begaining</b> </td></tr>
        <tr>
            <td ><b>  Use organization Name  </b><br/><b>Mention First Name Clearly</b></td>
            <td>صيغة الترحيب :ميديكال ون , التحية, الاسم - معاك تفضل <br/>
                السويدان كلينك، فوزية السلطان، أو بلش هوم سيرفس
            </td>

            <td>".$mention_first_name."</td><td><b>Max : 10</b></td>

        </tr>
        <tr bgcolor=\"#d4d0b3\"> <td colspan=\"4\"><b>Call Beginning - Voice Quality </b> </td></tr>
        <tr>
            <td ><b>Volume of Voice,Use appropriate Pace</b><br/><b>Friendly tone with a smile</b></td>

            <td>وضوح الصوت اثناء الترحيب وسرعة صوت مناسبة<br/>
                نبرة الصوت ودية اثناء الترحيب– حماسية توجد بها ابتسامة
            </td>
            <td>".$volume_voice."</td><td><b>Max : 10</b></td>

        </tr>
        <tr>
            <td ><b>Identify customer needs</b></td>

            <td> إبلاغ العميل بأنسب حل لطلبه بعد تحديد احتياجه بدقة</td>
            <td>".$customer_needs."</td><td><b>Max : 10</b></td>

        </tr>


        <tr>
            <td ><b>explain the procedures and process (Very Important)</b></td>
            <td>مهم جدا بالسويدان/ إتباع وتوضيح السياسات والإجراءات الموضحة  </td>
            <td>".$explain_process."</td><td><b>Max : 20</b></td>

        </tr>

        <tr>
            <td ><b> gave accurate information</b></td>
            <td> تقديم معلومة صحيحة ووافية للعميل</td>
            <td>".$accurate_information."</td><td><b>Max : 20</b></td>

        </tr>
        <tr bgcolor=\"#d4d0b3\"> <td colspan=\"4\"><b>Call Behavioural Skills  </b> </td></tr>
        <tr>
            <td ><b>Refrained from using complicated terms</b></td>
            <td>  الابتعاد عن المصطلحات الطبية الغير مفهومة للعميل</td>
            <td>".$complicated_terms."</td><td><b>Max : 5</b></td>

        </tr>
        <tr>
            <td ><b>Used positive words (I know, I'm certain,)</b></td>
            <td>التواصل مع العميل من خلال المتابعة ) مثال : نعم , طيب , الخ )</td>
            <td>".$positive_words."</td><td><b>Max : 5</b></td>

        </tr>

        <tr>
            <td ><b>did not use slang and jargon</b></td>
            <td> استخدام الألفاظ الرسمية والابتعاد عن المصطلحات والألفاظ العامية</td>
            <td>".$use_slan_words."</td><td><b>Max : 5</b></td>

        </tr>
        <tr bgcolor=\"#d4d0b3\"> <td colspan=\"4\"><b>Hold Process </b> </td></tr>
        <tr>
            <td ><b>Informed the Customer before</b><br/><b>placing them on hold</b><br/><b>Thanked the customer for holding</b></td>
            <td>الانتظار: الاستئذان و أخذ موافقته عند وضع العميل على الانتظار و شكر العميل على الانتظار أو الاعتذار منه  عند التاخير , </td>
            <td>".$informed_customer."</td><td><b>Max : 5</b></td>

        </tr>
        <tr bgcolor=\"#d4d0b3\"> <td colspan=\"4\"><b>Call Ending </b> </td></tr>
        <tr>
            <td ><b> Offer additional assistance</b></td>
            <td>الاستفسار بصيغة مناسبة عن ما اذا كان العميل يرغب بأي خدمة أخرى</td>
            <td>".$offer_asistence."</td><td><b>Max : 5</b></td>

        </tr>

        <tr>
            <td ><b>Thank you for calling use organization Name</b></td>

            <td>صيغة الختام : شكرا لاتصالك بمديكال ون<br/> شكرا لاتصالك بالسويدان كلينك، فوزية السلطان، أو بلش هوم سيرفس، عيادة الدكتورة هدى الصفار</td>
            <td>".$organization_name."</td><td><b>Max : 5</b></td>

        </tr>
        <tr bgcolor=\"#d4d0b3\"> <td  colspan=\"2\"><b>Total </b> </td><td>".$total_score."</td><td><b>100</b></td></tr>

   
        </tbody></table>";



        if(@mail($to,$subject,$message,$headers, "-odb -f $adminmail"))
        {
            echo "<b>Evaluation has been submitted Sucessfully and Mail has been Sent</b>";
        }
        else
        {
            echo 'Not Able to Send Mail';
        }


        unset($_POST);
    }



}
//$down =$recording_path.$play_file;




$agent_name="";
$email="";
$date_from=date("Y-m-d");
$call_reference="";
$evaluated_by="";
$mention_first_name=0;
$volume_voice=0;
$customer_needs=0;
$explain_process=0;
$accurate_information=0;
$complicated_terms=0;
$positive_words=0;
$use_slan_words=0;
$informed_customer=0;
$offer_asistence=0;
$organization_name=0;
$total_score=0;
$id_call=0;

$callstmt="SELECT *  from call_evaluation where id_recording='$recording_id' limit 1";
$callrslt=mysql_query($callstmt, $link);
if(mysql_num_rows($callrslt) >0) {


    $callrow=mysql_fetch_array($callrslt);

    //echo "<pre>";print_r($callrow);die;

    $agent_name=$callrow['agent_name'];
    $email=$callrow['email'];
    $date_from=$callrow['date'];
    $call_reference=$callrow['call_reference'];
    $evaluated_by=$callrow['evaluated_by'];
    $mention_first_name=$callrow['mention_first_name'];
    $volume_voice=$callrow['use_friendly_voice'];
    $customer_needs=$callrow['identify_customer_needs'];
    $explain_process=$callrow['explain_procedures'];
    $accurate_information=$callrow['give_accurate_information'];
    $complicated_terms=$callrow['refrained_using_complicated_terms'];
    $positive_words=$callrow['used_positive_words'];
    $use_slan_words=$callrow['not_used_slang'];
    $informed_customer=$callrow['thank_customer_for_holding'];
    $offer_asistence=$callrow['offer_additional_assistance'];
    $organization_name=$callrow['use_organization_name'];
    $total_score=$callrow['total_score'];
    $id_call=$callrow['id_call_evaluation'];

}

//echo $down;die;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
    <title>Play Recording File</title>
    <script language="JavaScript" src="calendar_db.js"></script>
    <link rel="stylesheet" href="calendar.css">
    <style type="text/css">input:valid {
            color: green;
        }
        input:invalid {
            color: red;
        }</style>
</head>

<body>
<?php require("top-menu.php"); ?>

<!--
<div class='panel panel-default'>
<div class='panel-heading'>Music Player</div>
<div class='panel-body'>
-->

<form name="form1" method="POST" >

    <?php
    //echo $down;
    if($down == "")
    {
        ?>
        <center> <TABLE width='50%'><TR><TD>
                        <FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
                            <div class='panel panel-default' style='margin:0 0%;'>
                                <div class='panel-heading'><h3 class='panel-title'> Play Recording</h3></div>
                                <div class='panel-body' style='padding:0;'>
                                    <table width='100%' class="table" cellspacing ='0' cellpadding = '1'>
                                        <tr bgcolor=#e8e6da><td align=left class='td_padding' colspan='2'>No file has been selected for Playing</td></tr>
                                        <tr bgcolor=#f7f5f0><td align=left class='td_padding' colspan='2'><input type="button" name="back" class="btn btn-orange" value="Go Back" onclick="javascript:window.history.go(-1);"></td></tr>
                                    </table></div></table></center>
        <?php
    }
    else
    {
//echo $down;die;

        shell_exec("/bin/rm -rf $dirPath/play/*.*");
        shell_exec("/bin/cp $down  $dirPath/play/");
        ?>

        <center><TABLE width='50%'><TR><TD>
                        <FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>
                            <div class='panel panel-default' style='margin:0 0%;'>
                                <div class='panel-heading'><h3 class='panel-title'> Play Recording</h3></div>
                                <div class='panel-body' style='padding:0;'>
                                    <table width='100%' class="table" cellspacing ='0' cellpadding = '1'>
                                        <tr bgcolor=#e8e6da><td align=left class='td_padding' colspan='2'>File Name:<?php echo $play_file;?></td></tr>
                                        <tr bgcolor=#f7f5f0><td align=left class='td_padding' colspan='2'>
                                                <?php
                                                echo "<audio src='play/$play_file' controls>
    <embed 
    src='play/$play_file'
    width='180'
    height='90'
    loop='false'
    autostart='false' />
    </audio>";
                                                ?>
                                                <br /><br />
                                            </td></tr>
                                        <tr bgcolor=#e8e6da><td align=left class='td_padding' colspan='2'><input type="button" name="back" class="btn btn-orange" value="Go Back" onclick="javascript:window.history.go(-1);"></td></tr>
                                    </table></div></table></center>
        <?php
    }
    ?>
    </table>



    <table  class="table" cellspacing="0" cellpadding="1"><tbody>

        <td><label>Name :</label><input  required type="text" name="agent_name" value="<?php echo $agent_name ?>" /></td>


        <td><label>Date :</label><input required type="text" name="date_from" id="date_from" value="<?php echo $date_from ?>"/>    <script language="JavaScript">
                var o_cal = new tcal ({
                    'formname': 'form1',
                    'controlname': 'date_from'
                });
                o_cal.a_tpl.yearscroll = false;
            </script></td>

        <td><label>Call Ref :</label><input required type="text" name="call_reference" value="<?php echo $call_reference;?>"/></td>

        <td><label>Evaluated By :</label><input type="text" required name="evaluated_by" value="<?php echo $evaluated_by;?>"/></td>
        </tr>

        <tr>
            <td><label>Email :</label><input  required type="text" name="email" value="<?php echo $email ?>" /></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>

        <tr bgcolor="#d4d0b3"> <td colspan="4"><b>Call Begaining</b> </td></tr>
        <tr>
            <td ><b>  Use organization Name  </b><br/><b>Mention First Name Clearly</b></td>
            <td>صيغة الترحيب :ميديكال ون , التحية, الاسم - معاك تفضل <br/>
                السويدان كلينك، فوزية السلطان، أو بلش هوم سيرفس
            </td>

            <td><input class="scoring_value" type="number" min = "0" max="10" required  maxlength="2"  name="mention_first_name" value="<?php echo $mention_first_name;?>" /></td><td><b>Max : 10</b></td>

        </tr>
        <tr bgcolor="#d4d0b3"> <td colspan="4"><b>Call Beginning - Voice Quality </b> </td></tr>
        <tr>
            <td ><b>Volume of Voice,Use appropriate Pace</b><br/><b>Friendly tone with a smile</b></td>

            <td>وضوح الصوت اثناء الترحيب وسرعة صوت مناسبة<br/>
                نبرة الصوت ودية اثناء الترحيب– حماسية توجد بها ابتسامة
            </td>
            <td><input class="scoring_value"  type="number" min = "0" max="10"required maxlength="2"  name="volume_voice" value="<?php echo $volume_voice;?>"  /></td><td><b>Max : 10</b></td>

        </tr>
        <tr>
            <td ><b>Identify customer needs</b></td>

            <td> إبلاغ العميل بأنسب حل لطلبه بعد تحديد احتياجه بدقة</td>
            <td><input type="number" class="scoring_value"  min = "0" max="10"required  maxlength="2"  name="customer_needs" value="<?php echo $customer_needs;?>"   /></td><td><b>Max : 10</b></td>

        </tr>


        <tr>
            <td ><b>explain the procedures and process (Very Important)</b></td>
            <td>مهم جدا بالسويدان/ إتباع وتوضيح السياسات والإجراءات الموضحة  </td>
            <td><input class="scoring_value"  type="number" min = "0" max="20" required  maxlength="2"   name="explain_process" value="<?php echo $explain_process;?>"   /></td><td><b>Max : 20</b></td>

        </tr>

        <tr>
            <td ><b> gave accurate information</b></td>
            <td> تقديم معلومة صحيحة ووافية للعميل</td>
            <td><input class="scoring_value"  type="number" min = "0" max="20" required  maxlength="2"  name="accurate_information" value="<?php echo $accurate_information;?>"  /></td><td><b>Max : 20</b></td>

        </tr>
        <tr bgcolor="#d4d0b3"> <td colspan="4"><b>Call Behavioural Skills  </b> </td></tr>
        <tr>
            <td ><b>Refrained from using complicated terms</b></td>
            <td>  الابتعاد عن المصطلحات الطبية الغير مفهومة للعميل</td>
            <td><input class="scoring_value"  type="number" min = "0" max="5" required   maxlength="1" value="<?php echo $complicated_terms;?>"   name="complicated_terms" /></td><td><b>Max : 5</b></td>

        </tr>
        <tr>
            <td ><b>Used positive words (I know, I'm certain,)</b></td>
            <td>التواصل مع العميل من خلال المتابعة ) مثال : نعم , طيب , الخ )</td>
            <td><input class="scoring_value"  type="number" min = "0" max="5" required maxlength="1" value="<?php echo $positive_words;?>"    name="positive_words" /></td><td><b>Max : 5</b></td>

        </tr>

        <tr>
            <td ><b>did not use slang and jargon</b></td>
            <td> استخدام الألفاظ الرسمية والابتعاد عن المصطلحات والألفاظ العامية</td>
            <td><input class="scoring_value"  type="number" min = "0" max="5" required  maxlength="1" value="<?php echo $use_slan_words;?>"    name="use_slan_words" /></td><td><b>Max : 5</b></td>

        </tr>



        <tr bgcolor="#d4d0b3"> <td colspan="4"><b>Hold Process </b> </td></tr>
        <tr>
            <td ><b>Informed the Customer before</b><br/><b>placing them on hold</b><br/><b>Thanked the customer for holding</b></td>
            <td>الانتظار: الاستئذان و أخذ موافقته عند وضع العميل على الانتظار و شكر العميل على الانتظار أو الاعتذار منه  عند التاخير , </td>
            <td><input class="scoring_value" name="informed_customer"  value="<?php echo $informed_customer;?>"   type="number" min = "0" max="5"  maxlength="1"  pattern="\d{1}" required name="informed_customer" /></td><td><b>Max : 5</b></td>

        </tr>
        <tr bgcolor="#d4d0b3"> <td colspan="4"><b>Call Ending </b> </td></tr>
        <tr>
            <td ><b> Offer additional assistance</b></td>
            <td>الاستفسار بصيغة مناسبة عن ما اذا كان العميل يرغب بأي خدمة أخرى</td>
            <td><input class="scoring_value"  value="<?php echo $offer_asistence;?>"    type="number" min = "0" max="5" maxlength="1" pattern="\d{1}" required name="offer_asistence" /></td><td><b>Max : 5</b></td>

        </tr>

        <tr>
            <td ><b>Thank you for calling use organization Name</b></td>

            <td>صيغة الختام : شكرا لاتصالك بمديكال ون<br/> شكرا لاتصالك بالسويدان كلينك، فوزية السلطان، أو بلش هوم سيرفس، عيادة الدكتورة هدى الصفار</td>
            <td><input  class="scoring_value"  value="<?php echo $organization_name;?>"    type="number" min = "0" max="5"required maxlength="1"  name="organization_name" /></td><td><b>Max : 5</b></td>

        </tr>
        <tr bgcolor="#d4d0b3"> <td  colspan="2"><b>Total </b> </td><td><input type="text" id="total_score" readonly  maxlength="3"   value="<?php echo $total_score;?>"  name="total_score" /></td><td><b>100</b></td></tr>

        <input type="hidden" name="call_evaluation_log" value="<?php echo $id_call; ?>">
        <tr><td><input type="submit" name="submit" value="Submit Report"></td></tr>
        </tbody></table>
</form>
</body>
</html>
<script>
    $(document).ready(function() {
        $(".scoring_value").each(function() {
            $(this).keyup(function() {
                calculateSum();
            });
        });
    });

    function calculateSum() {
        var sum = 0;
        $(".scoring_value").each(function() {
            if (!isNaN(this.value) && this.value.length != 0) {
                sum += parseFloat(this.value);
            }
        });

        $("#total_score").val(sum.toFixed(2));
    }
</script>
