<?php 
include('dbconnect.php'); 
require('functions.php');
$ip = getenv("REMOTE_ADDR");
$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
//echo $PHP_AUTH_USER;exit;
$query_date_BEGIN = $_GET['date_from'];
$query_date_END = $_GET['date_to'];
$call_type = $_GET['call_type'];
$group = $_GET['group'];



header('Content-Type: text/csv; charset=utf-8');
header("Content-Disposition: attachment; filename=inbound_callflow_report_$today.csv");
$output = fopen('php://output', 'w');	


fputcsv($output, array('','Inbound Call Flow Report ','','',''));
//fputcsv($output, array('','Todat`s Total Push Lead=',$push_lead ,'',''));
	fputcsv($output, array('No','Campaign Id','Phone Number','Groups','Datetime','Desk','Call Time ','Total Time','Hangup By','Disposition'));

$where = 1;
	if($call_type == "Misscall" ) {$where .= " and (status='DROP' or status='AFTHRS') " ;}
	elseif ($call_type == "Inbound") {$where .= " and (status !='DROP' and status !='AFTHRS')" ;}

	if($group == "Select" )
	{
		#$call_flow_sql = "SELECT * FROM (SELECT phone_ext,start_time,GROUP_CONCAT(comment_b),uniqueid FROM `live_inbound_log` WHERE `start_time` >= '$query_date_BEGIN' and `start_time` <= '$query_date_END'  group by uniqueid) as t1, (SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and {$where} ) as t2 WHERE t1.uniqueid = t2.uniqueid";
		$call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason,phone_number_call_date  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and {$where} ";
	//echo $call_flow_sql;exit;
	}
	if($group != "Select" ){//echo "123";exit;
		#$call_flow_sql = "SELECT * FROM (SELECT phone_ext,start_time,GROUP_CONCAT(comment_b),uniqueid FROM `live_inbound_log` WHERE `start_time` >= '$query_date_BEGIN' and `start_time` <= '$query_date_END'  group by uniqueid) as t1, (SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and campaign_id='$group' and {$where}) as t2 WHERE t1.uniqueid = t2.uniqueid";
		$call_flow_sql = "SELECT user,`campaign_id`,`length_in_sec`,`queue_seconds`,`uniqueid`,status,term_reason,phone_number,call_date  FROM `vicidial_closer_log` WHERE `call_date` >= '$query_date_BEGIN' and `call_date` <= '$query_date_END' and campaign_id='$group' and {$where} ";

	}
	$result = mysql_query($call_flow_sql);						
	$num = mysql_num_rows($result);	

	
		$i = 1;	
		$total_duration=0;	
		while ($call_flow_row = mysql_fetch_array($result))
		{	
				   $uniqueid = $call_flow_row['4'];
                                $phone_number = $call_flow_row['7'];
                                $group = $call_flow_row['1'];
                                $datetime = $call_flow_row['8'];
                                $user = $call_flow_row['0'];
                                $sec = $call_flow_row['2'];
                                #$que_sec = $call_flow_row['7'];
				$status = $call_flow_row['5'];
				$action = $call_flow_row['6'];
				$row = $i;
				
				if($pre_uniqueid==$uniqueid)
                                {
                                        $uniqueid='';
                                        $phone_number='';
                                        $ivr='';
                                        $datetime='';
					$row='';
					$i--;
					$c++;
					$total_sec = $total_sec + $sec;
                                }
                                elseif($pre_uniqueid!=$uniqueid)
                                {
                                        $pre_uniqueid='';
					$c=1;
					$total_sec = $sec;
                                }
				### Print total sec 
				$print_total_sec = $total_sec;
				$print_total_sec = sec_convert($print_total_sec,'H');
				$sec = sec_convert($sec,'H');
				

						
			fputcsv($output,array($i,$uniqueid,$phone_number,$group,$datetime,$user,$sec,$print_total_sec,$action,$status
));			
			 if($pre_uniqueid=='')
                                {
                                        $pre_uniqueid = $uniqueid;
                                }
	        	$i++;
		}
$NOW_TIME = date("Y-m-d H:i:s");
	
	$SQL_log = "$call_flow_sql|";
		$SQL_log = ereg_replace(';','',$SQL_log);
		$SQL_log = addslashes($SQL_log);
		$stmt="INSERT INTO vicidial_admin_log set event_date='$NOW_TIME', user='$PHP_AUTH_USER', ip_address='$ip', event_section='LEADS', event_type='EXPORT', record_id='', event_code='ADMIN EXPORT CALLS FLOW REPORT', event_sql=\"$SQL_log\", event_notes='';";
		//echo $stmt;exit;
		if ($DB) {echo "|$stmt|\n";}
		$rslt=mysql_query($stmt);		

//fputcsv($output,array('Total Number of Record(s):',$i-1));
?>