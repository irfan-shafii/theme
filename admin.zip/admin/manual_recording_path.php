<?php
//$recording_path="/var/spool/asterisk/monitorDONE/ORIG/";

$recording_path="/var/spool/asterisk/manual/";
$dirPath=getcwd();
?>
