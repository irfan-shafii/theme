<link rel="stylesheet" type="text/css" href="css/fonts.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<!-- <link rel="stylesheet" type="text/css" href="css/dropdown.css"> -->
<link rel="stylesheet" type="text/css" href="css/custom.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/panel-hideshow.js"></script>
<script src="js/custom.js"></script>
<div class="pg-header">
	<div class="container">
		<div class="col-xs-2">
			<h1 class="centrix-logo"><a class="text-hide" href="./admin.php">Centrix</a></h1>
		</div>
		<div class="col-xs-10">
			<div class="pg-sb-header text-right">
				<ul class="nav navbar-nav navbar-right">
			<li><?php echo date('D M d, Y '); echo date('H:i:s A'); ?> &nbsp;|&nbsp; </li>
						<li><a title="Home" data-toggle="tooltip" data-placement="top" href="./admin.php"><i class="fa fa-home" aria-hidden="true"></i></a> &nbsp;&nbsp;&nbsp;
					</li>	<li>	<a title="Search" data-toggle="tooltip" data-placement="top" href="admin_search_lead.php"><i class="fa fa-search" aria-hidden="true"></i></a> &nbsp;&nbsp;&nbsp;
					</li>	<li><a title="Logout" data-toggle="tooltip" data-placement="top" href="./admin.php?force_logout=1"><i class="fa fa-sign-out" aria-hidden="true"></i></a> &nbsp;&nbsp;&nbsp;
					</li>	<li>	<a title="Live Chat" data-toggle="tooltip" data-placement="top" href="./chat_customer/vicidial_chat_customer_side.php"><i class="fa fa-weixin" aria-hidden="true"></i></a>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Calls in Queue"><span class="label label-pill label-danger count" style="border-radius:10px;"></span> <span class="glyphicon glyphicon-bell" style="font-size:18px;"></span></a>
						<ul class="dropdown-menu" id="queue_count"></ul>
					</li>
				</ul>

			</div>
		</div>
	</div>
</div>
<nav class="navbar navbar-inverse">
	<div class="container">
		<ul class="nav navbar-nav">
			<li class="dropdown">
				<a href="./admin.php?ADD=0" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Agents <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=0">Show All Agents</a></li>
					<li><a href="./admin.php?ADD=1">Add New Agent</a></li>
					<li><a href="./admin.php?ADD=1A">Copy Agent</a></li>
					<li><a href="./admin.php?ADD=550">Search Agent</a></li>
					<li><a href="./user_stats.php?user=<?php echo $user ?>">Agent Stat</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=10" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Process <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=10">Process</a></li>
					<li><a href="./admin.php?ADD=32">Disposition</a></li>
					<li><a href="./admin.php?ADD=33">Hot Keys</a></li>
					<li><a href="./admin.php?ADD=35">Lead Recycle</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="./admin.php?ADD=36">Auto-Alt Dial</a></li>
					<li><a href="./admin.php?ADD=39">List Mix</a></li>
					<li><a href="./admin.php?ADD=37">Pause Codes</a></li>
					<li><a href="./admin.php?ADD=301">Presets</a></li>
					<li><a href="./admin.php?ADD=302">AC-CID</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=0" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Leads <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=100">Show List</a></li>
					<li><a href="./admin.php?ADD=111">Add A New List</a></li>
					<li><a href="./admin_search_lead.php">Search New Lead</a></li>
					<li><a href="./admin_modify_lead.php">Add A New Lead </a></li>
					<li><a href="./admin.php?ADD=121">Add-Delete DNC Number</a></li>
					<li><a href="./new_listloader_superL.php">Load New Leads</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=1000000" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Scripts <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=1000000">Show Script</a></li>
					<li><a href="./admin.php?ADD=1111111">Add New Script</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=10000000" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Filters <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=10000000">Show Filters</a></li>
					<li><a href="./admin.php?ADD=11111111">Add New Filters</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=10000000" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Inbound <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=1000">Show IVR</a></li>
					<li><a href="./admin.php?ADD=1111">Add New IVR</a></li>
					<li><a href="./admin.php?ADD=1211">Copy IVR</a></li>
					<li><a href="./admin.php?ADD=1300">Show PRI Numbers</a></li>
					<li><a href="./admin.php?ADD=1311">Add New PRI Number</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="./admin.php?ADD=1411">Copy PRI Number</a></li>
					<li><a href="./admin.php?ADD=1500">Show Call Menus</a></li>
					<li><a href="./admin.php?ADD=1511">Add New Call Menu</a></li>
					<li><a href="./admin.php?ADD=1611">Copy Call Menu</a></li>
					<li><a href="./admin.php?ADD=1700">Filter Phone Groups</a></li>
					<li><a href="./admin.php?ADD=1711">Add Filter Phone Group</a></li>
					<li><a href="./admin.php?ADD=171">Add-Delete FPG Number</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=100000" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">User Groups <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=100000">Show User Groups</a></li>
					<li><a href="./admin.php?ADD=111111">Add New User Groups</a></li>
					<li><a href="./user_group_bulk_change.php">Bulk Group Change</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=10000" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Remote Agent <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=10000">Show Remote Agents</a></li>
					<li><a href="./admin.php?ADD=11111">Add New Remote Agent</a></li>
					<li><a href="./admin.php?ADD=12000">Show Extension Groups</a></li>
					<li><a href="./admin.php?ADD=12111">Add New Extension Groups</a></li>
				</ul>
			</li>
			<li class="dropdown">
				<a href="./admin.php?ADD=100000000" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="./admin.php?ADD=100000000">Call Times</a></li>
					<li><a href="./admin.php?ADD=130000000">Shifts</a></li>
					<li><a href="./admin.php?ADD=10000000000">Phones</a></li>
					<li><a href="./admin.php?ADD=130000000000">Templates</a></li>
					<li><a href="./admin.php?ADD=140000000000">Carriers</a></li>
					<li role="separator" class="divider"></li>
					<li><a href="./admin.php?ADD=100000000000">Servers</a></li>
					<li><a href="./admin.php?ADD=1000000000000">Conferences</a></li>
					<li><a href="./admin.php?ADD=311111111111111">System Settings</a></li>
					<li><a href="./admin.php?ADD=321111111111111">System Dispositions</a></li>
					<li><a href="./admin.php?ADD=180000000000">Screen Labels</a></li>
					<li><a href="./admin.php?ADD=170000000000">Voice Mail</a></li>
					<li><a href="./break_time.php">Max Break Time</a></li>
					<li><a href="./break_time_code.php">User Break Time Code</a></li>
				</ul>
			</li>
			<li><a href="./admin.php?ADD=999999">Reports</a></li>
			<li class="dropdown">
				<a href="./search_recording_inbound.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Recordings <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<!-- <li><a href="./search_recording.php">Search Recording</a></li> -->
					<li><a href="./search_recording_inbound.php">Search Recording Inbound</a></li>
					<li><a href="./search_recording_outbound.php">Search Recording Outbound</a></li>
					<!-- <li><a href="./recording_report.php?section=recordings_for_this_time">Recording For This Time Period</a></li> -->
					<li><a href="./manual_outbound_recording_report.php?section=manual">Manual Outbound Calls</a></li>
<li><a href="./search_recording_wecare_extension.php">Search Recording Extension</a></li>
				</ul>
			</li>
			<li><a href="./kpi-report.php">KPI</a></li>

		</ul>
	</div>
</nav>
<?php  $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
<script>
	var oldstats=0;
	var oldnote=0;
	var closecallid=0;

	$(document).ready(function() {

		load_unseen_notification();
		setInterval(function(){ load_unseen_notification(); }, 30000);
		setInterval(function(){ load_unseen_notification('','agent'); }, 30000);
		load_sound();
		setInterval(function(){ 		load_sound(); }, 5000);
	});
	$(document).on('click', '.dropdown-toggle', function(){
		$('.count').html('');
		load_unseen_notification('yes','queue');
	});
	function load_unseen_notification(view = '',localtype='queue') {
		if (!Notification) {
			$('body').append('<h4 style="color:red">*Browser does not support Web Notification</h4>');
			return;
		}
		if (Notification.permission !== "granted") {
			Notification.requestPermission();
		}
		else {
			if(localtype=='queue') {
				$.ajax(
					{
						url: "fetch.php",
						method: "POST",
						data: {view: view},
						dataType: "json",
						success: function (data) {

							$('#queue_count').html(data.notification);
							var nottitle = data.unseen_notification + " Calls in Queue";
							if (data.unseen_notification > 0 ) {
								$('.count').html(data.unseen_notification);

								if (view == '' && oldstats !=data.unseen_notification) {

									var theurl = '<?php echo $actual_link; ?>';
									var notifikasi = new Notification("Change in KPI", {
										icon: "images/centrix_plus-logo-light.png",
										body: nottitle,
									});
									notifikasi.onclick = function () {
										window.open(theurl);
										notifikasi.close();
									};
									setTimeout(function () {
										notifikasi.close();
									}, 3000);

									oldstats=data.unseen_notification;

								}

							} else {
								$('.count').html('');

							}


						},
						error: function (jqXHR, textStatus, errorThrown) {

						}
					});
			}
			if(localtype=='agent') {

				$.ajax(
					{
						url: "fetch-agent.php",
						method: "POST",
						data: {view: view},
						dataType: "json",
						success: function (data) {

							//	$('#queue_count').html(data.notification);
							var nottitle = data.unseen_notification + " Agents are on Short Break greator than 10 Minutes";
							if (data.unseen_notification > 0 ) {
								//$('.count').html(data.unseen_notification);

								if (view == '' && oldnote !=data.unseen_notification) {

									var theurl = '<?php echo $actual_link; ?>';
									var notifikasi = new Notification("Change in KPI", {
										icon: "images/centrix_plus-logo-light.png",
										body: nottitle,
									});
									notifikasi.onclick = function () {
										window.open(theurl);
										notifikasi.close();
									};
									setTimeout(function () {
										notifikasi.close();
									}, 3000);

									oldnote=data.unseen_notification;
								}

							} else {
								//$('.count').html('');

							}


						},
						error: function (jqXHR, textStatus, errorThrown) {

						}
					});
			}

		}
	}


	function load_sound(view = 'role') {

			//if(localtype=='queue') {
				$.ajax(
					{
						url: "fetch-sound.php",
						method: "POST",
						data: {view: view},
						dataType: "json",
						success: function (data) {


							if (data.unseen_notification > 0 ) {
								if ( closecallid !=data.callid && closecallid >0) {
									var audio = new Audio('sounds/beep-01.mp3');
									audio.play();
									closecallid=data.callid;
								}
							}


						},
						error: function (jqXHR, textStatus, errorThrown) {

						}
					});
			//}



	}
</script>
