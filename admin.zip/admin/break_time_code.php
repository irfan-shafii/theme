<?php
//echo getcwd();die;
session_cache_limiter('private_no_expire');
session_start();
ob_start();
include_once("./dbconnect.php");
include_once("./value.php");
#############################################
##### START SYSTEM_SETTINGS LOOKUP #####
$stmt = "SELECT use_non_latin,outbound_autodial_active,user_territories_active FROM system_settings;";
$rslt=mysql_query($stmt, $link);
if ($DB) {echo "$stmt\n";}
$ss_conf_ct = mysql_num_rows($rslt);
if ($ss_conf_ct > 0)
{
    $row=mysql_fetch_row($rslt);
    $non_latin =                                            $row[0];
    $SSoutbound_autodial_active =           $row[1];
    $user_territories_active =                      $row[2];
}
//echo "<pre>";print_r($_SESSION);die;
##### END SETTINGS LOOKUP #####echo
###########################################
//$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
//$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
$PHP_AUTH_USER=$_SESSION['username'];
$PHP_AUTH_PW=$_SESSION['password'];
//$PHP_AUTH_USER = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_USER);
//$PHP_AUTH_PW = ereg_replace("[^0-9a-zA-Z]","",$PHP_AUTH_PW);

$STARTtime = date("U");
$TODAY = date("Y-m-d");

if (!isset($begin_date)) {$begin_date = $TODAY;}
if (!isset($end_date)) {$end_date = $TODAY;}
$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7 and view_reports='1';";
if ($non_latin > 0) { $rslt=mysql_query("SET NAMES 'UTF8'");}
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$auth=$row[0];

$fp = fopen ("./project_auth_entries.txt", "a");
$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or (!$auth))
{
    $referaall_url=base64_encode("break_time_code");
   header("Location: login.php?refereer=$referaall_url");

   exit;
}
else
{
    if($auth>0)
    {
        $stmt="SELECT full_name from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
        $rslt=mysql_query($stmt, $link);
        $row=mysql_fetch_row($rslt);
        $LOGfullname=$row[0];

        fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
        fclose($fp);
    }
    else
    {
        fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
        fclose($fp);
        echo "Invalid Username/Password: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
        exit;
    }

    $stmt="SELECT full_name,user_id from vicidial_users where user='$PHP_AUTH_USER';";
    $rslt=mysql_query($stmt, $link);
    $row=mysql_fetch_row($rslt);
    //echo "<pre>";print_r($row);die;
    $full_name = $row[0];
    $user_id= $row[1];

}


if($_POST['submit']) {
 //echo "<pre>";print_r($_POST);die;

    $recostmt="SELECT *  from breaktimeCode where user_id=".$_POST['userid'];
    $recorslt=mysql_query($recostmt, $link);
    if(mysql_num_rows($recorslt) >0) {

        $insert_query = "update breaktimeCode  set break_code='".$_POST['break_code']."' , updated_by='$user_id',date_update='" . date("Y-m-d H:i:s") . "' where  user_id=".$_POST['userid'];
    } else {
        $insert_query = "insert into breaktimeCode  set break_code='".$_POST['break_code']."',updated_by='$user_id', user_id=".$_POST['userid'].",date_update='" . date("Y-m-d H:i:s") . "',date_add='" . date("Y-m-d H:i:s") . "'";

    }

   // echo $insert_query;die;
    $insert_result = mysql_query($insert_query, $link);

    if($insert_result) {

        echo "Break Time Code has been Updated Successfully";

        unset($_POST);
    }

}
//$down =$recording_path.$play_file;

$callstmt="SELECT *  from breakTimeConfiguration  limit 1";
$callrslt=mysql_query($callstmt, $link);
if(mysql_num_rows($callrslt) >0) {

    $callrow=mysql_fetch_array($callrslt);

    $maxbreaktime=$callrow['breaktime'];

  //  $id_call=$callrow['id_breaktime'];

}


$getUsers="select user_id,full_name from vicidial_users where user_level >1 and active='Y'";
$userResult=mysql_query($getUsers, $link);

//echo $down;die;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
    <title>Break Time Code</title>

    <style type="text/css">input:valid {
            color: green;
        }
        input:invalid {
            color: red;
        }</style>
</head>

<body>
<?php require("top-menu.php"); ?>
<script language="JavaScript" src="js/timepicker/jquery.timepicker.min.js"></script>
<link rel="stylesheet" href="js/timepicker/jquery.timepicker.css">
<!--
<div class='panel panel-default'>
<div class='panel-heading'>Music Player</div>
<div class='panel-body'>
-->
<script>$('.timepicker').pickatime()</script>

<form name="form1" method="POST" >


    <table  class="table" cellspacing="0" cellpadding="1"><tbody><tr>

<td><label> User : </label></td><td><select id="userid"  name="userid" required onchange="changebreak()"><option>Select User</option>
                <?php if(mysql_num_rows($userResult) >0) {

                    while($rest=mysql_fetch_array($userResult)) { ?>

                        <option value="<?php echo $rest['user_id']  ?>"><?php echo $rest['full_name']; ?></option>

                 <?php   }
                    ?>



                    <?php }?>

                </select></td> </tr><tr>
        <td><label>Break Code :</label></td><td><input required type="text" id="break_code" name="break_code" maxlength="8"/></td>

             </tr>

               <tr><td><input type="submit" name="submit" value="Submit"></td></tr>
        </tbody></table>
</form>
</body>
</html>
<script>
function changebreak() {

    var userid=$("#userid").val();
    if(userid > 0) {

        $.ajax(
            {
                url: "ajax_break.php",
                method: "POST",
                data: {userid: userid},
               // dataType: "html",
                success: function (data) {
                    $("#break_code").val(data);
                   // alert(data);
                // consol.log(data);


                },
                error: function (jqXHR, textStatus, errorThrown) {

                }
            });
    } else {

        $("#break_code").val('');
    }


}
</script>