<?php 
include('dbconnect.php'); 
require('functions.php');
$ip = getenv("REMOTE_ADDR");
$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];

$query_date_BEGIN = $_GET['date_from'];
$query_date_END = $_GET['date_to'];
$campaign = $_GET['campaign'];


header('Content-Type: text/csv; charset=utf-8');
header("Content-Disposition: attachment; filename=outbound_callflow_report_$today.csv");
$output = fopen('php://output', 'w');	


fputcsv($output, array('','Inbound Call Flow Report ','','','','','',''));
//fputcsv($output, array('','Todat`s Total Push Lead=',$push_lead ,'',''));
	fputcsv($output, array('No','Campaign Id','Phone Number','DateTime','User','','Status','','Lead Id','List Id'));

	if($campaign != "")
	{
		$call_flow_sql = "select * from (select call_date,campaign_id,length_in_sec,lead_id,list_id,status,phone_number,user,term_reason from vicidial_log where call_date>='$query_date_BEGIN' and call_date<='$query_date_END' and campaign_id='$campaign') as t1 , (select lead_id,phone_number from vicidial_list) as t2 where t1.lead_id=t2.lead_id and t1.phone_number=t2.phone_number ";
	}else{
		$call_flow_sql = "select * from (select call_date,campaign_id,length_in_sec,lead_id,list_id,status,phone_number,user,term_reason from vicidial_log where call_date>='$query_date_BEGIN' and call_date<='$query_date_END' ) as t1 , (select lead_id,phone_number from vicidial_list) as t2 where t1.lead_id=t2.lead_id and t1.phone_number=t2.phone_number ";
	}
	
	
	#echo $call_flow_sql;

	$result = mysql_query($call_flow_sql);						
	$num = mysql_num_rows($result);	

	
		$i = 1;	
		$total_duration=0;	
		while ($row1 = mysql_fetch_array($result))
		{	
			   	$phone_number = $row1['phone_number'];
                $campaign = $row1['campaign_id'];
                $datetime = $row1['call_date'];
                $user = $row1['user'];
                $sec = $row1['length_in_sec'];
				$status = $row1['status'];
				$action = $row1['term_reason'];
				$lead_id = $row1['lead_id'];	
				$list_id = $row1['list_id'];									
			fputcsv($output,array($i,$campaign,$phone_number,$datetime,$user,$sec,$status,$action,$lead_id,$list_id
));	
	        	$i++;
		}
	
	$NOW_TIME = date("Y-m-d H:i:s");
	
	$SQL_log = "$call_flow_sql|";
		$SQL_log = ereg_replace(';','',$SQL_log);
		$SQL_log = addslashes($SQL_log);
		$stmt="INSERT INTO vicidial_admin_log set event_date='$NOW_TIME', user='$PHP_AUTH_USER', ip_address='$ip', event_section='LEADS', event_type='EXPORT', record_id='', event_code='ADMIN EXPORT OUTBOUND CALLS FLOW REPORT', event_sql=\"$SQL_log\", event_notes='';";
		//echo $stmt;exit;
		if ($DB) {echo "|$stmt|\n";}
		$rslt=mysql_query($stmt);	
//fputcsv($output,array('Total Number of Record(s):',$i-1));
?>